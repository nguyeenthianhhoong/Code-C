#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdio_ext.h>
#include "mygraph.h"
void chuanHoa(char *string){
    int n = strlen(string);
    char name[strlen(string)+1];
    int i = 0;
    while(string[i] == ' ') ++i;
    while(string[n - 1] == ' ') --n;
    int total = 0;
    name[total++] = string[i++];
    for (; i < n; ++i)
        if(string[i] != ' ' || string[i-1] != ' ') name[total++] = string[i];
    name[total] = 0;
    strcpy(string,name);
    return;
}
int readFile(Graph *graph){
    FILE  *f = fopen("hanoi-bus.txt","r");
    if(f == NULL){
        printf("Loi mo file.!!!");
        return -1;
    }
    char tuyen[10];// luu ten cua tuyen bus dang xet
    char name[200];// luu ten cua tuyen truoc do
    char name1[200];// luu ten cua tuyen hien tai
    char c;
    int t,n;// t lam chi so cho mang tuyen . n lam chi so cho mang name
    while(!feof(f)){
        t = 0;
        do{
            c = fgetc(f);
        }while (!isdigit(c));//0
        do{
            tuyen[t++] = c;
            c = fgetc(f);
        }while (c != ':');
        tuyen[t] = 0;
        n = 0;
        fgetc(f);
        c = fgetc(f);
        do{
            name[n++] = c;
            c = fgetc(f);
        }while (c != '>' && c != '\n' && c != '}');
        name[n - 1] = 0;
        chuanHoa(name);
        addVertex(graph,getID(graph,name),name);// them mot tram moi vao do thi (Tu bo qua neu name da ton tai trong graph)
        do{
            n = 0;
            fgetc(f);
            c = fgetc(f);
            do{
                name1[n++] = c;
                c = fgetc(f);
            }while (c != '>' && c != '\n' && c != '}');
            if(c != '}' && c != '\n') name1[n - 1] = 0;
            else name1[n] = 0;
            chuanHoa(name1);
            addVertex(graph,getID(graph,name1),name1);// them mot tram moi vao do thi (Tu bo qua neu name da ton tai trong graph)
            addEdge(graph,getID(graph,name),getID(graph,name1),tuyen,NULL);// them mot canh co huong tu name sang name1
            strcpy(name,name1);// cap nhat lai name  ==  name1
            if(c == '}') break;
        }while(c != '\n');
        if(c == '}') break;
    }
    fclose(f);
}
/*
 * Sau khi tim duoc tuyen duong co so tram di qua nho nhat  (Djkstra)
 * Goi ham nay de tim so tuyen nho nhat di doc theo tuyen duong da tim
 */
int  timTuyen(const Graph *graph,int *tram,int total,char *tuyen[10],int *total_t){
    //int x = 0;
}
int main() {
    char start[100];
    char end[100];
    int tram[1000];
    char tuyen[1000][10];
    int weight;
    int id1;
    int id2;
    int total ;
    Graph graph;
    createGraph(&graph);
    readFile(&graph);
    printGraph(&graph);
    do{
        printf("Nhap dia diem xuat phat : ");
        __fpurge(stdin);
        scanf("%[^\n]s",&start);
        printf("Nhap dia diem den : ");
        __fpurge(stdin);
        scanf("%[^\n]s",end);
        chuanHoa(start);
        chuanHoa(end);
        id1 = getID(&graph,start);
        id2 = getID(&graph,end);
        if(id1 > getVertexCount(&graph)|| id2 > getVertexCount(&graph))         
            printf("Dia diem ban nhap khong ton tai\n");
        else{
            total = dijkstra1(&graph,id1,id2,&weight,tram);
            if(total == 0 ) printf("Khong ton tai duong di giua hai dia diem.\n");
            else{
               // timTuyen(&graph,tram,total,tuyen);
                printf("So tram di qua la : %d\n",weight);
                printf("Tuyen duong can di la : ");
                printArr(&graph,tram,total);
            }
        }
        printf("\nBan co muon tim duong tiep (y/n) : ");
        __fpurge(stdin);
        id1 = fgetc(stdin);
    }while(id1 != 'n');
    dropGraph(&graph);
    return 0;
}
