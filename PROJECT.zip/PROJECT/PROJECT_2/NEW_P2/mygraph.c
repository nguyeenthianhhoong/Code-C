#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mygraph.h"
#include "queue.h"
#include "jval.h"
#include "jrb.h"
#include "dllist.h"

void createGraph(Graph *graph){
    graph->vertex = make_jrb();
    graph->edges = make_jrb();
    graph->id = 1;
    return ;
}
/*
 them canh giua 2 dinh kem trong so
 */

void addEdge(Graph *graph,int edge_1,int edge_2,char *tuyen,int *weight){
    JRB p = jrb_find_int(graph->edges,edge_1);
    JRB tree = (JRB)jval_v(p->val);
    if(tree == NULL){
        tree = make_jrb();
        JRB s = make_jrb();
        jrb_insert_str(s,strdup(tuyen),new_jval_v(NULL));
        jrb_insert_int(tree,edge_2,new_jval_v(s));
        p->val = new_jval_v(tree);
    }else{
        JRB s = jrb_find_int(tree,edge_2);
        if(s != NULL){
            JRB d = jrb_find_str((JRB)jval_v(s->val),tuyen);
            if(d != NULL) return;
            jrb_insert_str((JRB)jval_v(s->val),strdup(tuyen),new_jval_v(NULL));
            return ;
        }
        JRB d = make_jrb();
        jrb_insert_str(d,strdup(tuyen),new_jval_v(NULL));

        jrb_insert_int(tree,edge_2,new_jval_v(d));
   
    }
}



/*
 them dinh 
 */
void addVertex(Graph *graph,int id,char *name){
    JRB p = jrb_find_int(graph->vertex,id);
    if(p != NULL) return ;
    jrb_insert_int(graph->vertex,id,new_jval_s(strdup(name)));
    jrb_insert_int(graph->edges,id,new_jval_v(NULL));
}

void printGraph(const Graph *graph){
    printf("\nDanh sach cac id va ten dinh : \n");
    JRB p;
    jrb_traverse(p,graph->vertex)
        if(p != NULL) printf("%-5d : %s\n",jval_i(p->key),jval_s(p->val));
}


void dropGraph(Graph *graph){
    JRB p;
    if(graph->vertex != NULL){// giai phong cay vertex chua id va ten tram
        jrb_traverse(p, graph->vertex) if(p != NULL){// duyet cay vertex lay ra ten tram va giai phong (ten tram duoc cap phat dong bang ham strdup)
            char *s = jval_s(p->val);
            if(s != NULL) free(s);
        }
        jrb_free_tree(graph->vertex);
    }
    if(graph->edges != NULL){
        JRB s;
        jrb_traverse(s,graph->edges) // tai moi node cua cay lay ra cay con cua node (val)
            if(s != NULL){
                JRB g = (JRB)jval_v(s->val);
                JRB l,tree;
                if(g != NULL) jrb_traverse(l,g){ // tai moi node cua cay con lay ra cay con chua ten tuyen
                   tree = (JRB)jval_v(l->val);
                    if(tree != NULL){
                        JRB m;
                        jrb_traverse(m,tree)// duyet cay chua ten tuyen va giai phong
                            if(m != NULL){
                                char * str = jval_s(m->key);
                                if(str != NULL) free(str);
                            }
                        jrb_free_tree(tree);
                    }
                }
                if(g != NULL) jrb_free_tree(g);
            }
        jrb_free_tree(graph->edges);
    }
}
/*
 Lay ten dinh tu id
 */
char* getName(const Graph *graph,int id){
    JRB s = jrb_find_int(graph->vertex,id);
    return jval_s(s->val);
}

/*
 lay so luong dinh cua do thi
 */
int getVertexCount(const Graph *graph){
    int t = 0;
    JRB p;
    jrb_traverse(p,graph->vertex)
        if(p != NULL) ++t;
    return t;
}

/*
 in duong di
 */

void printArr(const Graph *graph,int *arr,int total){
    JRB p;
    int t = 0;
    for (int i = total - 1; i >= 0; --i) {
            p = jrb_find_int(graph->vertex,arr[i]);
	    if(i == total - 1) 
                printf("%s \n->  ",jval_s(p->val));
            if(p != NULL && i != total - 1){
		JRB w = (JRB)jval_v(jrb_find_int(graph->edges,t)->val);
		JRB l ;
		if(w!=NULL) 
                    l = (JRB)jval_v(jrb_find_int(w,jval_i(p->key))->val);
		printf("%s (   ",jval_s(p->val));
		JRB g;
		if(l != NULL) jrb_traverse(g,l)
			printf("%s  ",jval_s(g->key));
		if(i != 0) printf(") \n-> ");
		else printf(")");
		}
	t = jval_i(p->key);
    }
}


/*
 lay trong so giua 2 dinh
 */
int getweight(const Graph *graph,int edge_1,int edge_2){
    return 1;
}
/*
 lay cac id lien ke tu v1
 */
int getConnected(const Graph *graph,int v1,int *arr){
    JRB node = jrb_find_int(graph->edges,v1);
    if(node == NULL) return -1;
    int total = 0;
    JRB tree = (JRB)jval_v(node->val);
    JRB p;
    if(tree != NULL) jrb_traverse(p,tree)
            if(p!= NULL) arr[total++] = jval_i(p->key);

    return total;
}
 
int getID(Graph *graph,char *name){// ham nay kiem tra xem name da ton tai trong do thi chua neu co tra ve id tuong ung . Chua ton tai tra ve id moi
    JRB s;
    jrb_traverse(s,graph->vertex)
        if(s != NULL && strcmp(name,jval_s(s->val)) == 0) return jval_i(s->key);
    int id = graph->id;
    graph->id+=1;
    return id;
}
/*
 * Dua vao mang luu thong tin trong qua trinh dijkstra tim duong di tu dinh bat dau(start) den dinh ket thuc(end)
 */
int timDuong(int *ghiDuong,int end,int *arr){
    int to = 0;
    while(1){
        if(end == -1) break;
        arr[to++] = end;
        end = ghiDuong[end];
    }
    return to;
}

int dijkstra1(const Graph *graph,int start,int end,int *money,int *arr){
    int ck[2300] = {0};// neu dinh i (id = i)  chua duoc tham thi = 0. Dang tham= 2. Da tham xong 1
    int weight[2300] = {0};// luu trong so  
    int ghiDuong[2300] = {-1};// ghi lai dinh truoc do 
    int connect[2300] = {0};// ghi lai tat ca id cua cac dinh lien ke dinh hien tai
    int total_c = 0;//so luong phan tu mang connect
    Queue queue;
    createQueue(&queue);
    inQueue(&queue,start,0);
    weight[start] = 0;
    ck[start] = 2;
    ghiDuong[start] = -1;
    while(!isEmpty(&queue)) {
        Data_q *data = deQueue(&queue);
        if (ck[data->id] != 1) {
            ck[data->id] = 1;
            if (data->id == end) break;
            total_c = getConnected(graph, data->id, connect);
            for (int i = 0; i < total_c; ++i) {
                if (ck[connect[i]] == 1) continue;
                if (ck[connect[i]] == 2 &&
                    (compare(weight[connect[i]], weight[data->id] + getweight(graph, data->id, connect[i])) > 0)) {
                    weight[connect[i]] = weight[data->id] + getweight(graph, data->id, connect[i]);
                    ghiDuong[connect[i]] = data->id;
                }
                if (ck[connect[i]] == 0) {
                    inQueue(&queue, connect[i], getweight(graph, data->id, connect[i]) + weight[data->id]);
                    ck[connect[i]] = 2;
                    ghiDuong[connect[i]] = data->id;
                    weight[connect[i]] = getweight(graph, data->id, connect[i]) + weight[data->id];
                }
            }
            free(data);
        }
    }
    *money = weight[end];
    if(*money == 0) return -1;
    int t = -1;
    if(arr != NULL) 
        t = timDuong(ghiDuong,end,arr);
    freeQueue(&queue);
    return t;
}


