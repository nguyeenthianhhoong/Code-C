#ifndef UNTITLED5_MYGRAPH_H
#define UNTITLED5_MYGRAPH_H

#include "jval.h"
#include "jrb.h"

typedef struct Graph{
    JRB vertex;
    JRB edges;
    int id ;
}Graph;

void  createGraph(Graph *);
//void addEdge(Graph *,int edge_1,int edge_2,char *tuyen,int *weight,int tag);
void addEdge(Graph *,int edge_1,int edge_2,char *tuyen,int *weight);
void addVertex(Graph *,int key,char *name);
void printGraph(const Graph *);
int inDegree(const Graph *,int key);
int outDegree(const Graph *,int key);
int getVertexCount(const Graph *);
int getEdgesCount(const Graph *);
int dijkstra1(const Graph *graph,int start,int end,int *money,int *arr);
void printArr(const Graph *,int *arr,int total);
int getweight(const Graph *,int edge_1,int edge_2);
char* getName(const Graph *,int id);
int getConnected(const Graph *graph,int v1,int *arr);
void dropGraph(Graph *graph);
int getID(Graph *graph,char *name);
#endif
