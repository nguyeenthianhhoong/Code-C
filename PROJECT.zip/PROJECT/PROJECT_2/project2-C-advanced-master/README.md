# Instruction
Run shell.sh file
> ./run.sh