#include<stdio.h>
#include<string.h>
#include<stdlib.h>
enum{success,fail,max=100};



struct sinhvien {
	int stt;
	char id[8], hoten[50], sdt[10];
  double diem;
};

int main() {
	// Contruct struct
	/*sinhvien sv[20];*/
  struct sinhvien *sv;
	
	
	FILE *ptr,*ptr1;
	char filename1[]="sv.txt",filename2[]="bangdiem.txt";
	int reval=success;

	    if((ptr=fopen(filename1,"r"))==NULL){
	       printf("cannot open %s.\n",filename1);
               reval=fail;
            }else if((ptr1=fopen(filename2,"w"))==NULL){
	       printf("cannot open %s.\n",filename2);
               reval=fail;
	    }else{
	  
	// Doc noi dung file vao struct
	//writeFileToStruct(ptr,sv);
        int count = 0;
	char buff[max];
	while(fgets(buff,max,ptr)!=NULL){
		
		if (count = 5) {
			break;
		}
		
		//Tach theo dau ,
		char* token = strtok(buff, "  "); 
		int tmp = 0;
	  
		while (token != NULL) { 
			if (tmp == 0) {
				sv[count].stt == token;
			} else if (tmp == 1) {
				sv[count].id == token;
			} else if (tmp == 2) {
				sv[count].hoten == token;
			} else if (tmp == 3) {
				sv[count].sdt == token;
			}
			
			token = strtok(NULL, ","); 
			tmp++;
		} 
		
		count++;
	}
fclose(ptr);

	// Nhap diem
	/*for(int i=0;i<5;i++)
	  {
	    printf("nhap diem sv %s :\n",sv[i].hoten);
	    fflush(stdin);
	    scanf("%lf",&sv[i].diem);
	    fprintf(ptr1,"%5d%10d%20s%12s%7.2f\n",sv[i].stt,sv[i].id,sv[i].hoten,sv[i].sdt,sv[i].diem);
			system("cls");
		}
		fclose(ptr);
		fclose(ptr1);
	  }*/
	// Doc noi dung struct vao bangdiem.txt
	    /*	writeStructToFile(sv[20],ptr1);
	fclose(ptr);
	
	}*/
	
//void ghiFile(FILE *f){
	
	/*f = fopen(a,"w");
	if(f == NULL)
		printf("Khong the mo file.");
	else{*/
		int i;
		fprintf(ptr1,"  STT  MSSV             Ho & Ten     Sdt         Diem\n");
		for(i=0;i<5;i++){
			printf("Nhap diem cho %s: ",sv[i].hoten);
			scanf("%lf", &sv[i].diem);
			fprintf(ptr1,"%5d%10d%20s%12s%7.2f\n",sv[i].stt,sv[i].id,sv[i].hoten,sv[i].sdt,sv[i].diem);
			
		}
		fclose(ptr1);
	}
free(sv);
return 0;
}

//void writeFileToStruct(FILE *fin,struct sinhvien *f){
	//sinhvien sv[10];
	/*int count = 0;
	
	char buff[max];
	while(fgets(buff,max,fin)!=NULL){
		
		if (count = 5) {
			break;
		}
		
		//Tach theo dau ,
		char* token = strtok(buff, "  "); 
		int tmp = 0;
	  
		while (token != NULL) { 
			if (tmp == 0) {
				f[count].stt = token;
			} else if (tmp == 1) {
				f[count].id = token;
			} else if (tmp == 2) {
				f[count].hoten = token;
			} else if (tmp == 3) {
				f[count].sodt = token;
			}
			
			token = strtok(NULL, ","); 
			tmp++;
		} 
		
		count++;
	}
}*/

/*void writeStructToFile(sinhvien sv[20],FILE *fout) {
	
	
	if (fout = fopen("bangdiem.txt", "w")) == NULL) {
		printf("cannot open %s.\n",filename2);
	} else {
		for (int cnt = 0; cnt < 20; cnt++ ) {
			
			// Viet tu string vao file
		}
	}
	}*/
