#include<stdio.h>
enum{success,fail,max=80};

int main(int argc,char *argv[])
{
  FILE *ptr;
  int reval=success;
  
  if(argc==2)
    {
      if((ptr=fopen(argv[1],"r"))==NULL){
	 printf("cannot open %s.\n",argv[1]);
         reval=fail;
      }else{
	readFileLineByLine(ptr);
	fclose(ptr);
      }
    }else if(argc==3)
    {
      if((ptr=fopen(argv[1],"r"))==NULL){
	 printf("cannot open %s.\n",argv[1]);
         reval=fail;
      }else{
	readFilePageByPage(ptr);
	fclose(ptr);
	
     }
    } else{
    printf("input the correct format:mycat <filename> [-p]\n");
    return 1;;
   }
}
	
void readFileLineByLine(FILE *fin)
{
  char buff[max];
  while(fgets(buff,max,fin)!=NULL){
    printf("%s",buff);
  }
}
 void readFilePageByPage(FILE *fin)
 {
   char buff[max];
   int count=0 ;
   int page = 0;
   while(fgets(buff,max,fin)!=NULL){
     count++;
     if(count == 20) //20lines in a page
   {
       count = 0;
       page++;
       printf("%s\n", buff);
       printf("\t\t------------- End of page %d ------------\n\n\n\n", page);
     } else{
       printf("%s", buff);
     }
   }
 }
   
