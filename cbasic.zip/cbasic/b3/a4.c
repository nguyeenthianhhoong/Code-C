#include<stdio.h>
#include<stdlib.h>
int main(void){
  int i,n,*p;
  printf("how many numbers do you want to enter:\n");
  scanf("%d",&n);
  p=(int*)malloc(n*sizeof(int));
  if(p==NULL)
    {
      printf("memory allocation failed\n");
      return 1;
    }
  for(i=0;i<n;i++){
    printf("p[%d]=",i);
    scanf("%d",&p[i]);
  }
  printf("the numbers in reverse order are \n");
  for(i=n-1;i>=0;i--)
    printf("%d",p[i]);
  printf("\n");
  free(p);
  return 0;
}
