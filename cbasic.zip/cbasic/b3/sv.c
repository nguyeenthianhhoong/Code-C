#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
	int stt;
	int mssv;
	float diem;
	char name[30];
	char phone[12];
}SINHVIEN;
SINHVIEN *sv;
int n = -1;
void docFile(char a[]){
	FILE *f;
	f = fopen(a,"r");
	if( f == NULL)
		printf("Khong the mo file.");
	else{
		while(feof(f) == 0){
			n++;
			sv=(SINHVIEN *)realloc(sv,(n+1)*sizeof(SINHVIEN));
			fscanf(f,"%d%d%s%s", &sv[n].stt,&sv[n].mssv,&sv[n].name,&sv[n].phone);
		}
		fclose(f);
	}
}
void ghiFile(char a[]){
	FILE *f;
	f = fopen(a,"w");
	if(f == NULL)
		printf("Khong the mo file.");
	else{
		int i;
		fprintf(f,"  STT  MSSV             Ho & Ten     Sdt         Diem\n");
		for(i=0;i<n;i++){
			printf("Nhap diem cho %s: ",sv[i].name);
			scanf("%f", &sv[i].diem);
			fprintf(f,"%5d%10d%20s%12s%7.2f\n",sv[i].stt,sv[i].mssv,sv[i].name,sv[i].phone,sv[i].diem);
			//system("cls");
		}
		fclose(f);
	}
}
void addsv(int a,FILE *fout){
int i=0;
sv=(SINHVIEN *)realloc(sv,a);
for(int m=i;m<i+a;i++){
printf("mssv:");
scanf("%s",&sv[i].mssv);
printf("name:");
scanf("%s",&sv[i].name);
printf("phone:");
scanf("%s",&sv[i].phone);
printf("diem:");
scanf("%f",&sv[i].diem);
fprintf(fout,"%-5d%-11s%-21s%-11s%-5.2f\n",i,sv[i].mssv,sv[i].name,sv[i].phone,sv[i].diem);
}
i=i+a;

}
int main(){
	char a[10];
	char b[10];
int j;
	printf("Nhap ten file duoc doc: ");
	fflush(stdin);
	gets(a);
	docFile(a);
	printf("Nhap ten file ghi: ");
	fflush(stdin);
	gets(b);
	ghiFile(b);
printf("so sinh vien nhap them:");
scanf("%d",&j);
addsv(j,b);
/*printf("Nhap ten file ghi: ");
	fflush(stdin);
	gets(b);
ghiFile(b);*/
	free(sv);
	return 0;
}
