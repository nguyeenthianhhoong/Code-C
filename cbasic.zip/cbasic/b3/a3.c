#include<stdio.h>
enum{success,fail,max=80};
int main(void){
  FILE *ptr1,*ptr2,*ptr3;
  char filename1[]="1.txt",filename2[]="2.txt",filename3[]="3.txt";
  int reval=success;
  if((ptr1=fopen(filename1,"r"))==NULL){
    printf("cannot open");
    reval=fail;
  }else if((ptr2=fopen(filename2,"r"))==NULL){
    printf("cannot open");
    reval=fail;
    }else if((ptr3=fopen(filename3,"w"))==NULL){
    printf("cannot open");
    reval=fail;
  }else{
    linemerge(ptr1,ptr2,ptr3);
    fclose(ptr1);
        fclose(ptr2);
    fclose(ptr3);
  }return reval;
}
  void linemerge(FILE *f1,FILE *f2,FILE *f3){
    char buff1[max],buff2[max];
    while((fgets(buff1,max,f1)!=NULL)&&(fgets(buff2,max,f2)!=NULL)){
      fputs(buff1,f3);
      fputs(buff2,f3);}
    if(fgets(buff1,max,f1)!=NULL)
      fputs(buff1,f3);
    while(fgets(buff1,max,f1)!=NULL)
      fputs(buff1,f3);
    while(fgets(buff2,max,f2)!=NULL)
      fputs(buff2,f3);
  }

    
