#include<stdio.h>
enum{success,fail,max=80};

int main(void){
  FILE *ptr1,*ptr2;
  char filename1[]="1.txt",filename2[]="2.txt";
  int reval=success;
  if((ptr1=fopen(filename1,"w"))==NULL){
    printf("cannot open %s\n",filename1);
    reval=fail;
  }else if((ptr2=fopen(filename2,"r"))==NULL){
    printf("cannot open %s\n",filename2);
    reval=fail;
  }else{
    linereadwrite(ptr2,ptr1);
    fclose(ptr1);
    fclose(ptr2);
  }return reval;
}
void linereadwrite(FILE *fin,FILE *fout)
{
  char buff[max];
  while(fgets(buff,max,fin)!=NULL){
    fputs(buff,fout);
    printf("%s",buff);
  }
    

}
