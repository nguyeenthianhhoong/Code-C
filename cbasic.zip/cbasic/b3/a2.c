#include<stdio.h>
enum{success,fail,max=80};
int main(void){
  FILE *ptr;
  char filename[]="1.txt";
  int reval=success;
  int c=0;
  if((ptr=fopen(filename,"r"))==NULL){
    printf("cannotopen\n");
    reval=fail;
  }else{
    printf("reading %s.... done\n",filename);
    c=lineread(ptr);
    printf("file has %d line\n",c);
    fclose(ptr);
  }return reval;
}
int lineread(FILE *fin){
  char buff[max],a;
  int count=0;
  while((fgets(buff,max,fin))!=NULL){
      count++;
    printf("%s",buff);
  }
  return count;
}
