#include <stdio.h>
#include <string.h>
int top = -1;
char stack[100];
int push(char a){// them vao stack
    top = top + 1;
    stack[top] = a;
}
int pop(char c, int k){// k == 1 thi lay ki tu dau
    if(k == 1){
        printf("%c", stack[top]);
        top = top - 1;
        return 0;
    }
    while(stack[top] != c){// pop ra cho den khi stack top==c de lau dau ()"
        printf("%c", stack[top]);
        top = top - 1;
    }
    top = top - 1;
}
int xuli(char *a, int h){
    int i;
    for(i = 0; i < h; i++){
        if(a[i] > '9' || a[i] < '0'){
            if(a[i] == ')'){
                pop('(', 0);
            }
            else if(a[i] == '/' || a[i] == '*'){// 2 phep nhan va chia co vai tro nhu nhau nhau
                if(stack[top] == '/' || stack[top] == '*'){
                    pop('a', 1);
                }
                push(a[i]);
            }
            else if(a[i] == '-' || a[i] == '+'){// thu tu uu tien nhan chia truoc
                while(stack[top] == '/' || stack[top] == '*' || stack[top] == '+' || stack[top] == '-'){
                    pop('a', 1);
                }
                push(a[i]);
            }
            else {
                push(a[i]);
            }
        }
        else{
            printf("%c", a[i]);
        }
    }
    while(top != -1){
        printf("%c", stack[top]);
        top = top - 1;
    }
}
int main(){
    char b[100];
    gets(b);
    int h = strlen(b);
    xuli(b, h);

}
