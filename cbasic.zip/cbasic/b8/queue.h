#include<stdio.h>

#define max 100
typedef int elementtype;
typedef struct{
  elementtype elements[max];
  int Front,Rear;
}Queue;

void MakeNull_Queue(Queue *Q){
   Q->Front=-1;
   Q->Rear=-1;
}

int Empty_Queue(Queue Q){
   return Q.Front==-1;
}

int Full_Queue(Queue Q){
   return (Q.Rear-Q.Front+1)==max;
}
//them phan tu vao cuoi(Rear) cua Queue
void EnQueue(elementtype X,Queue *Q){
   if (!Full_Queue(*Q)){
     if (Empty_Queue(*Q)) Q->Front=0;
     Q->Rear=Q->Rear+1;
     Q->elements[Q->Rear]=X;
   }
   else printf("Queue đã đầy!");
}
//xoa phan tu khoi dau(Front) cua Queue 
void DeQueue(Queue *Q){
   if (!Empty_Queue(*Q)){
      Q->Front=Q->Front+1;
      if (Q->Front > Q->Rear)
        MakeNull_Queue(Q);
       // Queue trở thành rỗng
   }
   else printf("Queue bị rỗng!");
}
//lay gia tri o Front
int front(Queue Q){
return Q.elements[Q.Front];
}
