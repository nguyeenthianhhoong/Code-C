#include<stdio.h>
#include<stdlib.h>

 struct list{
  int num;
  struct list *next;
};
typedef struct list stack;


stack *root,*cur,*prev;

stack *makenewnode(int a){
  stack *new=(stack*)malloc(sizeof(stack));
  new->num=a;
  new->next=NULL;
  return new;
}

int empty(){
  return (root==NULL);
}

void push(int a){
  stack* new=makenewnode(a);
  if(root==NULL)
    {root=new;
      cur=root;
    }else{
      new->next=root;
      root=new;
      cur=root;
    }
}

int pop(){
  int a;
  if(empty())
    printf("stack underflow");
  else{
  stack *del=root;
  a=del->num;
  root = del->next;
  free(del);
  cur=root;
  }
  return a;
}


