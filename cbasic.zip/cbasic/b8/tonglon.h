#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX 1000
typedef struct NODE
{
	int x;
	struct NODE *next;
}NODE;
typedef struct LIST
{
	NODE *Head;
}LIST;
NODE *CreatNODE(int x)
{
	NODE *p=(NODE *)malloc(sizeof(NODE));
	if(p==NULL) 
	{
		printf("Loi con tro NULL\n");
		return NULL;
	}
	p->x=x;
	p->next=NULL;
	return p;
}
void Push(LIST *l,int x)
{
	NODE *p=CreatNODE(x);
	if(l->Head==NULL) l->Head=p;
	else
	{
		p->next=l->Head;
		l->Head=p;
	}
}
int Pop(LIST *l)
{
	NODE *p=l->Head;
	if(p==NULL) return -1;
	l->Head=l->Head->next;
	int a=p->x;
	free(p);
	return a;
}
void Free(LIST *l)
{
	while(l->Head!=NULL) Pop(l);
}
void GetLIST(LIST *l,char s[])
{
	for(int i=0;i<strlen(s);i++)
	{
		int a=s[i]-'0';
		if(a<0||a>9)
		{
			Free(l);
			break;
		}
		Push(l,a);
	}
}
void Tong(LIST *l,LIST *l1, LIST *Tong)
{
	int a=0,b=0,dem=0;
	while(1)
	{
		a=Pop(l);
		b=Pop(l1);
		if(a==-1 && b==-1 && dem==0) break;
		if(a==-1) a=0;
		if(b==-1) b=0;
		int c=a+b+dem;
		if(c>9)
		{
			dem=1;
			Push(Tong,c-10);
		}
		else
		{
			dem=0;
			Push(Tong,c);
		}
	}
}

int SoSanh(char s1[],char s2[])
{
  if (strlen(s1)>strlen(s2))
  {
    return 1;
  }
  else if (strlen(s1)<strlen(s2))
  {
    return -1;
  }
  else
  {
    return (strcmp(s1,s2));
  }
}
void Tru(LIST *l,LIST *l1, LIST *Hieu)
{
  int a=0,b=0,dem=0,c;
  while(1)
  {
    a=Pop(l);
    b=Pop(l1);
    if(a==-1 && b==-1&& dem==0) break;
    if(a==-1) a=0;
    if(b==-1) b=0;
    int c=a-b+dem;
    if(c<0)
    {
      dem=-1;
      Push(Hieu,c+10);
    }
    else
    {
      dem=0;
      Push(Hieu,c);
    }
  }
  if (Hieu->Head->next!=NULL &&c==0)
  {
    Pop(Hieu);
  }
}
void In(LIST *l)
{
	NODE  *p = l->Head;
	while(p!=NULL)
	{
		printf("%d",p->x);
		p=p->next;
	}
	free(p);
}