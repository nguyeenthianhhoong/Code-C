#include"queue.h"

int main(){
  int a[5]={5,2,9,3,0};
  int i;
  Queue q;
  MakeNull_Queue(&q);
  for(i=0;i<5;i++)
    EnQueue(a[i],&q);
  printf("all elements in queue\n");
  while(!Empty_Queue(q)){
    printf("%4d\t",front(q));
    DeQueue(&q);
  }
  printf("\n");
  return 0;
}
