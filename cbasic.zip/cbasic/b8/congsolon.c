#include"stackstruct.h"
#include<string.h>

void main(){
  stacktype stack1,stack2,stack3;
  initialize(&stack1);
  initialize(&stack2);
  initialize(&stack3);
  char str1[max],str2[max];
  printf("enter num1:");
  scanf("%s",str1);
  fseek(stdin,0,SEEK_END);
   printf("enter num2:");
  scanf("%s",str2);
  int i=0;
  for(i=0;i<strlen(str1);i++)
    push(str1[i]-48,&stack1);
  for(i=0;i<strlen(str2);i++)
    push(str2[i]-48,&stack2);
  int carry=0,local_sum=0;
  while((!empty(&stack1)) || (!empty(&stack2))){
    local_sum=carry;
    if(!empty(&stack1))
      local_sum+=pop(&stack1);
    if(!empty(&stack2))
      local_sum+=pop(&stack2);
    if(local_sum>=10){
      local_sum-=10;
      carry=1;
    }else(carry=0);
	   push(local_sum,&stack3);
  }
  printf("ketqua:");
  while(!empty(&stack3))
    printf("%d",pop(&stack3));

}
