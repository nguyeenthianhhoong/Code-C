#include "tonglon.h"
int main()
{
	LIST *l=(LIST *)malloc(sizeof(LIST));
	l->Head=NULL;
	LIST *l2=(LIST *)malloc(sizeof(LIST));
	l2->Head=NULL;
	LIST *l3=(LIST *)malloc(sizeof(LIST));
	l3->Head=NULL;
	printf("Nhap so thu nhat: ");
	char s[MAX];
	gets(s);
	GetLIST(l,s);
	printf("Nhap so thu hai: ");
	char s2[MAX];
	gets(s2);
	GetLIST(l2,s2);
	if(l->Head==NULL||l2->Head==NULL) 
	{
		printf("Nhap sai\n");
		return 0;
	}
	Tong(l,l2,l3);
	printf("Tong : ");
	In(l3);
	printf("\n");
	Free(l);
  	Free(l2);
	Free(l3);
	return 0;
}
