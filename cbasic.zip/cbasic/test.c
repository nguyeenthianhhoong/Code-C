#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdio_ext.h>
typedef struct dulieu{
	char khoa[31];
	char nghia[100];
}dulieu;
typedef struct node{
	dulieu dulieu;
	struct node *left;
	struct node *right;
}node;
void addnode(node **root,dulieu dulieu){
	if(*root == NULL){
		node *p = (node *)calloc(1,sizeof(node));
		p->dulieu = dulieu;
		p->left = p->right = NULL;
		*root = p;
	}
	if(strcmp((*root)->dulieu.khoa,dulieu.khoa) > 0) addnode(&(*root)->left,dulieu);
	else if(strcmp((*root)->dulieu.khoa,dulieu.khoa) < 0) addnode(&(*root)->right,dulieu);
}
void docFile(node **root){
	FILE *f = fopen("dict.txt","r");
	if(f == NULL) return ;
	printf("\n------------ NOI DUNG FILE -----\n");
	char a[61];
	dulieu dulieu;
	while(!feof(f)){
		fscanf(f,"%s%s",dulieu.khoa,dulieu.nghia);
		int i;
		for(i=0;i<strlen(dulieu.nghia);i++)
				if(dulieu.nghia[i] == '\n'){
					dulieu.nghia[i]= '\0';
					break;
				}
		if(!feof(f)){
			addnode(root,dulieu);
			printf("\t-%s %s\n",dulieu.khoa,dulieu.nghia);
		}
	}
	fclose(f);
}
void inTree(node *root){
	if(root == NULL) return ;
	inTree(root->left);
	printf("-%s : %s \n",root->dulieu.khoa,root->dulieu.nghia);
	inTree(root->right);
}
node* kiem(node *root,char *a){
	if(root == NULL) return NULL;
	if(strcmp(root->dulieu.khoa,a) == 0) return root;
	else if(strcmp(root->dulieu.khoa,a) >0) return kiem(root->left,a);
	else if(strcmp(root->dulieu.khoa,a) < 0) return kiem(root->right,a);
	return NULL;
}
void dich(node **root){
	char a[200];
	printf("Nhap xau dich:");
	__fpurge(stdin);
	gets(a);
	char c[200];
	char b[200][31];
	
	int i = 0;
	int j =0;
	int t = 0;
	int k = 0; 
	if(a[0] != ' ') c[k++] = a[0];
	for(i = 1;i <strlen(a);i++)
		if(a[i-1] != ' ' || a[i] != ' ') c[k++] = a[i];
	c[k] = '\0';
	i = 0;
	t = 0;
	while(i < strlen(c)){
		if(c[i] != ' '){
			 b[j][t++] = c[i];
			 if(i == strlen(c) - 1) b[j][t] = '\0';
		}
		else{
			if(c[i-1] != ' '){
				b[j][t] = '\0';
				++j;
				t=0;
			}
		}
		++i;
	}
	for(i=0;i<j+1;i++){
		printf("- %s\n",b[i]);
	}
	char *nghia;
	char e[31];
	nghia = (char *)calloc(200,sizeof(char));
	for(i=0;i<j+1;i++){
		if(kiem(*root,b[i]) == NULL){
			printf("Tu \"%s\" chua co , bo sung :", b[i]);
			__fpurge(stdin);
			scanf("%s",e);
			strcat(nghia,e);
			int n = strlen(nghia);
			nghia[n] = ' ';
			nghia[n+1] = '\0';
			dulieu dulieu;
			strcpy(dulieu.khoa,b[i]);
			strcpy(dulieu.nghia,e);
			addnode(root,dulieu);
		}
		else {
			 strcat(nghia,kiem(*root,b[i])->dulieu.nghia);
			 int n = strlen(nghia);
			 nghia[n] = ' ';
			 nghia[n+1] = '\0';
		}
	}
	printf("Nghia cua xau la:%s\n",nghia);
	free(nghia);
}

void them(node **root){
	char new[31];
	printf("-Nhap tu tieng anh can them:");
	scanf("%s",new);
	node *p = kiem(*root,new);
	if(p == NULL){
		dulieu dulieu;
		strcpy(dulieu.khoa,new);
		printf("-Nghia cua tu:");
		scanf("%s",dulieu.nghia);
		addnode(root,dulieu);
	}
	else{
		printf("-Tu da co trong tu dien:\n");
		printf("\t+ Nhap :\'y\' de thay nghia.\n");
		printf("\t+ Nhap :\'n\' de giu nghia cu.\n");
		char c;
		printf("Nhap su lua chon cua ban:");
		__fpurge(stdin);
		scanf("%c",&c);
		if(c == 'y'){
			printf("Nhap nghia:");
			scanf("%s",p->dulieu.nghia);
		}
	}
}
void Free(node **root){
	if(*root == NULL) return ;
	Free(&(*root)->left);
	Free(&(*root)->right);
	free(*root);
}
int main(){
	node **root = (node **)calloc(1,sizeof(node *));
	*root= NULL;
	while(1){
		printf("\n----- MENU -----\n");
		printf("\t1.Doc file.\n");
		printf("\t2.Hien thi cay.\n");
		printf("\t3.Them tu moi.\n");
		printf("\t4.Dihc van ban.\n");
		printf("\t5.Thoat.\n");
		int c;
		printf("Nhap su lua chon:");
		scanf("%d",&c);
		switch(c){
			case 1: docFile(root);
				 break;
			case 2:inTree(*root);
				break;
			case 4:dich(root);
					break;
			case 3:them(root);
				break;
			case 5:Free(root);free(root);return 0;
		}
	}
	return 0;
}
