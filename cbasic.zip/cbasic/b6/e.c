#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef struct{
  char name[31];
  char tel[11];
  char email[50];
}address;
typedef address elementype;
typedef struct list{
  elementype element;
  struct list *next;
}node;

node *root,*cur,*prev; //cac bien toan cuc
node* makeNewNode(elementype e)
{
  node* new=(node*)malloc(sizeof(node));
  new->element=e;
  new->next=NULL;
  return new;
}
void displayNode(node* p)
{
  if(p==NULL)
    {
      printf("Loi con tro NULL\n");
      return;
    }
  elementype tmp=p->element;
  printf("%-33s%-13s%-52s\n",tmp.name,tmp.tel,tmp.email);
}
address readnode()
{
  address tmp;
  printf("name:");gets(tmp.name);
  printf("telnumber:");gets(tmp.tel);
  printf("email:");gets(tmp.email);
  return tmp;
}
//Them node vao dau
void insertAtHead(elementype e)
{
  node* new=makeNewNode(e);
  new->next=root;
  root=new;
  cur=root;
}
void insertAfterCur(elementype e)
{
  node *new=makeNewNode(e);
  
  if(root==NULL)
    {
      root=new;
      cur=root;
    }
  else if(cur==NULL) return;
  else
    {
    new->next=cur->next;
    cur->next=new;
    /*prev=cur*/
    cur=cur->next;
    }
}

void insertBeforeCurrent(elementype e) {
  node *new=makeNewNode(e);
  node *tmp=root;
  
  while(tmp!=NULL && tmp->next!=cur && cur!=NULL)
    tmp=tmp->next;
  prev=tmp;
  if ( root == NULL ) {
    root = new;
    cur = root;
    prev = NULL;
  } else {
    new->next=cur;
    if (cur==root) {
      root = new; 
    }
    else prev->next = new;
    cur = new;
  }
}
void traversingList(){
  node *p;
  for(p=root;p!=NULL;p=p->next)
    displayNode(p);
}
void deleteFirstElement()
{
  node *del=root;
  if (root==NULL)
  {
    return;
  }
  root = del->next;
  free(del);
  cur=root;
}
void deletecur()
{
  node *tmp;
  while(tmp!=NULL && tmp->next!=cur && cur!=NULL)
  {
    tmp=tmp->next;
  }
  prev=tmp;
  if (cur==NULL)
  {
    return ;
  }
  if (cur==root)
  {
    deleteFirstElement();
  }
  else
  {
    prev->next=cur->next;
    free(cur);
    cur=prev->next;
  }
}
node* releaseNode(node* root)
{
node *del = root;
while (del != NULL)
{
root = root->next;
free(del);
del = root;
}
return root;
}
node* list_reserve(node* root)
{
  node *cur,*prev;
  cur=prev=NULL;
  while(root!=NULL)
  {
    cur=root;
    root=root->next;
    cur->next=prev;
    prev=cur;
  }
}
int main(){
  elementype a,b,c,d;
  a=readnode();
  root=makeNewNode(a);
  b=readnode();
  insertAtHead(b);
  c=readnode();
  insertAfterCur(c);
  d=readnode();
  insertBeforeCurrent(d);
  deleteFirstElement();
  deletecur();
  //list_reserve(root);
  //displayNode(root);
  traversingList();
  //releaseNode(root);
  return 0;
}
