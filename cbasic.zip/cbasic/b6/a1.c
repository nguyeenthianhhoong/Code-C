#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct {
  char name[30];
  char tel[11];
  char email[20];
}address;

typedef struct list{
  address addr;
  struct list *next;
}node;
node *root,*cur,*prev;

node *makenewnode(address addr){
  node *new=(node*)malloc(sizeof(node));
  new->addr=addr;
  new->next=NULL;
  return new;
}

address readnode()
{
  address tmp;
    printf("name:");
    scanf("%s",&tmp.name);
    printf("tel:");scanf("%s",&tmp.tel);
    printf("email:");scanf("%s",&tmp.email);
    return tmp;
  }

void displaynode(node *p){
  if(p==NULL){
    printf("Loi con tro\n");
    return;
  }
  address tmp=p->addr;
  printf("%-30s%-12s%-30s\n",tmp.name,tmp.tel,tmp.email);
}

void insertathead(address addr){
  node *new=makenewnode(addr);
  new->next=root;
  root=new;
  cur=root;
}

void insertaftercur(address addr){
  node *new=makenewnode(addr);
  if(root==NULL){
    root=new;
    cur=root;
  }else if(cur==NULL){

    return;
}
  else{

  new->next=cur->next;
  cur->next=new;
  //cur->next=cur;
  }
  
}

void insertbeforecur(address addr){
  node *new=makenewnode(addr);
  node *tmp=root;
  while(tmp!=NULL && tmp->next!=cur && cur!=NULL)
     tmp=tmp->next;
  prev=tmp;
    
  if(root==NULL){
    root=new;
    cur=root;
    prev=NULL;
  }else {
    new->next=cur;
    if(cur=root)
      root=new;
    else {
      prev->next=new;
      cur=new;
    }
  }

}

void deletefirstelement(){
  node *del=root;
  if(root==NULL)
    return;
  root=del->next;
  free(del);
  cur=root->next;
}

void deletecur(){
  node *tmp;
  while(tmp!=NULL && tmp->next!=cur && cur!=NULL)
    tmp=tmp->next;
  prev=tmp;
  if(cur==NULL)
    return;
  else if(cur==root)
    deletefirstelement();
  else{
    prev->next=cur->next;
    free(cur);
    cur=prev->next;
  }
}
//xoa toan bo
node* releasenode(node* root){
  node *del=root;
  while(del!=NULL){
    root=root->next;
    free(root);
    del=root;
  }
printf("done!!\n");
  return root;
}

void traversinglist(){
  node *p;
  for(p=root;p!=NULL;p=p->next)
    displaynode(p);
}

node* list_reserve(node* root){
  node *cur,*prev;
  cur=prev=NULL;
  while(root!=NULL)
    {
      cur=root;
      root=root->next;
      cur->next=prev;
    }
  
}

int main(){
  address a,b,c,d;
  a=readnode();
  root=makenewnode(a);
  b=readnode();
  insertathead(b);
c=readnode();
  insertaftercur(c);
d=readnode();
  insertbeforecur(d);
  //deletefirstelement();
  //deletecur();
  //displaynode(root);
  //printf("--------------\n");
  traversinglist();
  releasenode(root);
  return 0;

}



