#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct {
  char name[20];
  char tel[11];
  char email[25];
}address;
typedef address elementtype;
//typedef struct node node;
typedef struct list{
  elementtype element;
  struct list *next;
}node;
node* root;
node* cur,*prev;

node *makenewnode(elementtype e){
  node *new=(node*)malloc(sizeof(node));
  new->element=e;
  new->next=NULL;
  return new;
}
elementtype readdata(){
  elementtype e;
  printf("name:");
  scanf("%s",&e.name);
  printf("tel:");
  scanf("%s",&e.tel);
  printf("email:");
  scanf("%s",&e.email);
}

void printdata(node* p){
if(p==NULL){
printf("loi con tro\n");
return;
}
elementtype e=p->element;
  printf("%-15s%-10s%-20s\n",e.name,e.tel,e.email);
}

void traversinglist(){
  node* p;
  for(p=root;p!=NULL;p=p->next)
    printdata(p);
}


void insertathead(elementtype e){
  node *new=makenewnode(e);
  new->next=root;
  root=new;
  cur=root;
}
void insertaftercurrent(elementtype e){
  node* new= makenewnode(e);
  if(root==NULL){
    root=new;
    cur=root;
  } else {
    new->next=cur->next;
    cur->next=new;
    //cur =cur->next;
  }
}
void insertbeforcurrent(elementtype e){
  node* new= makenewnode(e);
  node* tmp=root;
  while(tmp!=NULL && tmp->next!=cur && cur!=NULL)
    tmp=tmp->next;
  prev=tmp;
  if(root==NULL){
    root=new;
    cur=root;
    prev=NULL;
  } else {
    new->next=cur;
    if(cur==root){
      root=new;
    }else{
      prev->next=new;
      cur =new;
    }
  }
}


void deletefirstelement(){
  node *del=root;
  if(root==NULL)
    return;
  root = del->next;
  free(del);
  cur=root;
}

void deletecur()
{
  node *tmp;
  while(tmp!=NULL && tmp->next!=cur && cur!=NULL)
    tmp=tmp->next;
  prev=tmp;
  if (cur==NULL)
    return ;
  if (cur==root)
    deletefirstelement();
  else
  {
    prev->next=cur->next;
    free(cur);
    cur=prev->next;
  }
}

node* releaseNode(node* root)
{
    node *del = root;
    while (del != NULL)
    {
      root = root->next;
      free(del);
      del = root;
    }
    return root;
}

int main(){
  elementtype a,b,c,d;
   a=readdata();
   root=makenewnode(a);
   b=readdata();
   insertathead(b);
   c=readdata();
   insertbeforcurrent(c);
   d=readdata();
   insertaftercurrent(d);
   //printdata(a);
   traversinglist();
   return 0;
}
