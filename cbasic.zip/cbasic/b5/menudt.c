#include<stdio.h>
#include<stdlib.h>
#include<string.h>
enum{success,fail,max=20};
typedef struct phone_t{
  char model[20];
  char memory[6];
  char inch[8];
  char price[20];
}phone;

int main(){
  FILE *f,*f1;
  char modeltim[20];
  int reval=success,dem=0;
  phone *p=malloc(max* sizeof(phone));
  int choice,choice1;
  int i=0,irc,j;
  if((f=fopen("phoneDB.txt","r"))==NULL){
    printf("cannot open file");
    reval=fail;
  }
     while(!feof(f))
		  {
		    fscanf(f,"%s %s %s %s",p[i].model,p[i].memory,p[i].inch,p[i].price);
		    i++;	   
		  }
	//i++;
  fclose(f);
  
  
  if((f1=fopen("phoneDB.dat","w+b"))==NULL){
    printf("cannot open file");
    reval=fail;
    }

  do{
        printf("MENU\n");
        printf("1. Import DB from text\n");
        printf("2. Import from DB\n");
        printf("3. Print all database\n");
        printf("4. Search phone\n");
        printf("5. Quit\n");
        
        do{
            printf("Input a choice: ");
scanf("%d", &choice);
        } while (choice < 1 || choice > 5);
        
        switch(choice){
            case 1:
	     
	       irc=fwrite(p,sizeof(phone),max,f1);
	      printf("fwrite return code:%d\n",irc);
	    
                break;
            case 2:
	      printf("ban muon doc:\n");
              printf("1. toan phan\n2. mot phan tu dau\n3.mot phan tu cuoi\n");
              printf("choice:");
              scanf("%d",&choice1);
	      // printf("model\t\t\t\tmemory\t\tinch\t\tprice\n");
              if(choice1==1){
		 printf("model\t\t\t\tmemory\t\tinch\t\tprice\n");
                for(i=0;i<max;i++){
	            printf("%-33s%-15s%-15s%-10s\n",p[i].model,p[i].memory,p[i].inch,p[i].price);
		}
              }
              if(choice1!=1){
                printf("nhap so model muon doc:");
                scanf("%d",&j);
		 printf("model\t\t\t\tmemory\t\tinch\t\tprice\n");
                if(choice1==2){
                  for(i=0;i<j;i++)
                      printf("%-33s%-15s%-15s%-10s\n",p[i].model,p[i].memory,p[i].inch,p[i].price);
	      
		}
                if(choice1==3){
                   for(i=max-1;i>max-j-1;i--)
                       printf("%-33s%-15s%-15s%-10s\n",p[i].model,p[i].memory,p[i].inch,p[i].price);
		}
	      }
               
                break;
            case 3:
	     
	      printf("model\t\t\t\tmemory\t\tinch\t\tprice\n");
	       for(i=0;i<max;i++){
	      printf("%-33s%-15s%-15s%-10s\n",p[i].model,p[i].memory,p[i].inch,p[i].price);
	      }
               
                break;
            case 4:
	      printf("enter model:");
	      scanf("%s",&modeltim);
	      for(int i=0;i<max;i++)
          {
	    if(strcmp(p[i].model,modeltim)==0){
	printf("model\t\t\t\tmemory\t\tinch\t\tprice\n");
	printf("%-33s%-15s%-15s%-10s\n",p[i].model,p[i].memory,p[i].inch,p[i].price);
	dem++;
      }
	    }
	     if(dem==0){
	      printf("not find model\n");
    }
                
                break;
            case 5:
        
                break;
        }
    } while (choice != 5);
  fclose(f1);
  free(p);


}
