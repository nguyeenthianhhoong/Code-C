#include<stdio.h>
#include<stdlib.h>
#include<string.h>
enum{success,fail,max=20};

typedef struct address_t{
  char name[20];
  char tel[11];
}address;

struct list{
  address addr;
  struct list *next;
};
typedef struct list node;
node *root,*cur,*prev;

void readnode()
{
  struct list *p=root;
  while(p!=NULL)
    {
      //printf("%d\t\t%d",p->addr->name,p->addr->tel);
      p=p->next;
    }
}

node *newnode(address addr)
{
  node *new=(node*)malloc(sizeof(node));
  new->addr=addr;
  new->next=NULL;
  return new;
}
void displaynode(node* p,address addr){
  if(p==NULL){
    printf("loi con tro\n");
    return ;
  }
  address addr=p->addr;
 
  while(p!=NULL){
  printf("%-20s%-15s\n",tmp.name,tmp.tel);
 
  }
}


int main(){
  FILE *f;
  address tmp;
  struct list *pa;
  
  int reval=success,i=0;
  if((f=fopen("phone.dat","rb"))==NULL){
    printf("cannot open phone.dat");
    reval=fail;
  }
  while(!feof(f))
    {
      pa=malloc(sizeof(struct list));
      fread(pa,sizeof(struct list),1,f);
      pa->next=root;
      root=pa;

    }
  fclose(f);
 
  tmp==readnode();
  root=newnode(tmp);
  displaynode(root,tmp);
  //free(addr);
  




}
