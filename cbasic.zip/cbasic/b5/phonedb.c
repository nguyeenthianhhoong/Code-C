#include<stdio.h>
enum{success,fail,max=20};
typedef struct phone_t{
  char model[20];
  char memory[10];
  float inch;
  char price[15];
}phone;

int main(){
  FILE *f;
  phone p[max];
  int i,irc,reval=success;
  for(i=0;i<max;i++){
    printf("model:");
    scanf("%s",&p[i].model);
    printf("memory:");
    scanf("%s",&p[i].memory);
    printf("inch:");
    scanf("%f",&p[i].inch);
    printf("price:");
    scanf("%s",&p[i].price);
  }
  if((f=fopen("phoneDB.txt","w"))==NULL){
    printf("cannot open file");
    reval=fail;
  }
  irc=fwrite(p,sizeof(phone),max,f);
  printf("fwrite return code:%d\n",irc);
  fclose(f);
  return reval;



}
