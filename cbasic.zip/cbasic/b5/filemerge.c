#include<stdio.h>
enum{success,fail,max=20};
typedef struct phonebook_t{
  char name[40];
  char tel[11];
}phonebook;


int main(int argc,char* argv[]){
  FILE *f,*f1,*f2;
  int n,i,reval=success,irc;
  if(argc!=4){
    printf("wrong!!correct syntax:filemerge <file1> <file2> <filemerge>\n");
    return 1;
  }
  printf("n=");
  scanf("%d",&n);
  phonebook pa1[n],pa2[max-n];
  if((f=fopen(argv[3],"w+b"))==NULL){
    printf("cannot open file");
    reval=fail;
  }
  if((f1=fopen(argv[1],"rb"))==NULL){
    printf("cannot open file");
    reval=fail;
  }
  for(i=0;i<n;i++){
    fread(&pa1[i].name,40,1,f1);
    fread(&pa1[i].tel,11,1,f1);
  }
  irc=fwrite(pa1,sizeof(phonebook),n,f);
  printf("fwrie %s into %s return code:%d",argv[1],argv[3],irc);
  printf("\tdone!!\n");
  fclose(f1);

   if((f2=fopen(argv[2],"rb"))==NULL){
    printf("cannot open file");
    reval=fail;
  }

  for(i=0;i<max-n;i++){
    fread(&pa2[i].name,40,1,f2);
    fread(&pa2[i].tel,11,1,f2);
  }
  if (fseek(f,n * sizeof(phonebook),SEEK_SET)!=0){
    printf("fseek failed");
    return fail;
  }
  irc=fwrite(pa2,sizeof(phonebook),max-n,f);
  printf("fwrite %s into %s return code:%d",argv[2],argv[3],irc);
  printf("\tdone!!\n");
  fclose(f2);
  
  fclose(f);
  return 0;



}
