#include<stdio.h>
#include<stdlib.h>
enum{success,fail,max=10};
int main(int argc,char* argv[])
{
  FILE *f,*f1,*f2;
  int n,i,reval=success,irc;
  if(argc!=5)
    {
      printf("wrong!!correct syntax:filesplit <file> <n> <filesplit1> <filesplit2>\n");
      return 1;
    }
    n=atoi(argv[3]);
  if((f=fopen(argv[1],"rb"))==NULL){
    printf("cannot open file\n");
    reval=fail;
  }
  if((f1=fopen(argv[4],"w+b"))==NULL){
    printf("cannot open file\n");
    reval=fail;
  }
  irc=fwrite(f,sizeof(FILE),40*n+11*n,f1);
  printf("fwrite filesplit1 return code=%d\n",irc);
   printf("done!!\n");
   fclose(f1);

   fseek(f,40*n+11*n,SEEK_SET);
   if((f2=fopen(argv[5],"w+b"))==NULL){
    printf("cannot open file\n");
    reval=fail;
    }
   fwrite(f,sizeof(FILE),40*(max-n)+11*(max-n),f2);
   printf("fwrite filesplit2 return code=%d\n",irc);
   printf("done!!\n");
   fclose(f2);
   fclose(f);
   return 0;
}
