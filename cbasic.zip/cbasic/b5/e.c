#include<stdio.h>

enum{success,fail,max=20};

typedef struct phonebook_t{
  char name[40];
char tel[11];
}phonebook;

int main(){
  FILE *f;
  phonebook pa[max];
  int i,irc,reval=success;
  printf("nhap du lieu:\n");
  for(i=0;i<max;i++){
    printf("enter name:");
    scanf("%s",&pa[i].name);
    printf("enter tel:");
    scanf("%s",&pa[i].tel);
  }
  if((f=fopen("phonebook.dat","w+b"))==NULL){
    printf("cannot open file");
    reval=fail;
  }
  irc=fwrite(pa,sizeof(phonebook),max,f);
  fclose(f);
  
  if((f=fopen("phonebook.dat","rb"))==NULL){
    printf("cannot open file");
    reval=fail;
  }
  irc=fread(pa,sizeof(phonebook),max,f);
  for(i=0;i<max;i++){
    printf("%s\t\t",pa[i].name);
printf("%s\n",pa[i].tel);
    }
  fclose(f);
  return reval;
  


}
