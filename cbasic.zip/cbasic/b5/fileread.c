#include<stdio.h>
enum{success,fail,max=20};

typedef struct phonebook_t{
  char name[40];
  char tel[11];
}phonebook;

int main(){
  FILE *f1,*f2;
  int i,reval=success,irc;
  int n;
  // phonebook pa1[max],pa2[max];
   printf("enter n=");
  scanf("%d",&n);
 phonebook pa1[n],pa2[max-n];
  if((f1=fopen("phone1.dat","rb"))==NULL){
    printf("cannot open file");
    reval=fail;
  }

  printf("read phone1.dat\n");
   for(i=0;i<n;i++){
    fread(&pa1[i].name,40,1,f1);
    printf("%s\t\t",pa1[i].name);
    fread(&pa1[i].tel,11,1,f1);
    printf("%s\n",pa1[i].tel);
    }
   /* irc=fread(pa1,sizeof(phonebook),1,f1);
      printf("fread return code:%d",irc);*/
  fclose(f1);

    printf("-----------------------------------------------------\n");
 
  
  if((f2=fopen("phone2.dat","rb"))==NULL){
    printf("cannot open file");
    reval=fail;
    }
  printf("read phone2.dat\n");
  for(i=0;i<max-n;i++){
    fread(&pa2[i].name,40,1,f2);
    printf("%s\t\t",pa2[i].name);
    fread(&pa2[i].tel,11,1,f2);
    printf("%s\n",pa2[i].tel);
  }
  fclose(f2);
  return 0;


}
