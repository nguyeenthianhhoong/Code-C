#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <string.h>
/* Definition of function named sentenceGenerator */
void sentenceGenerator(char *article[],  char *noun[], char *verb[],char *preposition[]);

	/* Function main begins program execution */
int main()
	{
	  int i;
	  char *article[5] = { "the", "a", "one", "some", "any"};   /* Declaration of array article */
	 
	  char *noun[5] = { "boy", "girl", "dog", "town", "car"};   /* Declaration of array noun */

	  char *verb[5] = { "drove","jumped", "ran", "walked", "skipped"}; /* Declaration of array verb */

	  char *preposition[5] = { "to", "from", "over", "under", "on"}; /* Declaration of array preposition */
	  while(i=0;i <= 7;;i++){
	       sentenceGenerator( article, noun, verb, preposition );
	  }
	  system ("pause");
	  return 0;              /* Indicates successful termination */
	}
	/* Function Prototype */
void sentenceGenerator(char *article[],  char *noun[],char *verb[],char *preposition[])
      {
	  char sentence[];                                 
	  sprintf("%s %s %s %s %s %s.",                        
	             article        [srand(time( NULL)) % 5],          
	             noun          [srand(time( NULL)) % 5],
	             verb          [srand(time( NULL)) % 5],
	             preposition    [srand(time( NULL)) % 5],
	             article        [srand(time( NULL)) % 5],
	             noun          [srand(time( NULL)) % 5]);
	  sentence[0] = toupper( sentence[0] );                
	  
      }
