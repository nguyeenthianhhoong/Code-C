#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct menu
{
    char id[10];
    char tenmon[30];
    char soluong[10];
    char giatien[30];
} menu;
int readfile(FILE *fptr, menu data[])
{
    char s[80];
    int i = 1;
    while (fgets(s, 81, fptr) != NULL)
    {
        int count = 0;
        char *tmp;
        tmp = strtok(s, ",");
        while (tmp != NULL)
        {
            if (count == 0)
            {
                strcpy(data[i].id, tmp);
            }
            if (count == 1)
            {
                strcpy(data[i].tenmon, tmp);
            }
            if (count == 2)
            {
                strcpy(data[i].soluong, tmp);
            }
            if (count == 3)
            {
                strcpy(data[i].giatien, tmp);
            }
            count++;
            tmp = strtok(NULL, ",");
        }
        i++;
    }

    for (int k = 1; k < i; k++)
    {
        printf("%s %s %s %s\n", data[k].id, data[k].tenmon, data[k].soluong, data[k].giatien);
    }
    printf("Readfile successfull!");
    return i;
}
void swap(menu *x1, menu *x2)
{
    menu tmp = *x1;
    *x1 = *x2;
    *x2 = tmp;
}
void adjust(menu data[], int i, int size)
{
    int j;
    menu copy;
    int Number;
    int Reference = 1;
    Number = size;
    while (2 * i <= Number && Reference == 1)
    {
        j = 2 * i;
        if (j + 1 <= Number && strcmp(data[j + 1].giatien, data[j].giatien) > 0)
            j = j + 1;
        if (strcmp(data[j].giatien, data[i].giatien) < 0)
            Reference = 0;
        else
        {
            swap(&data[i], &data[j]);
            i = j;
        }
    }
}
void MakeHeap(menu data[], int size)
{
    int i;
    int k = size;
    for (i = size / 2; i >= 1; i--)
    {
        adjust(data, i, size);
    }
}
int main()
{
    FILE *fptr = fopen("menu.txt", "r+");
    menu data[100];
    int k, size;
    k = size = readfile(fptr, data);
    MakeHeap(data, k-1);
    while (k > 1)
    {
        int x = k;
        swap(&data[1], &data[x]);
        k--;
        adjust(data, 1, k-1);
    }
    printf("after while size =%d\n", size);
    for (int k = 2; k<=size; k++)
    {
        printf("%s %s %s %s\n", data[k].id, data[k].tenmon, data[k].soluong, data[k].giatien);
    }

    fclose(fptr);
    return 0;
}