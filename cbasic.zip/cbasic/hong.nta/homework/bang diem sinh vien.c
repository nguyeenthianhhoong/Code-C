#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct{
	int stt;
	int mssv;
	float diem;
	char ten[30];
	char sdt[12];
}SINHVIEN;
SINHVIEN *sv;
int n = -1;
void docFile(char a[]){
	FILE *f;
	f = fopen(a,"r");
	if( f == NULL)
		printf("Khong the mo file.");
	else{
		while(feof(f) == 0){
			++n;
			sv=(SINHVIEN *)realloc(sv,(n+1)*sizeof(SINHVIEN));
			fscanf(f,"%d%d%s%s", &sv[n].stt,&sv[n].mssv,&sv[n].ten,&sv[n].sdt);
		}
		fclose(f);
	}
}
void ghiFile(char a[]){
	FILE *f;
	f = fopen(a,"w");
	if(f == NULL)
		printf("Khong the mo file.");
	else{
		int i;
		fprintf(f,"  STT  MSSV             Ho & Ten          Sdt         Diem\n");
		for(i=0;i<n;i++){
			printf("Nhap diem cho %s: ",sv[i].ten);
			scanf("%f", &sv[i].diem);
			fprintf(f,"%3d%12d%20s%17s%7.2f\n",sv[i].stt,sv[i].mssv,sv[i].ten,sv[i].sdt,sv[i].diem);
			system("cls");
		}
		fclose(f);
	}
}
int main(){
	char a[10];
	char b[10];\
	printf("Nhap ten file duoc doc: ");
	fflush(stdin);
	gets(a);
	docFile(a);
	printf("Nhap ten file ghi: ");
	fflush(stdin);
	gets(b);
	ghiFile(b);
	free(sv);
	return 0;
}
