#include<stdio.h>
#include<stdlib.h>
#include<string.h>

enum{success,fail};

typedef struct {
  char model[20];
  char memory[6];
  char inch[8];
  char price[20];
}phone;

typedef struct list{
  phone data;
  struct list *next;
}node;

node *root,*cur,*prev;

node *makenewnode(phone data){
  node *new=(node*)malloc(sizeof(node));
  new->data=data;
  new->next=NULL;
  return new;
}

void insertathead(phone data){
  node *new=makenewnode(data);
  new->next=root;
  root=new;
  cur=root;
}

void insertaftercur(phone data){
  node *new=makenewnode(data);
  if(root==NULL){
    root=new;
    cur=root;
  }else if(cur==NULL){

    return;
}
  else{

  new->next=cur->next;
  cur->next=new;
  //cur->next=cur;
  cur=new;
  }
  
}

void displaynode(node *p){
  if(p==NULL){
    printf("Loi con tro\n");
    return;
  }
  phone tmp=p->data;
  printf("%-33s%-8s%-20s%-10s\n",tmp.model,tmp.memory,tmp.inch,tmp.price);
}

void traversinglist(){
  node *p;
  for(p=root;p!=NULL;p=p->next)
    displaynode(p);
}


void docfiletext(FILE *fin){
  phone data;
  while(!feof(fin)){
    fscanf(fin,"%s %s %s %s",data.model,data.memory,data.inch,data.price);
    insertathead(data);
    
  }
}

void docfiledat(FILE *fin){
  phone data;
  while(!feof(fin)){
    fread(&data.model,20,1,fin);
    fread(&data.memory,6,1,fin);
    fread(&data.inch,8,1,fin);
    fread(&data.price,20,1,fin);
    insertaftercur(data);
  }
}

void searchmodel(node *root){
 
  char modeltim[30];
  //phone data;
  printf("search model phone:");
  scanf("%s",&modeltim);
  for(node *p=root;p!=NULL;p=p->next){
int check=strcmp((p->data).model,modeltim);
    if(check==0){
      displaynode(p);
     
    }
  }
  //if(check!=0)
   // printf("cannot find\n");
}

void writetofiledat(FILE *fout){
  node *p;
  // phone a=p->data;
  for(p=root;p!=NULL;p=p->next){
    fwrite(p,1,sizeof(phone),fout);
  }

}
  
int main(){
  FILE *f,*f1,*f2;
  int reval=success;
  int choice;
  char modeltim[30];
   if((f=fopen("phoneDB.txt","r"))==NULL){
    printf("cannot open file");
    reval=fail;
  }
   if((f1=fopen("phoneDB.dat","rb"))==NULL){
     printf("cannot open file");
     reval=fail;
   }
   if((f2=fopen("phone.dat","w+b"))==NULL){
     printf("cannot open file");
     reval=fail;
   }
  
 do{
        printf("MENU\n");
        printf("1. Import from text\n");
        printf("2. Import from dat\n");
        printf("3. Display list\n");
        printf("4. Search phone by model\n");
	printf("5. Search phone by price(under value inputed)\n");
	printf("6. Export to dat\n");
	printf("7. Manual insertion\n");
	printf("8. Quit\n");
        
        do{
            printf("Input a choice: ");
scanf("%d", &choice);
        } while (choice < 1 || choice > 8);
        
        switch(choice){
            case 1:
	      docfiletext(f);
	      printf("import done!!!\n");
	      //traversinglist();
	      fclose(f);
	     break;
            case 2:
	      docfiledat(f1);
	      printf("import done!!!\n");
	      //traversinglist();
	      fclose(f1);
	      
                break;
            case 3:
	      printf("model\t\t\t\tmemory\tinch\t\t\tprice\n");
	      traversinglist();
               
                break;
            case 4:
	      
	      searchmodel(root);
                
                break;
            case 5:
        
                break;
	     case 6:
	       writetofiledat(f2);
	       printf("fwrite done!!!\n");
	       fclose(f2);
	        break;
             case 7:

	       
	        break;
	     case 8:
	       
	        break;
        }
    } while (choice != 8);
 

}
