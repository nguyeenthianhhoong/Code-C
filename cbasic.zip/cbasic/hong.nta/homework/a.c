#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ID_LENGTH 8
#define NAME_LENGTH 20
typedef struct Student_t {
char id[ID_LENGTH];
char name[NAME_LENGTH];
int grade;
struct Student_t* next;
} Student;
Student* head = NULL, * current = NULL, * tail = NULL, * stu = NULL;
Student* makeANewNode() {
// Tao mot node moi
Student* newNode = (Student*)malloc(sizeof(Student));
printf("Nhap thong tin lien he:\n");
printf("\tID: ");
fflush(stdin);
gets(newNode->id);
printf("\tTen: ");
fflush(stdin);
gets(newNode->name);
printf("\tDiem: ");
fflush(stdin);
scanf(" %d", &newNode->grade);newNode->next = NULL;
return newNode;
}
void insertStudent(Student* toAdd) {
// Xep node vao dung vi tri theo thu tu diem giam dan
Student* prev = head;
if (head == NULL)
head = tail = toAdd;
else if (toAdd->grade > head->grade) {
toAdd->next = head;
head = toAdd;
}
else {
current = head;
while (current != NULL && toAdd->grade < current->grade) {
prev = current;
current = current->next;
}
prev->next = toAdd;
toAdd->next = current;
}
}
Student* searchStudent() {
// Tim sinh vien bang ID
char IDD[ID_LENGTH];
current = head;
printf("Nhap ID sinh vien muon tim: ");
fflush(stdin);
gets(IDD);
while (current != NULL && strcmp(IDD, current->id) != 0) {current = current->next;
}
return current;
}
void deleteStudent() { // Xoa sinh vien tim bang ID
char IDD[ID_LENGTH];
current = head;
Student* prev = NULL;
printf("Nhap ID sinh vien muon xoa: ");
fflush(stdin);
gets(IDD);
while (current != NULL && strcmp(IDD, current->id) != 0) {
prev = current;
current = current->next;
}
if (current == NULL) {
printf("ID khong hop le!\n");
}
else {
if (current == head) {
Student* del = head;
head = del->next;
free(del);
}
else {
prev->next = current->next;
}
printf("Thuc hien thanh cong!\n");}
}
void showAllList() {
// Duyet va in ra toan bo danh sach
if (head == NULL) {
printf("Danh sach rong, hay tao danh sach moi!\n");
}
else {
current = head;
printf("ID\tTen\tDiem\n");
while (current != NULL) {
printf("%s\t%s\t%d\n", current->id, current->name, current->grade);
current = current->next;
}
}
}
void creatList() {
// Tao 1 danh sach moi & xoa toan bo danh sach cu (neu co)
if (head != NULL) {
// Xoa toan bo danh sach cu (neu co)
Student* toFree = head;
while (toFree != NULL) {
head = head->next;
free(toFree);
toFree = head;
}
}
int n;
printf("Nhap so sinh vien muon them: ");
scanf(" %d", &n);for (int i = 0; i < n; i++) {
Student* studentInfor = NULL;
studentInfor = makeANewNode();
insertStudent(studentInfor);
}
printf("Thuc hien thanh cong!\n");
}
void showMenu() {
// In ra menu co cac chuc nang
printf("\nMENU\n");
printf("1. Hien thi toan bo danh sach\n");
printf("2. Tao danh sach moi\n");
printf("3. Chen sinh vien\n");
printf("4. Tim sinh vien\n");
printf("5. Xoa sinh vien\n");
printf("6. Thoat\n");
printf("\nNhap lua chon: ");
int option;
scanf(" %d", &option);
switch (option)
{
case 1:
showAllList();
showMenu();
break;
case 2:
creatList();
showMenu();
case 3:
stu = makeANewNode();insertStudent(stu);
printf("Thuc hien thanh cong!\n");
showMenu();
break;
case 4:
current = searchStudent();
if (current == NULL) {
printf("ID khong hop le!\n");
}
else {
printf("ID\tTen\tDiem\n");
printf("%s\t%s\t%d\n", current->id, current->name, current->grade);
}
showMenu();
break;
case 5:
deleteStudent();
showMenu();
break;
case 6:
exit(0);
break;
default:
printf("Sai lua chon!\n");
showMenu();
break;
}
}
void main() {showMenu();
}
