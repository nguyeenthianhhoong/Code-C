#include<stdio.h>
enum{success,fail,max_len=81};

int main(void)
{
  FILE *fptr1;
  char filename1[]="1.txt";
  int reval=success;
  int c=0;
  if((fptr1=fopen(filename1,"r"))==NULL){
    printf("cannot open %s.\n",filename1);
    reval=fail;
  } else {
    printf("reading file %s... done!\n",filename1);
    c=linereadwrite(fptr1);
    printf("the file has %d line\n",c);
    fclose(fptr1);
  }return reval;
}
int linereadwrite(FILE *fin)
{
  char buff[max_len];
  int count=0;
  while (fgets(buff,max_len,fin)!=NULL){
   
     printf("%s",buff);
     count++;
  }
  return count;
}
  
