#include "stdio.h"
#include "stdlib.h"
#include "string.h"

const int MAX_LEN = 1000;
const int NUM_WORD = 100;
const int NAME_LEN = 50;

// ham check tu hoa
// tra ve 1 neu la ten rieng
// tra ve 0 neu nguoc lai
int checkTenRieng(char* word)
{
	///
	return 0;
}

// ham tim ten rieng va tra ve mang ten rieng
// mang retval chua cac ten rieng tra ve
// n la so luong
void timTenRieng(char *str, char ***retval, int *n)
{
	int i;
	// cap phat muc 1(muc char [][]
	(*retval) = (char**)calloc(NUM_WORD, sizeof(char*));
	// cap phat muc 2 (muc char[])
/*	for (int i = 0; i < NUM_WORD; i++)
		(*retval)[i] = (char*)calloc(NAME_LEN, sizeof(char));
		*/
	// chuyen tat ca cac dau cau ve cach trong
	for (int i = 0; i < strlen(str); i++)
		if (str[i] == '.' || str[i] == ',') str[i] = ' ';

	*n = 0;
	i = 0;
	while (i < strlen(str))
	{
		while (str[i] == ' ')i++;
		int j = i + 1;
		while (j < strlen(str) && j != ' ') j++;

		// cap phat 1 tu moi
		char *word = (char*)calloc(NAME_LEN, sizeof(char));
		// copy tung ky tu
		int k;
		for (k = i; k <= j; k++)
		{
			word[k - i] = str[i];
		}
		
		if (j < strlen(str))
			word[k-1] = '\0';
		else
			word[k] = '\0';
		if(checkTenRieng(word)>0)
		{
			// gan vao danh sach
			(*retval)[*n] = word;
			(*n)++;
		}
		else
			free(word);
		
	}
	

}
int main132()
{
	char* str;
	str = (char*)malloc(MAX_LEN * sizeof(char));
	printf("Nhap vao van ban: ");
	gets_s(str, MAX_LEN);


	system("pause");
	return 0;
}