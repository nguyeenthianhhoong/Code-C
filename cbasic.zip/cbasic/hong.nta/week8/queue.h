#include<stdio.h>

#define max 100
typedef int elementtype;
typedef struct{
  elementtype element[max];
  int front,rear;
}queue;

void makenull_queue(queue *q){
  q->front=-1;
  q->rear=-1;
}

int empty_queue(queue q){
  return q.front==-1;
}

int full_queue(queue q){
  return (q.rear-q.front+1)==max;
}

void enqueue(elementtype x,queue *q){
  if(!full_queue(*q)){
    if(empty_queue(*q))
      q->front=0;
    q->rear=q->rear+1;
    q->element(q->rear)=X;
  }
  else printf("queue is full");
  
}

void dequeue(queue *q){
  if(!empty_queue(*q)){
    q->front=q->front+1;
    if(q->front>q->rear)
      makenull_queue(Q);
  }
  else printf("queue is empty");
}
