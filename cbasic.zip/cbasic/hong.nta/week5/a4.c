#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct address_t {
  char name[20];
  char tel[11];
  char email[25];
}address;

struct list_el
{
  address addr;
  struct list_el *next;
};
typedef struct list_el node_addr;

node_addr *root,*cur,*prev;
node_addr *makenewnode()
{
  node_addr *new=(node_addr*)malloc(sizeof(node_addr));
 
  //new->addr = addr;
  new->next = NULL;
  return new;

}

int main(){
new=makenewnode


}
