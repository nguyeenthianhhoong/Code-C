#include<stdio.h>
typedef struct address_t {
  char name[20];
  char tel[11];
  char email[25];
}address;

struct list_el{
  address addr;
  struct list_el *next;
};
typedef struct list_el node_addr;

node_addr *root,*cur,*prev; //khai bao 3 bien toan cuc
node_addr *makenewnode()
{
  node_addr *new=(node_addr*)malloc(sizeof(node_addr));
 
  //new->addr = addr;
  new->next = NULL;
  return new;
}

void displaynote(note_addr *p){
  if(p==NULL){
    printf("loi contro NULL\n");
    return ;
  }
  address tmp=p->addr;
  printf("%-20s\t%-15s\t%-30s\n",tmp.name,tmp.tel,tmp.email);
}
void main(){
  address tmp=readnode();
  strcpy(tmp.name,"Tran Van Thanh");
  strcpy(tmp.tel,"039473943");
  strcpy(tmp.email,"thanh@email.com");
  root=makenewnode(tmp);
  displaynote(root);
  return 0;
}
  

