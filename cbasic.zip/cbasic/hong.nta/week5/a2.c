#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct address_t {
  char name[20];
  char tel[11];
  char email[25];
}address;

struct list_el
{
  address addr;
  struct list_el *next;
};
typedef struct list_el node_addr;

node_addr *root,*cur,*prev; //khai bao 3 bien toan cuc
node_addr *makenewnode()
{
  node_addr *new=(node_addr*)malloc(sizeof(node_addr));
 /* strcpy((new->addr).name,<<Tran Van Thanh>>);
  strcpy((new->addr).tel,<<039473943>>);
  strcpy((new->addr).email,<<thanh@email.com>>);*/
  //new->addr = addr;
  new->next = NULL;
  return new;

}
int main(){
address a;
strcpy(a.name,"Tran Van Thanh");
  strcpy(a.tel,"039473943");
  strcpy(a.email,"thanh@email.com");
root=makenewnode(a);

 cur=root;
 printf("%s %5s %5s\n",a.name,a.tel,a.email);
 return 0;
}
