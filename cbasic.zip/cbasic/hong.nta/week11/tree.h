#include<stdio.h>
#include<stdlib.h>
typedef int keytype;
typedef struct node{
  keytype key;
  struct node *left,*right;
}nodetype;
typedef node* treetype;

void inorderprint(treetype tree){
  if(tree!=NULL){
    inorderprint(tree->left);
    printf("%4d\n",tree->key);
    inorderprint(tree->right);
  }
}

treetype search(keytype x,treetype root){
  if(root==NULL)
    return NULL;
  else if(root->key==x)
    return root;
  else if(root->key<x)
    return search(x,root->right);
  else{
    return search(x,root->left);
  }
}

void insertnode(KeyType x,TreeType *Root ){
  if (*Root == NULL){
/* Create a new node for key x */
    *Root=(nodetype*)malloc(sizeof(nodetype));
    (*Root)->key = x;
    (*Root)->left = NULL;
    (*Root)->right = NULL;
   }
   else if (x < (*Root)->key)
     insertnode(x,&(*Root)->left);
   else if (x>(*Root)->key)
     insertnode(x, &(*Root)->right);
}

/*treetype insertnode2(keytype x,treetype root){
  if(root==NULL){
    root=(nodetype*)malloc(sizeof(nodetype));
    root->key=x;
    root->left=NULL;
    root->right=NULL;
    return root;
  }
  else if (x < root->key)
     return insertnode(x,root->left);
   else if (x> Root->key)
     return insertnode(x, root->right);
     }*/
