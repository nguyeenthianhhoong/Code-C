#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct address_t {
  char name[20];
  char tel[11];
  char email[25];
}address;

struct list_el
{
  address addr;
  struct list_el *next;
};
typedef struct list_el node_addr;
node_addr *root,*cur,*prev;
root->addr.name='Tran Anh';
root->addr.tel='04356345';
root->addr.email='anh@email.com';
cur->addr.name='Tran An';
cur->addr.tel='04356346';
cur->addr.email='anh11@email.com';


node_addr *makenewnode(address addr)
{
  node_addr *new=(node_addr*)malloc(sizeof(node_addr));
  new->addr = addr;
  new->next = NULL;
  return new;
}
void displaynote(note_addr *p){
  if(p==NULL){
    printf("loi contro NULL\n");
    return ;
  }
  address tmp=p->addr;
  printf("%-20s\t%-15s\t%-30s\n",tmp.name,tmp.tel,tmp.email);
}
void insertathead(address addr){
  node_addr* new=makenewnode(addr);
  new->next=root;
  root=new;
  cur=root;
}
void insertaftercurrent(address addr){
  node_addr* new=makenewnode(addr);
  if(cur==NULL)
    return;
  
}
void insertbeforcurrent(address e){
  node_addr * new= makenewnode(e);
  if(root==NULL){
    root=new;
    cur=root;
    prev=NULL;
  } else {
    new->next=cur;
    if(cur==root){
      root=new;
    }
    else prev->next=new;
    cur =new;
  }
}
 void deletefirstelement(){
   node_addr *del=root;
   if(del==NULL)
     return;
   root=del->next;
   free(del);
   cur=root;
 }
void deletecurrent(){
  if(cur==NULL)
    return;
  if(cur==root)
    deletefirstelement();
  else{
  prev->next=cur->next;
  free(cur);
  cur=prev->next;
  }
}
void traversinglist(){
  node_addr *p;
  for(p=root;p!=NULL;p=p->next)
    displaynode(p);
}

node_addr* list_reverse(node_addr* root){
  node_addr *cur,*prev;
  cur=prev=NULL;
  while(root!=NULL){
    cur=root;
    root=root->next;
    cur->next=prev;
    prev=cur;
  }
  return prev;
 }

 int main(){
   address a;
   a=readnode();
   insertbeforecurrent(a);
   deletefirstelement();
   deletecurrent();
   displaynode(root);
   return 0;
 }
  
   
   
