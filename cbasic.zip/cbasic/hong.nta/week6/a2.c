#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct address_t {
  char name[20];
  char tel[11];
  char email[25];
}address;
typedef address elementtype;
typedef struct node node;
typedef struct node{
  elementtype element;
  node* next;
};
node* root;
node* cur,*prev;
node *makenewnode(elementtype addr){
  node *new=(node*)malloc(sizeof(node));
  new->element=addr;
  new->next=NULL;
  return new;
}
elementtype readdata(){
  elementtype e;
  printf("name:");
  gets(e.name);
  printf("tel:");
  gets(e.tel);
  printf("email:");
  gets(e.email);
}

void printdata(elementtype e){
  printf("%15s\t%10s\t%20s\n",e.name,e.tel,e.email);
}
void insertaftercurrent(elementtype e){
  node* new= makenewnode(e);
  if(root==NULL){
    root=new;
    cur=root;
  } else {
    new->next=cur->next;
    cur->next=new;
    cur =cur->next;
  }
}
void insertbeforcurrent(elementtype e){
  node* new= makenewnode(e);
  if(root==NULL){
    root=new;
    cur=root;
    prev=NULL;
  } else {
    new->next=cur;
    if(cur==root){
      root=new;
    }
    else prev->next=new;
    cur =new;
  }
}
void traversinglist(){
  node* p;
  for(p=root;p!=NULL;p=p->next)
    printdata(p->element);
}
int main(){
   elementtype a;
   a=readdata();
   insertbeforcurrent(a);
   insertaftercurrent(a);
   printdata(a);
   traversinglist();
   return 0;
}
