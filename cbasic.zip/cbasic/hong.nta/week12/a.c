#include<stdio.h>
enum{success,fail, max= 5};
typedef struct phoneaddress_t{
  char name[20];
  char tel[11];
  char email[25];
}phoneaddress;

typedef struct Node{
  phoneaddress key;
  struct Node* left,right;
}Nodetype;
typedef Node *treetype;

treetype search(char *email,treetype root){
  if(root==NULL)
    return NULL;
  else if(strcmp((root->key).email,email)==0)
    return root;
  else if(strcmp((root->key).email,email)<0)
    return search(email,root->right);
  else {
    return search(email,root->left);
  }
}

void insertnode(phoneaddress x,treetype *root){
  if(*root==NULL){
    *root=(Nodetype*)malloc(sizeof(Nodetype));
    (*root)->key=x;
    (*root)->left=NULL;
    (*root)->right=NULL;
  }
  else if (strcmp(((*root)->key).email,x.email)>0)
    insertnode(x,(*root)->left);
  else if(strcmp(((*root)->key).email,x.email)<0)
    insertnode(x,(*root)->right);
}

void inorderprint(treetype tree){
  if(tree!=NULL){
    inorderprint(tree->left);
    printf("%4d\n",tree->key);
    inorderprint(tree->right);
  }
}

int main(void){
  FILE *f;
  phoneaddress phonearr[max];
  treetype root;
  int i,n,irc;
  int reval=success;
  // int n=10;

  if((f=fopen("phonebook.dat","rb"))==NULL){
    printf("cannot open file phonebook.dat\n");
    reval=fail;
  }
  while(!feof(f)){
  fread(phonearr,sizeof(phoneaddress),1,f);
  }
  fclose(f);
  for(i=0;i<max;i++)
    root=insertnode(phonearr[i],root);

}
