#include<stdio.h>
#include<stdlib.h>

typedef int elementtype;
typedef struct nodetype{
  elementtype element;
  struct nodetype *left,*right;
}node;
typedef struct nodetype *treetype;

void MakeNullTree(treetype *T){
  (*T)=NULL;
}


void inorderprint(treetype tree){
  if(tree!=NULL){
    inorderprint(tree->left);
    printf("%4d\n",tree->element);
    inorderprint(tree->right);
  }
}


treetype search(elementtype x,treetype root){
  if(root==NULL)
    return NULL;
  else if(root->element==x)
    return root;
  else if(root->element <x)
    return search(x,root->right);
  else{
    return search(x,root->left);
  }
}

void insertnode(elementtype x,treetype *Root ){
  if (*Root == NULL){
    *Root=(node*)malloc(sizeof(node));
    (*Root)->element = x;
    (*Root)->left = NULL;
    (*Root)->right = NULL;
   }
   else if (x < (*Root)->element)
     insertnode(x,&(*Root)->left);
   else if (x>(*Root)->element)
     insertnode(x, &(*Root)->right);
}

elementtype DeleteMin (treetype *Root ){
elementtype k;
if ((*Root)->left == NULL){
k=(*Root)->element;
(*Root) = (*Root)->right;
return k;
}
else return DeleteMin(&(*Root)->left);
}

void Deletenode(elementtype x,treetype *root){
  if(*root!=NULL)
    if(x<(*root)->element)
      Deletenode(x,&(*root)->left);
    else if (x>(*root)->element)
      Deletenode(x,&(*root)->right);
    else if (((*root)->left==NULL)&&((*root)->right==NULL))
				   *root=NULL;
    else if ((*root)->left==NULL)
      *root=(*root)->right;
    else if ((*root)->right==NULL)
      *root=(*root)->left;
    else (*root)->element=DeleteMin(&(*root)->right);
					    
}

void freetree(treetype tree){
  if(tree!=NULL)
    {
      freetree(tree->left);
      freetree(tree->right);
      free(tree);
    }
}
