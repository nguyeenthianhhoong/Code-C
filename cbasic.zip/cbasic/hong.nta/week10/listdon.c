#include<stdio.h>
#include<string.h>
#include<stdlib.h>
enum{success,fail};

typedef struct phonedb{
  char model[25];
  char memory[10];
  char screen[15];
  char price[15];
}phone;

typedef phone elementtype;
typedef struct node node;
struct node{
  elementtype element;
  node* next;
};
node *root,*cur,*prev;

node* makenewnode(elementtype a){
  node* new=(node*)malloc(sizeof(node));
  new->element=a;
  new->next=NULL;
  return new;
}


elementtype readdata(){
  elementtype e;
  printf("model:");
  scanf("%s",e.model);
  printf("memory:");
  scanf("%s",e.memory);
  printf("screen:");
  scanf("%s",e.screen);
  printf("price:");
  scanf("%s",e.price);
  return e;
}

void insertathead(elementtype a){
  node* new=makenewnode(a);
  new->next=root;
  root=new;
  cur=root;
}

void insertaftercur(elementtype e){
  node* new= makenewnode(e);
  if(root==NULL){
    root=new;
    cur=root;
  }else if(cur==NULL)
    return;
  else {
    new->next=cur->next;
    cur->next=new;
    //cur =cur->next;
    cur=new;
  }
}
/*
node *inserttail(node *head,node *curr, elementtype data){
  node *temp = makenewnode(data);
  if(temp == NULL)
    return head;
  if (head == NULL){
    head = temp;
  }
  else{
    curr = head;
    while(curr->next != NULL){
      curr = curr->next;
    }
    curr->next = temp;
  }
  return head;
}
*/

node *insertatposition(node *root,elementtype add,int n)
{
  int a=1;
  cur=root;
 node *new = makenewnode(add);
 if(root==NULL)
   {
     root =new;
   }
 if(n==0)
   insertathead( add);
 while(cur != NULL && a!=n)
   {
     cur = cur->next;
     ++a;
   }
 if(a!=n)
   printf("Khong tim thay vi tri can chen!!!\n");
 else{
new ->next = cur -> next;
    cur->next = new;
    cur = cur->next; 
 }
 return cur;
}

void readdat(FILE *fin){
  elementtype e;
  while(!feof(fin)){
    fread(e.model,25,1,fin);
    fread(e.memory,10,1,fin);
    fread(e.screen,15,1,fin);
    fread(e.price,15,1,fin);
    insertaftercur(e);
  }
}

void getlinkdata(node* head){
  printf("\n");
  for (node *p = head; p != NULL; p = p->next){
    printf("%-25s%-10s%-15s%-15s\n",(p->element).model, (p->element).memory, (p->element).screen, (p->element).price);
  }
}

void deletefirstelement(){
  node *del=root;
  if(root==NULL)
    return;
  root = del->next;
  free(del);
  cur=root;
}

void deletecur()
{
  node *tmp;
  while(tmp!=NULL && tmp->next!=cur && cur!=NULL)
    tmp=tmp->next;
  prev=tmp;
  if (cur==NULL)
    return ;
  if (cur==root)
    deletefirstelement();
  else
  {
    prev->next=cur->next;
    free(cur);
    cur=prev->next;
  }
 }

node *deleteatposition(node *root,int n)
{
  cur = root;
  int a=1;
   while(cur != NULL && a!=n)
   {
     cur = cur->next;
     ++a;
   }
  if(a!=n)
   printf("Khong tim thay vi tri xoa!!!\n");
  
  node *tmp;
  tmp = root;
  while(tmp != NULL && tmp->next !=cur && cur != NULL)
    tmp = tmp->next;
  prev = tmp;
 
 prev->next = cur->next;
  free(cur);
  cur = prev->next;
 
 return root;
}

void searchmovefront(node *head,node *cur){
  char models[20];
  int check;
  elementtype m;
  printf("Search Model:");
  getchar();
  gets(models);
  for(node *p = head; p != NULL; p = p->next){
    check = strcmp((p->element).model,models);
    if(check == 0){
      cur=p;
      makenewnode(m);
      m=p->element;
      
       deletecur();
        printf("------\n");
      insertathead(m);
      
      //printf("%-25s%-10s%-15s%-15s\n\n",(p->element).model, (p->element).memory, (p->element).screen, (p->element).price);
    }
  }
 }

void searchtranspose(){
  char models[20];
  int check;
  node *prev=root;
  elementtype m;
  printf("Search Model:");
  getchar();
  gets(models);
  for(node *p = head; p != NULL; p = p->next){
    check = strcmp((p->element).model,models);
    if(check == 0){
      while(prev->next!=p)
	prev=prev->next;
      m=p->element;
      p->element=prev->element;
      prev->next=p;

}

void list_reverse(node **root)
{
  node *cur=*root;
  node *prev=NULL;
  node *next;
  while(cur != NULL)
    {
     next = cur->next;
      cur->next = prev;
      prev=cur;
     cur=next; 
    }
  *root=prev;
 }

void exportdat(FILE *file, node *head){
  for(node *p = head; p != NULL; p = p->next){
    fwrite(&(p->element),sizeof(elementtype),1,file);
  }
}

int main(){
  FILE *f,*f1;
  int choice,n,m;
  int reval=success;
  elementtype p;

  if((f=fopen("phoneDB.dat","rb"))==NULL){
    printf("cannot open phoneDB.dat\n");
    reval=fail;
  }
  if((f1=fopen("phoneDB1.dat","wb"))==NULL){
    printf("cannot open phoneDB.dat\n");
    reval=fail;
  }

  do{
    printf("MENU:\n");
    printf("1.  IMPORT FROM DAT\n");
    printf("2.  DISPLAY\n");
    printf("3.  ADD NEW PHONE\n");
    printf("4.  INSERT AT POSITION\n");
    printf("5.  DELETE AT POSITION\n");
    //printf("5.  DELETE CURRENT\n");
    printf("6.  DELETE FIRST\n");
    printf("7.  SEARCH MOVE FRONT\n");
    printf("8.  SEARCH TRANSPOSE\n");
    printf("9.  REVERSE LIST\n");
    printf("10. SAVE TO FILE\n");
    printf("11. QUIT\n");
    do{
      printf("Input a choice:");
      scanf("%d",&choice);
    }
    while (choice < 1|| choice > 10);
    switch(choice){

    case 1:
      readdat(f);
      printf("Import success\n");
      fclose(f);
      break;
    
    case 2:
      getlinkdata(root);
      break;
    
    case 3:
    
      p=readdata();
      insertathead(p);
      printf("done\n");
      break;
    
    case 4:
      p=readdata();
      printf("Vi tri chen:");
      scanf("%d",&n);
      insertatposition(root,p,n);
      getlinkdata(root);
      break;
    
    case 5:
      printf("vi tri xoa:");
      scanf("%d",&m);
      deleteatposition(root,m);
      getlinkdata(root);
      break;

    case 6:
      deletefirstelement();
      getlinkdata(root);
      break;

    case 7:
      searchmovefront(root,cur);
      getlinkdata(root);
      break;

    case 8:

      list_reverse(&root);
      getlinkdata(root);
      break;

    case 9:
      exportdat(f1,root);
      printf("save success\n");
      fclose(f1);
      break;

    case 11:
      printf("byeee\n");

      break;

      /* case 12:
      printf("byeeee\n");
      break;*/
    
    }
    } while (choice!=11);
    return 0;


}
