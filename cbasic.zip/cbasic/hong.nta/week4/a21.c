size_t size:kichthuoc theo byte of 1 phan tu of mang dong
n: so luong phan tu don
size_t: int


size_t fread(void *ptr,size_t size,size_t n,FILE *stream
size_t fwrite(const void *ptr,size_t size,size_t n,FILE *stream)




	     int feof(FILE *stream)
	     tra ve 0 chua den cuoi file
	     khac 0 den cuoi file





fseek(FILE *stream,long offset,int whence)
whence:hang so chi moc
