#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define max 10
char *my_strcat(char *str1,char *str2)
{
  int len1,len2;
  char *result;
  len1=strlen(str1);
  len2=strlen(str2);
  result=(char*)malloc((len1+len2+1)*sizeof(char));
  if(result==NULL){
    printf("allocation failed!check memoty\n");
    return NULL;
  }
  strcpy(result,str1);
  strcpy(result+len1,str2);
  return result;

  /*c2:for(i=0;i<len1;i++)
  result[i]=str1[i];
  for(i=len1;i<len1+len2;i++)
    result[i]=str[i]
    result[i+1]='\0'*/
}
int main(void)
{
  char str1[max+1],str2[max+1];
  char *cat_str;
  printf("please enter two strings\n");
  scanf("%100s",str1);
  scanf("%100s",str2);
  cat_str=my_strcat(str1,str2);
  if(cat_str==NULL)
    {
      printf("problem allocating memory\n");
    }
  printf("the concatenation of %s and %s is:\n %s\n",str1,str2,cat_str);
  free(cat_str);
  return 0;
}
