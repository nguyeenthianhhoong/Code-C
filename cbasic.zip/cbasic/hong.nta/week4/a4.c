#include<stdio.h>

enum{success,fail,max=5};
typedef struct phoneaddress_t{
  char name[20];
  char tel[11];
  char email[25];
}phoneaddress;


int main(){
  FILE *fp;
  phoneaddress pa[max];
  int i,irc;
  int reval=success;
  printf("nhap du lieu:\n");
  for( i=0;i<10;i++){
    printf("enter name:");
    scanf("%s",&pa[i].name);
    printf("enter tel:");
    scanf("%s",&pa[i].tel);
    printf("enter email:");
    scanf("%s",&pa[i].email);
  }
  if((fp=fopen("phonebook.dat","w+b"))==NULL){
    printf("cannot open file");
    reval=fail;
  }

  irc=fwrite(pa,sizeof(phoneaddress),5,fp);
  printf("fwrite return code= %d\n",irc);
  fclose(fp);

  if((fp=fopen("phonebook.dat","rb"))==NULL){
    printf("cannot open file");
    reval=fail;
  }
  irc=fread(pa,sizeof(phoneaddress),5,fp);
  printf("fread return code=%d\n",irc);
  for(i=0;i<10;i++){
    printf("%s---",pa[i].name);
    printf("%s---",pa[i].tel);
    printf("%s\n",pa[i].email);
  }
  fclose(fp);
  return reval;
}


