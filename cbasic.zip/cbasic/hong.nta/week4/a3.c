#include<stdio.h>

enum{success,fail,max=80};

int main(){
  int num;
  FILE *ptr,*ptr1;
  char filename[]="1.txt",filename1[]="2.txt";
  int reval=success;
  char buff[max+1],str[max];
  if((ptr=fopen(filename,"r"))==NULL){
    printf("cannot open file");
    reval=fail;
    exit(1);
  }else if((ptr1=fopen(filename1,"w"))==NULL){
    printf("cannot open file");
    reval=fail;
    exit(1);
    
    }else{
    blockreadwrite(ptr,ptr1);
    fclose(ptr);
    fclose(ptr1);

    }
  return 0;
  
}
void blockreadwrite(FILE *fin,FILE *fout){
  int num;
  char buff[max+1];
  while(!feof(fin)){
    num=fread(buff,sizeof(char),max,fin);
    buff[num *sizeof(char)]='\0';
    printf("%s",buff);
    fwrite(buff,sizeof(char),num,fout);
  }
    
}
