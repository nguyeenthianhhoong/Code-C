#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct address_t {
  char name[20];
  char tel[11];
  char email[25];
}address;
typedef address elementtype;
typedef struct node node;
typedef struct node{
  elementtype element;
  node* prev;
  node* next;
};
typedef node* doublelist;
doublelist root,tail,cur;

node* makenewnode(elementtype addr){
  node* new=(node*)malloc(sizeof(node));
  new->element=addr;
  new->next=NULL;
  new->prev=NULL;
  return new;
}

void makeNull_List(doublelist *root,doublelist *tail,doublelist *cur){
  (*root)=NULL;
  (*tail)=NULL;
  (*cur)=NULL;
}
int isempty(doublelist *root){
  return(root==NULL);
}

elementtype readdata(){
  elementtype e;
  printf("name:");
  gets(e.name);
  printf("tel:");
  gets(e.tel);
  printf("email:");
  gets(e.email);
}

void printdata(elementtype e){
  printf("%15s\t%10s\t%20s\n",e.name,e.tel,e.email);
}

void traversinglist(doublelist *root){
  doublelist* p;
  for(p=*root;p!=NULL;p=p->next)
    printdata(p->element);
}

void insertathead(elementtype e,doublelist *root,doublelist *tail,doublelist *cur){
  node* new=makenewnode(e);
  if(*root==NULL)
    *tail=new;
  new->next=*root;
  (*root)->next=new;
  *root=new;
  *cur=*root;
  printf("done!!");
}

void insertaftercur(elementtype e,doublelist *root,doublelist *tail, doublelist *cur){
  node* new=makenewnode(e);
  if(*root==NULL){
    *root=new;
    *tail=new;
    cur=root;
  }else{
    new->next=(*cur)->next;
    if((*cur)->next!=NULL)
      (*cur)->next->prev=new;
    //*cur->next=new;
    new->prev=*cur;
    (*cur)->next=new;
    *cur=new;
    
    if(new->next==NULL)
      *tail=new;
  }
}

void delete_list(doublelist p,doublelist *root





int main(){
  elementtype a,b,c;
  //doublelist *root,*tail,*cur;
  //makeNull_List(&root,&tail,&cur);
  a=readdata();
  root=makenewnode(a);
  b=readdata();
  insertathead(b,&root,&tail,&cur);
  c=readdata();
  insertaftercur(c,&root,&tail,&cur);
  
  //printdata(a);
  //printdata(b);
  //traversinglist(&root);
  return 0;


}

