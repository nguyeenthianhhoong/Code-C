#include<stdio.h>

#define max 50
typedef int eltype;
typedef eltype stacktype[max];
int top;

void initialize(stacktype stack);
int empty(stacktype stack);
int full(stacktype stack);
void push(eltype el,stacktype stack);
eltype pop(stacktype stack);
eltype peek(stacktype stack);

initialize(stacktype stack){
  top=0;
}

empty(stacktype stack){
  return top==0;
}

full(stacktype stack){
  return top==max;
}

 push(eltype el,stacktype stack){
  if(full(stack))
    printf("stack overflow");
  else stack[top++]=el;
}

eltype pop(stacktype stack){
  if(empty(stack))
    printf("stack underflow");
  else return stack[--top];
}

eltype peek(stacktype stack){
  if(empty(stack)){
    printf("stack underflow");
    return -999999;
  }
  else return stack[top-1];
}
