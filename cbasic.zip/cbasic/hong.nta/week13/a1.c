#include<stdio.h>

typedef int element;
//element key;
void insertion_sort(element list[],int n){
  int i,j;
  element next;
  for(i=0;i<n;i++){
    next=list[i];
    for(j=i-1;j>=0 && next<list[j];j--)
      list[j+1]=list[j];
    list[j+1]=next;
  }
}

void selection(element a[],int n){
  int i,j,min,tmp;
  for(i=0;i<n;i++){
    min =i;
    for(j=i+1;j<=n-1;j++)
      if(a[j]<a[min])
	min=j;
    tmp=a[i];
    a[i]=a[min];
    a[min]=tmp;
  }
}

void display(element list[],int n){
  for (int i=0;i<n;i++)
    printf("%d\n",list[i]);
}
void SWAP(int *a,int *b){
      int temp=*a;
      *a=*b;
      *b=temp;

}

void quicksort(element list[],int left,int right){
  int pivot,i,j;
  element tmp;
  if(left<right){
    i=left;
    j=right+1;
    pivot=list[left];
    do{
      do i++;
      while (list[i]<pivot);
      do j--;
      while (list[i]>pivot);
      if(i<j)
	SWAP(&list[i],&list[j]);		
	  }while(i<j);
    SWAP(&list[left],&list[j]);
    quicksort(list,left,j-1);
    quicksort(list,j+1,right);
  }
}

void merge(int arr[], int l, int m, int r)
{
int i, j, k;
int n1 = m - l + 1;
int n2 = r - m;
/* tạo các mảng tạm thời*/
int L[n1], R[n2];
/* Chép dữ liệu vào các mảng tạm thời arrays L[] và R[] */
for (i = 0; i < n1; i++)
L[i] = arr[l + i];
for (j = 0; j < n2; j++)
R[j] = arr[m + 1+ j];

/* Trộn các mảng tạm thời trở lại vào arr[l..r]*/
i = 0; // Khởi tạo chỉ số cho mảng con thứ 1
j = 0; // Khởi tạo chỉ số cho mảng con thứ 2
k = l; // Khởi tạo chỉ số cho mảng con được trộn
while (i < n1 && j < n2)
{
if (L[i] <= R[j])
{
arr[k] = L[i];
i++;
}
else
{
arr[k] = R[j];
j++;
}
k++;
}

/* Chép các phần tử còn lại của L[], nếu còn */
while (i < n1)
{
arr[k] = L[i];
i++;
k++;
}

/* Chép các phần tử còn lại của R[], nếu còn */
while (j < n2)
{
arr[k] = R[j];
j++;
k++;
}
}

//l la chi so trai,r la chi so phai cua mang can dc sap xep
void mergeSort(int arr[], int l, int r)
{
if (l < r)
{
int m = l+(r-l)/2;
// Same as (l+r)/2, but avoids overflow for large l and h
// Sort first and second halves
mergeSort(arr, l, m);
mergeSort(arr, m+1, r);
merge(arr, l, m, r);
}
}


int main(){
  element a[6]={-3,400,1,25,7,0};
  //insertion_sort(a,6);
  //selection(a,6);
  //quicksort(a,0,5);
  mergeSort(a,0,5);
  display(a,6);

}
