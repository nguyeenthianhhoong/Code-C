#include<stdio.h>
#include<stdlib.h>

typedef int element;

void SWAP(int *a,int *b){
      int temp=*a;
      *a=*b;
      *b=temp;
}

void adjust(element list[], int root,int n){
  int child,rootkey;
  element temp;
  temp=list[root];
  rootkey=list[root];
  child=2*root;
  while (child <=n){
    if ((child< n)&&(list[child]<list[child+1]))
      child++;
    if(rootkey>list[child])
      break;
    else {
      list[child/2]=list[child];
      child *= 2;
    }
  }
  list[child/2]=temp;
}

void display(element *list,int n){
  for (int i=0;i<n;i++)
    printf("%d\t",list[i]);
}

void heapsort(element list[],int n){
  int i,j,d=1;
  element temp;
  for(i=n/2;i>0;i--) adjust(list,i,n);
  for(i=n-1;i>0;i--){
    SWAP(&list[1],&list[i+1]);
    adjust(list,1,i);
    printf("Sap xep lan %d:  ",d);
    display(list,10);
    printf("\n");
    d++;
      
  }
}


int main(){
  element a[10]={-3,400,1,25,7,0,5,100,99,236};
  printf("mang:");
  display(a,10);
  printf("\n\n");
  heapsort(a,9);
   return 0;
}
