#include<stdio.h>
#include<string.h>
#include<stdlib.h>


typedef struct thucdon_t{
  int ID;
  char tenmon[30];
  int soluong;
  char giatien;
}thucdon;
thucdon *menu;
int n=-1;
void docfile(char a[]){
  FILE *f;
  if((f=fopen(a,"r"))==NULL){
  printf("cannot open file");
  }
 else{
   while(feof(f)==0){
     ++n;
     menu=(thucdon *)realloc(menu,(n+1)*sizeof(thucdon));
     fscanf(f,"%d %s %d %s",&menu[n].ID,&menu[n].tenmon,&menu[n].soluong,&menu[n].giatien);
     printf("%d%s%d%s",menu[n].ID,menu[n].tenmon,menu[n].soluong,menu[n].giatien

     fclose(f);
   }
 }
}
  /*
void SWAP(int *a,int *b){
      int temp=*a;
      *a=*b;
      *b=temp;
}

void adjust(thucdon list[], int root,int n){
  int child,rootkey;
  element temp;
  temp=list[root];
  rootkey=list[root];
  child=2*root;
  while (child <=n){
    if ((child< n)&&(list[child]<list[child+1]))
      child++;
    if(rootkey>list[child])
      break;
    else {
      list[child/2]=list[child];
      child *= 2;
    }
  }
  list[child/2]=temp;
}

void display(element *list,int n){
  for (int i=0;i<n;i++)
    printf("%d\t",list[i]);
}

void heapsort(element list[],int n){
  int i,j,d=1;
  element temp;
  for(i=n/2;i>0;i--) adjust(list,i,n);
  for(i=n-1;i>0;i--){
    SWAP(&list[1],&list[i+1]);
    adjust(list,1,i);
    printf("Sap xep lan %d:  ",d);
    display(list,10);
    printf("\n");
    d++;
      
  }
}

  */

int main(){
  char a[10];
  printf("Nhap ten file doc:");
  fflush(stdin);
  gets(a);
  docfile(a);
  


  free(menu);
  return 0;
  

}
