#include <stdio.h>
#include<string.h>
#include <stdlib.h>
enum {SUCCESS,FAIL};
char uconvert(char file[20])
{
  FILE *lab;
 
  int reval = SUCCESS;
  if((lab=fopen(file,"r+"))==NULL)
    {
      printf("canot open %s.\n","a1.txt");
      reval = FAIL;
    }
 else{
    int c;
    char A[50];
    while ((fgets(A,50,lab)) != NULL)
      {
	for(int i=0;i<strlen(A);i++)
	  {	if(A[i]<='z' && A[i]>='a')
	    {
	      A[i]=A[i]-32;
	     }

	  }
      }
	lab=fopen(file,"w+");
     int n=strlen(A);
	  fprintf(lab,"%c",n);
	  for(int i=0;i<n;i++)
	    { fprintf(lab,"%c",A[i]);
	  printf("%c",A[i]);
	    }
	
    fclose(lab);
   
  }
  return reval;
}
int main(){
  char lenh[50];
  char file[20];
  int vitri1,i;
  printf("nhap lenh (uconvert file.txt)\n");
  scanf("%[^\n]s",lenh);
  scanf("%*c");
 for(vitri1 = strlen(lenh);vitri1 >=0; vitri1--)
   if(lenh[vitri1] == ' ')break;
  for( i=vitri1+1;i<strlen(lenh);i++)
    file[i-(vitri1+1)] = lenh[i];
  file[i-(vitri1+1)] = '\0';
  uconvert(file);
 return 0;
}
