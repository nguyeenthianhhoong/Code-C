#include <stdio.h>
#include <string.h>
#include <malloc.h>
//#include <stdio_ext.h>
//dinh nghia cau truc cay
typedef struct data{
	char key[21];
	char mean[101];
}Data;
typedef struct Node {
	Data data; 
	struct Node *left;
	struct Node *right;
}Node;
// khoi tao mot node khi co du lieu la data
Node* createNode(Data data){
	Node *p = NULL;
	p = (Node *)calloc(1,sizeof(Node));
	p->data = data;
	return p;
}
//them mot node vao cay
void makerTree(Node *node, Node **root){
	if(*root==NULL) *root=node;
	else if(strcmp((*root)->data.key,node->data.key)<0) makerTree(node,&((*root)->right));
	else makerTree(node,&((*root)->left));
}
// doc va xu li file dau vao
void docFile(Node **root){
	char a[30];
	char b[200];
	printf("Nhap ten file can doc: ");
	//__fpurge(stdin);// chay tren linux
	fflush(stdin);//chay tren dev
	gets(a);
	FILE *f=NULL;
	f=fopen(a,"r");
	if(f==NULL){
		printf("Khong the mo file.");
		return;
	}
	else{
	Data data;
	int i=0,k=0,t=0;
	int n;
	while(!feof(f)){
		fgets(b,150,f);
		t=0;
		k=0;
		n=strlen(b);
		for(i=0;i<n;i++)
		if(t==0){
			if(b[i] != ';')
			data.key[k++] = b[i];
			else {
				++t;
				data.key[k]='\0';
				k=0;
			}
		}
		else data.mean[k++]=b[i];
		data.mean[k] = '\0';
	 	if(!feof(f))makerTree(createNode(data),root);
	}
}
}
void duyetCay(Node ** root){
	if(*root == NULL) return;
	printf("%s:%s\n",(*root)->data.key,(*root)->data.mean);
	if((*root)->left!=NULL) duyetCay(&(*root)->left);
	if((*root)->right!=NULL) duyetCay(&(*root)->right);
}
//ham nay tra ve dia chi cua xau chua is nghia cua key a[]
char* timKiem(Node **root,char a[]){
	if(*root == NULL) return NULL;
	if(strcmp(a,(*root)->data.key) == 0) return (*root)->data.mean;
	if(strcmp(a,(*root)->data.key) > 0)  return timKiem(&((*root)->right),a);
	if(strcmp(a,(*root)->data.key) < 0) return timKiem(&((*root)->left),a); 
}
void tim(Node **root){
	char b[21];
	printf("Nhap tu can tim:");
	fflush(stdin);
	gets(b);
	if(timKiem(root,b) == NULL) printf("Khong tim thay tu can tim.");
	else printf("Tu can tim co nghia la:%s",timKiem(root,b));
	return ;
}
// them mot node moi voi du lieu data cao tree
void them(Node **root,Data data){
	if(*root == NULL){
		Node *p= NULL;
		p = (Node *)calloc(1,sizeof(Node));
		p->data = data;
		p->left = p->right = NULL;
		*root = p;
	} 
 	else if(strcmp((*root)->data.key,data.key) > 0) them(&((*root)->left),data);
	else if(strcmp((*root)->data.key,data.key) < 0) them(&((*root)->right),data);
}
void themNode(Node **root){
	Data data;
	printf("Key:");
	fflush(stdin);
	gets(data.key);
	printf("Mean:");
	fflush(stdin);
	gets(data.mean);
	them(root,data);
	return ;	
}
//tim  node co data.key nho nhat cua cay con nen phai node can xoa.
Data minRight(Node **root){
	Data data;
	if((*root)->left == NULL){
		data = (*root)->data;
		free(*root);
		return data;
	}
	else  return minRight(&((*root)->left));
}
void xoaNode(Node **root,char key[]){
	if(*root == NULL) return;
	if(strcmp((*root)->data.key,key) == 0){
		if((*root)->left == NULL && (*root)->right == NULL) free(*root);
		else if((*root)->left != NULL && (*root)->right == NULL){
			Node *p = NULL;
			p = (Node *)calloc(1,sizeof(Node));
			p = *root;
			*root = (*root)->left;
			free(p);
		} 
		else if((*root)->left == NULL && (*root)->right != NULL){
			Node *p = NULL;
			p = (Node *)calloc(1,sizeof(Node));
			p = (*root);
			(*root) = (*root)->right;
			free(*root);
		}
		else (*root)->data = minRight(root);
	}
	else if(strcmp(key,(*root)->data.key) > 0) xoaNode(&((*root)->right),key);
	else if(strcmp(key,(*root)->data.key) < 0) xoaNode(&((*root)->left),key);
}
void xoa(Node **root){
	char a[30];
	printf("Nhap tu khoa can xoa:");
	fflush(stdin);
	gets(a);
	xoaNode(root,a);
	return;
}
//duyet cay theo chieu sau
void in(Node **root,FILE *f){
	if(*root == NULL) return;
	fprintf(f,"%s;%s\n",(*root)->data.key,(*root)->data.mean);
	in(&((*root)->left),f);
	in(&((*root)->right),f);
}
//ghi du lieu vao file
void inFile(Node **root){
	char a[20];
	printf("Nhap ten file can ghi:");
	fflush(stdin);
	gets(a);
	FILE *f = NULL;
	f = fopen(a,"w");
	if(f == NULL){
		printf("Khong the mo file.");
		return;
	}
	else{
		in(root,f);
	}
	fclose(f);
	return;
}
// xoa du lieu trong cay
void Free(Node **root){
	if(*root==NULL) return;
	Node *p=NULL;
	Free(&((*root)->left));
	Free(&((*root)->right));
	free(*root);
}
int main(){
	Node **root=NULL;
	root=(Node **)calloc(1,sizeof(Node*));
	while(1){
		printf("\n============== MENU ================\n");
		printf("\t\t1.Doc file.\n");
		printf("\t\t2.Duyet cay.\n");
		printf("\t\t3.Them node.\n");
		printf("\t\t4.Xoa node.\n");
		printf("\t\t5.Ghi file.\n");
		printf("\t\t6.Tim kiem.\n");
		printf("\t\t7.Thoat chuong trinh.\n");
		int c;
		printf("Nhap sua lua chon cua ban:");
		scanf("%d",&c);
		switch(c){
			case 1:docFile(root); break;
			case 2:duyetCay(root); break;
			case 3:themNode(root); break;
			case 4:xoa(root);break;
			case 5:inFile(root);break;
			case 6:tim(root);break;
			case 7:	Free(root); return 0;
		}
	}
}
