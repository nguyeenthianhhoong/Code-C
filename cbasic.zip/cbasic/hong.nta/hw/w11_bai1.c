#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"dblistw11.h"
#include"dblinkqueuew11.h"
int main() {
  int n;
  int i = 0;
  int ram;
  dblist* root1=NULL, *tail1=NULL;
  queue* front1=NULL, *rear1=NULL;
  printf("memory capacity (MB): "); scanf("%d", &ram);
  printf("number of parallel process: "); scanf("%d", &n);
  int bonhodu = ram;
  int k;
  while(1) {
    printf("-----\nMENU: \n");
    printf(" [1].create new program run\n");
    printf(" [2].show the status\n");
    printf(" [3].kill process\n");
    printf(" [4].exit\n");
    printf("ban chon tac vu: "); scanf("%d", &k);
    switch(k) {
      //
    case 1: {
      elementtype el;
      printf("the memory size of program? ");
      scanf("%d", &el.memory);
      printf("program ID? ");
      scanf("%d", &el.id);
      dblist* cur; queue* cur1;
      /*
      for(cur=root1; cur!=NULL; cur= cur->next) {
	if( (cur->element).id == el.id) break;
      }
      for(cur1=front1; cur1!=NULL; cur1=cur1->next) {
	if( (cur1->element).id == el.id) break;
      }
      if( cur!=NULL || cur1!=NULL) {
	printf("trung ID!!!\n");
	break;
      }
      */
      if(el.memory > ram) printf(" Vuot qua bo nho toi da!!!\n");
      else {
	if(el.memory > bonhodu || i >= n || emptyQueue(front1) == 0) {
	  enQueue(&front1, &rear1, el);
	  printf(" in queue\n");
	}
	else {
	  i = i+1;
	  bonhodu -= el.memory;
	  tao_ds(&root1, &tail1, el);
	  printf("success. Process created\n");
	}
      }
    }break;
      //
    case 2:{
      printf("\tID\t\tMEMORY\t\tQUEUE\n");
      displayList(root1);
      displayQueue(front1);
    }break;
      //
    case 3:{
      int add;
      printf("process ID: ");
      scanf("%d", &add);
      dblist* cur;
      for(cur=root1; cur!=NULL; cur=cur->next) {
	if((cur->element).id == add) break;
      }
      if(cur == NULL) {
	printf("khong co chuong trinh nao id: %d dang chay!!\n", add);
	break;
      }
      bonhodu += (cur->element).memory;
      i = i-1;
      if(cur == root1) {
	root1 = root1->next;
	free(cur);
      }else {
	if(cur == tail1) {
	  tail1 = tail1->prev;
	  free(cur);
	} else {
	  dblist* del = cur;
	  cur = cur->prev;
	  cur->next = del->next;
	  (del->next)->prev = cur;
	  free(del);
	}
      }
      elementtype el = front1->element;
      if( el.memory <= bonhodu ) {
	i = i+1;
	bonhodu -= el.memory;
	tao_ds(&root1, &tail1, el);
	deQueue(&front1, &rear1);
      }
    }break;
      //
    case 4: printf("exit...\n"); exit(0); break;
    }
  }
  freeQueue(&front1);
  freeList(&root1);
  return 0;
}
	       
  
  
