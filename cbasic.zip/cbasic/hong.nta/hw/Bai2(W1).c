#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 struct SINHVIEN
{
  char hoten[50];
  char ten[20];
};
void tachten(struct SINHVIEN *sv)
{
  sv->ten[0] = '\0';
  int vitri = 0 ;
  for(vitri = strlen(sv->hoten);vitri >= 0; vitri--)
    {
      if(sv->hoten[vitri]== ' ')break;
    }
  int i;
  for( i=vitri+1; i < strlen(sv->hoten);i++)
    sv->ten[i-(vitri+1)]= sv->hoten[i];
  sv->ten[i-(vitri+1)]='\0';
}
void sx(struct SINHVIEN ds[],int n)
{
  for(int i=n; i > 1; i--)
    for(int j=1; j<i;j++)
      {
	if(strcmp(ds[j-1].ten,ds[j].ten) > 0)
	  {
	    struct SINHVIEN tmp = ds[j-1];
	    ds[j-1] = ds[j];
	    ds[j] = tmp;
	  }
      }
}
void input(struct SINHVIEN* ds, int n)
{
  for(int i = 0; i < n;i++)
    {
 
  scanf("%[^\n]s",ds[i].hoten);
   scanf("%*c");
  tachten(&ds[i]);
    }
}
void output(struct SINHVIEN* ds, int n)
{
  printf("Danh sach sv: \n");
  for(int i = 0; i < n;i++)
    {
      printf("Hoten: %s\n",ds[i].hoten);
    }
  printf("\n");
}
int main()
{
  typedef struct SINHVIEN SV;
  SV ds[50];
  int n=0;
  printf("nhap so sv: ");
  scanf("%d\n",&n);
 
  input(ds, n);
  printf("Sap xep.....");
  sx(ds,n);
  output(ds,n);
  return 0;
}
