struct chuongtrinh {
  int id;
  int memory;
};
typedef struct chuongtrinh elementtype;
struct list {
  elementtype element;
  struct list* next;
  struct list* prev;
};
typedef struct list dblist;
//1.tao nut moi
dblist* makeNewNode(elementtype element_t) {
  dblist* new = (dblist*)calloc(1, sizeof(dblist));
  new->element = element_t;
  new->next = NULL;
  new->prev = NULL;
  return new;
}
//2.tao danh sach
void tao_ds(dblist** root, dblist** tail, elementtype element_t) {
  dblist* new = makeNewNode(element_t);
  if(*root == NULL) {
    *root = new;
    *tail = *root;
  }else {
    (*tail)->next = new;
    new->prev = *tail;
    *tail = new;
  }
}
//3.display danh sach
void displayList(dblist* root1) {
  dblist* cur;
  for(cur=root1; cur!=NULL; cur=cur->next) {
    printf("\t%d\t\t%d\n", (cur->element).id, (cur->element).memory);
  }
}
//4. free list
void freeList(dblist** root) {
  dblist* del = *root;
  while(root != NULL){
    *root = (*root)->next;
    free(del);
  }
}
