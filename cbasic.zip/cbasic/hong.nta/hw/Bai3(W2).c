#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
int main(int agc,char*agv[])
{
  if(agc!=5)
    {
      printf("wrong form\n");
      printf("enter form: sde a b c\n");
      return 1;
    }
  int a,b,c;
  a=atoi(agv[2]);
   b=atoi(agv[3]);
    c=atoi(agv[4]);
    float denta=(b*b-4*a*c)/(2*a);
    float f;
  if(a==0)
    {
      if(b==0)
	{
	  if(c==0)
	    printf("Phuong trinh vo so nghiem\n");
	  else
	    printf("phuong trinh vo nghiem\n");
	}
      else
	printf("phuong trinh co nghiem duy nhat x1= %d\n",-c/b);
    }
  else
    {
      
      if(denta<0)
       printf("phuong trinh vo nghiem\n");
      else if(denta==0)
	printf("phuong trinh co nghiem kep x1=x2=%.2f\n",(-b+sqrt(denta))/(2*a));
      else
	printf("phuong trinh cos 2 nghiem x1=%.2f,x2=%.2f\n",(-b+sqrt(denta))/(2*a),(-b-sqrt(denta))/(2*a));
    }
  return 0;
}
