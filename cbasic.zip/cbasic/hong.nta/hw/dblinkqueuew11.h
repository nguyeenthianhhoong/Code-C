struct node {
  elementtype element;
  struct node* next;
  struct node* prev;
};
typedef struct node queue;

//tao nut moi;
queue* makeNewNodeQueue(elementtype el) {
  queue* new = (queue*)malloc(sizeof(queue));
  new->element = el;
  new->next = NULL;
  new->prev = NULL;
  return new;
}
//kiem tra rong
int emptyQueue(queue* front1) {
  return front1 == NULL;
}
//them vao queue
void enQueue(queue** front, queue** rear, elementtype el) {
  queue* new = makeNewNodeQueue(el);
  if(*rear==NULL) {
    *front = new;
    *rear = *front;
  }else {
    (*rear)->next = new;
    new->prev = *rear;
    *rear = new;
  }
}
//lay khoi queue
void deQueue(queue** front, queue** rear) {
  if(*front == NULL) return ;
  else {
    queue* cur = *front;
    *front = (*front)->next;
    free(cur);
  }
}
//xoa queue
void freeQueue(queue** front) {
  queue* cur1;
  for(cur1=*front; cur1!=NULL; cur1=cur1->next) {
    *front = (*front)->next;
    free(cur1);
    cur1 = *front;
  }
}
//display queue
void displayQueue(queue* front1) {
  queue* cur1;
  for(cur1=front1; cur1!=NULL; cur1=cur1->next) {
    printf("\t%d\t\t\t\t%d\n", (cur1->element).id, (cur1->element).memory);
  }
}
