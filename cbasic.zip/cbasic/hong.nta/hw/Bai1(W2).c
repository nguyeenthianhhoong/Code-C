#include <stdio.h>
#include <string.h>
#include <stdlib.h>
enum {SUCCESS,FAIL};
char mycp(char file1[],char file2[])
{
  FILE *lab,*lab1w;
 
  int reval = SUCCESS;
  if((lab = fopen(file1,"r"))==NULL)
    {
      printf("canot open %s.\n",file1);
      reval = FAIL;
    }
  else if((lab1w = fopen(file2,"w"))==NULL)
    {
      printf("canot open %s.\n",file2);
      reval = FAIL;
    }else{
    int c;
    while ((c=fgetc(lab)) != EOF)
      {
	fputc(c, lab1w);
	putchar(c);
      }
    fclose(lab);
    fclose(lab1w);
  }

  return reval;
}
int main()
{
  
    char lenh[50];
  int vitri1,vitri2,i,j;
  char file1[20],file2[20];
  printf("nhap cau lenh (mycpy file1.txt file2.txt) de copy file1 vao file2\n");
  scanf("%[^\n]s",lenh);
  scanf("%*c");
  for(vitri1 = strlen(lenh);vitri1 >=0; vitri1--)
    if(lenh[vitri1] == ' ')break;
  for(vitri2 = vitri1-1; vitri2 >= 0; vitri2--)
    if(lenh[vitri2] == ' ')break;
  for( i=vitri1+1;i<strlen(lenh);i++)
    file2[i-(vitri1+1)] = lenh[i];
  file2[i-(vitri1+1)] = '\0';
  for(j=vitri2+1;j<vitri1;j++)
    file1[j-(vitri2+1)] = lenh[j];
  file1[j-(vitri2+1)] = '\0';
  mycp(file1,file2);
  return 0;
}
