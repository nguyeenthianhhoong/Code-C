#include <stdio.h>
#define LEN 10
int main(void)
{
  int i=0,
    count[LEN] = {0};
  char c='\0';
  printf("nhap day: \n");
  c = getchar();
  while(c!='\n'&& c >= 0)
    {
      if(c <= '9' && c >= '0')
	++count[c-'0'];
	  c=getchar();
    }
  for(i=0;i<LEN;++i)
    {
      if(count[i]>0)
	printf("so %c xuat hien %d lan\n",'0'+i,count[i]);
    }
  return 0;
}


