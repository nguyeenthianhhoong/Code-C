#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct _node
{
    struct _data
    {
        char word[20];
        char mean[100];
    } data;
    struct _node *left, *right;
} node;

void insertNode(node** root, char word[], char mean[])
{
    if (*root == NULL)
    {
        *root = (node*)malloc(sizeof(node));
        strcpy((*root)->data.word, word);
        strcpy((*root)->data.mean, mean);
        (*root)->left = NULL;
        (*root)->right = NULL;
    }
    else if (strcmp((*root)->data.word, word) < 0)
        insertNode(&(*root)->right, word, mean);
    else if (strcmp((*root)->data.word, word) > 0)
        insertNode(&(*root)->left, word, mean);
}
void readFile(node **root)
{
    FILE *f = fopen("tu_dien_20184218.txt", "r");
    if(f == NULL)
    {
        printf("Can't open file\n");
        return;
    }
    
    char st[100];
    while(fgets(st, 100, f) != NULL)
    {
        char *word = strtok(st, " ");
        char *mean = strtok(NULL, "\n");
        insertNode(root, word, mean);
    }
}
void preOrder(node* root){
     if (root != NULL)
     {
     printf("%s \n",root->data.word);
     preOrder(root->left);
     preOrder(root->right);
     }	
}
node* search(node* root, char* word)
{
    if (root == NULL || strcmp(word, root->data.word) == 0)
       return root->data.mean;
    if (strcmp(word, root->data.word) < 0)
       return search(root->left, word);
    else
        return search(root->right,word);
}
void main(){
    char tmpWord[21], tmpMeaning[101], item[122];
  char *tmpWord1; tmpWord1 = (char*)calloc(21, sizeof(char)); 
  char *tmpMeaning1; tmpMeaning1 = (char*)calloc(101, sizeof(char));
node* root = NULL;
int select;
 while(1){
 printf("===========MENU========== \n");
 printf("1.Duyet theo chieu sau va in ra BST      \n");
 printf("2.Them tu moi \n");
 printf("3.Tra tu \n");
 printf("End \n");
 printf("Nhap lua chon cua ban \t");
            printf(">>> "); scanf("%d", &select);
            switch (select)
            {
            case 1:
	      readFile(&root);
	      preOrder(root);
	      printf("\n");
                break;
            case 2:
	   printf("Nhap <tu> <nghia> : ");
	  scanf("%s %s", &tmpWord, &tmpMeaning);
          strcpy(tmpMeaning1,tmpMeaning);
          strcpy(tmpWord1,tmpWord);
          root = InsertNode(root,tmpWord1,tmpMeaning1);
	      
                break;
            case 3:
               
                return;
            default:
                break;
            }
        }
}
