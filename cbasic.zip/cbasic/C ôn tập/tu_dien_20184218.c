#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct _node
{
    struct _data
    {
        char word[20];
        char mean[100];
    } data;
    struct _node *left, *right;
} node;

void insertNode(node** root, char word[], char mean[])
{
    if (*root == NULL)
    {
        *root = (node*)malloc(sizeof(node));
        strcpy((*root)->data.word, word);
        strcpy((*root)->data.mean, mean);
        (*root)->left = NULL;
        (*root)->right = NULL;
    }
    else if (strcmp((*root)->data.word, word) < 0)
        insertNode(&(*root)->right, word, mean);
    else if (strcmp((*root)->data.word, word) > 0)
        insertNode(&(*root)->left, word, mean);
}
void readFile(node **root,char* thamso)
{
    FILE *f = fopen(thamso, "r");
    if(f == NULL)
    {
        printf("Can't open file\n");
        return;
    }
    
    char st[100];
    while(fgets(st, 100, f) != NULL)
    {
        char *word = strtok(st, " ");
        char *mean = strtok(NULL, "\n");
        insertNode(root, word, mean);
    }
}
void preOrder(node* root){
     if (root != NULL)
     {
     printf("%s \n",root->data.word);
     preOrder(root->left);
     preOrder(root->right);
     }	
}
node* Search(node *root, char *word)
{
  if (root != NULL)
    {
      if (strcmp(word,root->data.word) == 0)
	{
	  return root;
	};
       if (strcmp(word,root->data.word) > 0)
      Search(root->left,word);
        if (strcmp(word,root->data.word) < 0)
      Search(root->right,word);
    };
};
void main(int argn, char** argv){
  node* root = NULL;
  readFile(&root,argv[1]);
  char tu;
  char word[20], mean[100];
  char *word1; word1 = (char*)calloc(21, sizeof(char)); 
  char *mean1; mean1 = (char*)calloc(101, sizeof(char));

int select;
 while(1){
 printf("===========MENU========== \n");
 printf("1.Duyet theo chieu sau va in ra BST      \n");
 printf("2.Them tu moi \n");
 printf("3.Tra tu \n");
 printf("End \n");
 printf("Nhap lua chon cua ban \t");
            printf(">>> "); scanf("%d", &select);
            switch (select)
            {
            case 1:
	      
	      preOrder(root);
	      printf("\n");
                break;
            case 2:
	   printf("Nhap <tu> <nghia> : ");
	  scanf("%s %s", &word, &mean);
          strcpy(mean1,mean);
          strcpy(word1,word);
           insertNode(&root,word1,mean1);	    
                break;
            case 3:
	      printf("Nhap tu can tra: \t");
		scanf("%s",&tu);
		// Search(root,tu);
                return;
            default:
                break;
            }
        }
}
