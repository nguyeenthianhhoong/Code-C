#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct address_t
{
  char name[20];
  char tell[11];
  char email[25];
}address;

typedef address elementtype;
struct list_el
{
  elementtype element;
  struct list_el *next;
};
typedef struct list_el node_addr;
node_addr *root,*cur,*prev;
node_addr *root1,*root2;
int soluong=0;

node_addr *makeNewNode(elementtype element)
{
  node_addr *new = (node_addr*)malloc(sizeof(node_addr));
  new->element=element;
  new->next =NULL;
  return new;
}

void insertAtHead(elementtype element)
{
  node_addr *new = makeNewNode(element);
   if( root == NULL)
    {
      root = new;
      cur = root;
    }else{
  new ->next = root;
  root = new;
  cur = root;
   }
}

void displayNode(node_addr *p)
{
  if(p==NULL)
    {
      printf("Loi con tro\n");
      return;
    }
  elementtype tmp= p->element;
  printf("%-20s\t%-15s\t%-30s\n",tmp.name,tmp.tell,tmp.email);
}
//file cach nhau dau cach
node_addr *importFromText(FILE *fptr1)
{
  elementtype member[20];
	while(!feof(fptr1))
	  {
		fscanf(fptr1,"%s %s %s\n",member[soluong].name,member[soluong].tell,member[soluong].email);
		insertAtHead(member[soluong]);
		soluong++;
	}
	printf("%d\n",soluong);
	
	printf("Thanh cong\n");
	return root;
}
//file cach nhau dau ,
node_addr *importFromText1(FILE *f){
  elementtype key[20];
  char s[56];
  int i=1;
  while (fgets(s,81,f)!=NULL){
    int count=0;
    char *tmp;
    tmp= strtok(s,",");
    while(tmp != NULL){
      if(count==0)
	strcpy(key[i].name,tmp);
      if(count==1)
	strcpy(key[i].tell,tmp);
      if(count==2)
	strcpy(key[i].email,tmp);
      //insertAtHead(key[i]);
      count++;
      tmp=strtok(NULL,",");
    }
    insertAtHead(key[i]);
    i++;
    }
  return root;
}

void traversingList(node_addr *root)
{
  node_addr *p;
  for(p=root; p!= NULL; p=p->next)
    displayNode(p);
}

void freeList(node_addr *root)
{
  node_addr *to_free = root;
  while(to_free != NULL)
    {
      root = root->next;
      free(to_free);
      to_free = root;
    }
}

int main()
{
  FILE *f1;
  int n1,n2;
  f1=fopen("phone1.txt","r");
  if(f1==NULL)
    {
      printf("Cannot file!!!");
      return 0;
    }
  root=importFromText1(f1);
  traversingList(root);
freeList(root);
   fclose(f1);
  return 0;
}
