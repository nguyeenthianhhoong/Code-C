#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct phoneaddress_t{
  char name[20];
  char tel[11];
  char email[30];
}phoneaddress;

typedef struct node{
  phoneaddress data;
  struct node *left, *right;
}nodetype;
typedef nodetype* treetype;

//thêm theo sđt 
void insertnode1(phoneaddress x,treetype *root){
  if(*root==NULL){
    *root=(nodetype*)malloc(sizeof(nodetype));
    (*root)->data=x;
    (*root)->left=NULL;
    (*root)->right=NULL;
  }
  else if(strcmp(((*root)->data).tel,x.tel)>0)
    return insertnode1(x,&(*root)->left);
  else if(strcmp(((*root)->data).tel,x.tel)<0)
    return insertnode1(x,&(*root)->right);
}

// thêm theo tên  
void insertnode2(phoneaddress x,treetype *root){
  if(*root==NULL){
    *root=(nodetype*)malloc(sizeof(nodetype));
    (*root)->data=x;
    (*root)->left=NULL;
    (*root)->right=NULL;
  }
  else if(strcmp(((*root)->data).name,x.name)>0)
    return insertnode1(x,&(*root)->left);
  else if(strcmp(((*root)->data).name,x.name)<0)
    return insertnode1(x,&(*root)->right);
}

//thêm the email 
void insertnode3(phoneaddress x,treetype *root){
  if(root==NULL){
    *root=(nodetype*)malloc(sizeof(nodetype));
    (*root)->data=x;
    (*root)->left=NULL;
    (*root)->right=NULL;
  }
  else if(strcmp(((*root)->data).email,x.email)>0)
    return insertnode2(x,&(*root)->left);
  else if(strcmp(((*root)->data).email,x.email)<0)
    return insertnode2(x,&(*root)->right);
 }
//duyệt theo thứ tự giữa 
void InOrderPrint(treetype root){
  if(root!=NULL){
    InOrderPrint(root->left);
    printf("%-20s%-11s%-30s\n",(root->data).name,(root->data).tel,(root->data).email);
    InOrderPrint(root->right);
  }
}
//duyệt theo thứ tự trước  
void PreOrderPrint(treetype root){
  if(root!=NULL){
    printf("%-20s%-11s%-30s\n",(root->data).name,(root->data).tel,(root->data).email);
    PreOrderPrint(root->left);
    PreOrderPrint(root->right);
  }
}
//duyệt theo thứ tự sau  
void PostOrderPrint(treetype root){
  if(root!=NULL){
    PostOrderPrint(root->left);
    PostOrderPrint(root->right);
    printf("%-20s%-11s%-30s\n",(root->data).name,(root->data).tel,(root->data).email);
  }
}
//search node
treetype Search(char x[11],treetype Root)
{
  if(Root == NULL)return NULL;
  else if (strcmp((Root->data).tel, x)==0)
    return Root;
  else if(strcmp((Root->data).tel, x)<0)
    return Search(x, Root->right);
  else
    {
      return Search(x, Root->left);
    }
}

//xóa node 
phoneaddress DeleteMin(treetype *Root)
{
  phoneaddress k;
  if((*Root)->left == NULL)
    {
      k=(*Root)->data;
      (*Root) = (*Root)->right;
      return k;
    }
  else return DeleteMin(&(*Root)->left);
}
void DeleteNode(char x[11],treetype *Root)
{
  if(*Root!=NULL)
    {
    if(strcmp(((*Root)->data).tel, x)>0) DeleteNode(x,&(*Root)->left);
    else if(strcmp(((*Root)->data).tel, x)<0) DeleteNode(x,&(*Root)->right);
    else if((*Root)->left==NULL&&(*Root)->left==NULL) *Root=NULL;
    else if((*Root)->left==NULL)
    *Root=(*Root)->right;
    else if((*Root)->right==NULL)
    *Root=(*Root)->left;
    else (*Root)->data = DeleteMin(&(*Root)->right);
  
    }			 
}

void FreeTree(treetype root){
  if(root!=NULL){
    FreeTree(root->left);
    FreeTree(root->right);
    free(root);
  }
}

int main(){
  phoneaddress p[20];
  int i=0;
  treetype root=NULL;
  FILE *f;
  if((f=fopen("phone.txt","r"))==NULL){
    printf("cannot open file\n");
    return 0;
  }
  while (!feof(f)){
    fscanf(f,"%s %s %s\n",p[i].name,p[i].tel,p[i].email);
    insertnode1(p[i],&root);
    //insertnode2(p[i],&root);
    i++;
  }
  //PreOrderPrint(root);
  InOrderPrint(root);
  //PostOrderPrint(root);
  fclose(f);
  FreeTree(root);
  return 0;
}
