#include<stdio.h>
#include<malloc.h>
#include<string.h>

typedef struct _Node
{
  char *word;
  char *meaning;
  struct _Node *left;
  struct _Node *right;
}NODE;

NODE *root = NULL;

NODE* InsertNode(NODE* root, char *word, char *meaning)
{
  if (root == NULL)
    {
      NODE* tmp = (NODE*)calloc(1, sizeof(NODE));
      tmp->word = (char*)calloc(1, strlen(word) + 1);
      strcpy(tmp->word, word);
      tmp->meaning = (char*)calloc(1, strlen(meaning) + 1);
      strcpy(tmp->meaning, meaning);
      tmp->left = NULL;
      tmp->right = NULL;
      return tmp;
    }else
    {
      if (strcmp(root->word, word) < 0)
	{
	  root->right = InsertNode(root->right, word, meaning);
	}else if (strcmp(root->word, word) > 0)
	{
	  root->left = InsertNode(root->left, word, meaning);
	}
      return root;
    }
}

void Print1(NODE* root)
{
  if (root != NULL)
    {
      printf("%s\n",root->word);
      Print1(root->left);
      Print1(root->right);
    };
}

int Search(NODE *root, char *word)
{
  if (root != NULL)
    {
      printf("%s\n",root->word);
      if (word == root->word)
	{
	  print("Nghia : &s\n",root->word);
	}

int main(int argc, char *argv[])
{
  char tmpWord[21], tmpMeaning[101], item[122];
  char *tmpWord1; tmpWord1 = (char*)calloc(21, sizeof(char)); 
  char *tmpMeaning1; tmpMeaning1 = (char*)calloc(101, sizeof(char));
  int x = 0, n = 0, kt = 0;
  if (argc != 2)
    {
      printf("Invalid command line arguments, check the input and try again ! \n");
      return -1;
    };
  FILE *f1;
  char *f1name; f1name = argv[1];
  if ((f1 = fopen(f1name,"r")) == NULL)
    {
      printf("Cannot open \"%s\" ! Check it and try again. \n",f1name);
      return -1;
    };
  printf("Noi dung file :\n");
  do
    {
      n = 0;
      fgets(item,121,f1);
      if (!feof(f1))
	{
	  puts(item);
	}else
	{
	  break;
	};
      x = strlen(item);
      item[x-1] = NULL;
      kt = 0;
      while((item[n] != ' ') && (n<=x))
	{
	  if (item[n] == ' ') kt = 1;
	  n++;
	};
      strncpy(tmpWord,item,n);
      tmpWord[n] = NULL;
      for (int k = 0; k < x-n-1; k++)
	{
	  item[k] = item[n+k+1];
	};
      item[x-n-1] = NULL;
      strcpy(tmpMeaning,item);
      tmpMeaning[x-n-1] = NULL;
      strcpy(tmpMeaning1,tmpMeaning);
      strcpy(tmpWord1,tmpWord);
      root = InsertNode(root,tmpWord1,tmpMeaning1);
    }while(!feof(f1));
  printf("\n");
  printf("Menu :\n");
  do
    {
      printf("1 : Duyet cay nhi phan.\n2 : Nhap them tu.\n3 : Dich.\n4 : Thoat chuong trinh.\n");
      printf("Chon : ");
      scanf("%d",&x);
      if ((x<=0) || (x>4)) printf("Moi nhap so tu 1 den 4 theo Menu :\n");
      if (x == 1) Print1(root);
      if (x == 2)
	{
	  printf("Nhap <tu> <nghia> : ");
	  scanf("%s %s", &tmpWord, &tmpMeaning);
          strcpy(tmpMeaning1,tmpMeaning);
          strcpy(tmpWord1,tmpWord);
          root = InsertNode(root,tmpWord1,tmpMeaning1);
	};
      if (x == 3)
	{
    }while((x>0) && (x<4));
  fclose(f1);
};
