#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct tu_dien_t{
  char english[25];
  char mean[25];
}tudien;

typedef struct node{
  tudien data;
  struct node *left, *right;
}nodetype;
typedef nodetype* treetype;
treetype *root;

void insertnode(tudien x,treetype *root){
  if(*root==NULL){
    *root=(nodetype*)malloc(sizeof(nodetype));
    (*root)->data=x;
    (*root)->left=NULL;
    (*root)->right=NULL;
  }
  else if(strcmp(((*root)->data).english,x.english)>0)
    return insertnode(x,&(*root)->left);
  else if(strcmp(((*root)->data).english,x.english)<0)
    return insertnode(x,&(*root)->right);
}

void InOrderPrint(treetype root){
  if(root!=NULL){
    InOrderPrint(root->left);
    printf("%-25s%-25s\n",(root->data).english,(root->data).mean);
    InOrderPrint(root->right);
  }
}

treetype Search(char x[25],treetype Root)
{
  if(Root == NULL)return NULL;
  else if (strcmp((Root->data).english, x)==0)
    return Root;
  else if(strcmp((Root->data).english, x)<0)
    return Search(x, Root->right);
  else
    {
      return Search(x, Root->left);
    }
}

void edit(treetype **root,char new[25]){
  char s;
  treetype *p = Search(new,root);
	if(p == NULL){
		tudien key;
		printf("Khong tim thay\n");
		strcpy(key.english,new);
		printf("Mean:");
		scanf("%s",key.mean);
		insertnode(key,&root);
		InOrderPrint(root);
	}
	/*
       	else{
	   printf("Tim thay\n");
	  printf("Ban co muon sua noi dung(y/n):");
	  scanf("%c",&s);
	  if(s=='y'){
		  printf("Mean:");
		  scanf("%s",p->key.mean);
	     }
	     }

	*/
}

void FreeTree(treetype root){
  if(root!=NULL){
    FreeTree(root->left);
    FreeTree(root->right);
    free(root);
  }
}

int main(){
  treetype root=NULL;
  tudien a[20];
  int i=0;
  int choice;
  FILE *f;
  if((f=fopen("dict.txt","r"))==NULL){
    printf("cannot open file dict.txt\n");
    return 0;
  }
  char word[25],s[1];   
  

do{
    printf("\t\tMENU:\n");
    printf("\t1. IMPORT FROM TEXT\n");
    printf("\t2. DISPLAY\n");
    printf("\t3. INSERT/EDIT WORD\n");
    printf("\t4. TRANSLATE\n");
    printf("\t5. QUIT\n");
    do{
      printf("Input a choice:");
      scanf("%d",&choice);
    }
    while (choice < 1|| choice >5 );
    switch(choice){

    case 1:
      	while(!feof(f))
	  {
	    fscanf(f,"%s %s\n",a[i].english,a[i].mean);
		printf("%-25s%-25s\n",a[i].english,a[i].mean);
		 insertnode(a[i],&root);
        	i++;
 	}
        printf("\n");
	printf("Success!\n\n");
     
      fclose(f);
      break;
    
    case 2:
      InOrderPrint(root);
   
      break;
    
    case 3:
      printf("Enter word:");
      scanf("%s",&word);
      edit(root,word);
  
     
      break;
    
    case 4:
     
      break;
    
    case 5:
      FreeTree(root);
      printf("byeee\n");

      break;

     
    }
    } while (choice!=5);
    return 0;


}
