#include <stdio.h>
#include <stdlib.h>
typedef int etype;
typedef struct nodeType{
  etype e;
  struct nodeType *left,*right;
}nodeType;
typedef nodeType *treetype;
void MakeNullTree(treetype *T){ 
  (*T)=NULL; 
} 
int EmptyTree(treetype T){ 
  return T==NULL; 
}
treetype LeftChild(treetype n)
{ 
  if (n!=NULL) return n->left; 
  else return NULL;
}
treetype RightChild(treetype n)
{ 
  if (n!=NULL) return n->right;
  else return NULL;
}
nodeType *createNode(etype data){
  nodeType *new;
  new=(nodeType*)malloc(sizeof(nodeType));
  if(new!=NULL)
    {
      new->left=NULL;
      new->right=NULL;
      new->e=data;
    }
  return new;
}
int IsLeaf(treetype n){
  if(n!=NULL) 
    return(LeftChild(n)==NULL)&&(RightChild(n)==NULL); 
  else return -1; 
}
treetype AddLeft(treetype *T, etype NewData){
  nodeType *NewNode = createNode(NewData);
  if (NewNode == NULL) return (NewNode);
  if (*T == NULL)
    *T = NewNode;
  else{
    nodeType *Lnode = *T;
    while (Lnode->left != NULL)
      Lnode = Lnode->left;
    Lnode->left = NewNode;
  }
  return (NewNode);
}
treetype AddRight(treetype *T, etype NewData){
  nodeType *NewNode = createNode(NewData);
  if (NewNode == NULL) return (NewNode);
  if (*T == NULL)
    *T = NewNode;
  else{
    nodeType *Rnode = *T;
    while (Rnode->right != NULL)
      Rnode = Rnode->right;
    Rnode->right = NewNode;
  }
  return (NewNode);
}
void inorderPrint(treetype T){
  if (T != NULL)
    {
      inorderPrint(T->left);
      printf("%d\n",T->e);
      inorderPrint(T->right);
    }
}

int nb_Nodes(treetype T){ 
  if(EmptyTree(T)) return 0; 
  else return
	 1+nb_Nodes(LeftChild(T))+nb_Nodes(RightChild(T)); 
}

int height(treetype T){
  if(EmptyTree(T)) return 0;
  else{
    int Lheight=height(T->left);
    int Rheight=height(T->right);
    if(Lheight>Rheight) return (Lheight+1);
    else return (Rheight+1);
  }
}

int countLeaf=0;
int nb_Leaf(treetype T){
  if(T != NULL)
    {
      nb_Leaf(T->left);
      if((T->left == NULL)&&(T->right == NULL))
	{
	  countLeaf++; 
	}
      nb_Leaf(T->right);
    }
  return countLeaf;
}
int countIn=0;
int nb_Internal(treetype T){
  if(T != NULL)
    {
      nb_Internal(T->left);
      if((T->left != NULL)||(T->right !=NULL))
	{
	  countIn ++;
	}
      nb_Internal(T->right);
    }
  return countIn;
}
int nb_Rchild(treetype T){
  if(EmptyTree(T)) return 0;
  if(T->right) return 1+nb_Rchild(T->right)+nb_Rchild(T->left);
  else return nb_Rchild(T->left);
}
int main(){
  nodeType *n1,*n2,*n3,*n4,*n5,*n6;
  n1 =createNode(1);
  n2=AddLeft(&n1,2);
  n3=AddRight(&n1,3);
  n4=AddLeft(&n2,18);
  n5=AddLeft(&n4,6);
  printf("Height:%d\n",height(n1));
  printf("Number of leaf nodes:%d\n",nb_Leaf(n1));
  printf("Number of internal nodes:%d\n",nb_Internal(n1));
  printf("Number of rigth child:%d\n",nb_Rchild(n1));
  return 0;
}
  
