typedef char elmtype;
typedef struct nodeType{
  elmtype data[20];
  struct nodeType *left, *right;
}nodeType;
typedef struct nodeType *treetype;

void MakeNullTree(treetype *T);
int EmptyTree(treetype T);
treetype LeftChild(treetype n);
treetype RightChild(treetype n);
nodeType *create_node(elmtype *NewData);
int IsLeaf(treetype n);
int nb_nodes(treetype T);
treetype createfrom2(elmtype *v, treetype l, treetype r);
treetype Add_Left(treetype *Tree, elmtype *NewData);
treetype Add_Right(treetype *Tree, elmtype *NewData);
void inorderprint(treetype tree);

void MakeNullTree(treetype *T){ 
  (*T) = NULL; 
}

int EmptyTree(treetype T){ 
  return T == NULL; 
}

treetype LeftChild(treetype n){ 
  if (n != NULL)
    return n->left; 
  else
    return NULL;
}

treetype RightChild(treetype n){ 
  if (n != NULL)
    return n->right;
  else
    return NULL;
}

nodeType *create_node(elmtype *NewData){ 
  nodeType *N;
  N=(nodeType *)malloc(sizeof(nodeType));
  if (N != NULL){ 
    N->left = NULL;
    N->right = NULL;
    strcpy(N->data,NewData);
  }
  return N;
}

int IsLeaf(treetype n){
  if(n != NULL) 
    return (LeftChild(n) == NULL) && (RightChild(n) == NULL); 
  else return -1; 
}

int nb_nodes(treetype T){
  if(EmptyTree(T))
    return 0;
  else
    return 1 + nb_nodes(LeftChild(T)) + nb_nodes(RightChild(T));
}

treetype createfrom2(elmtype *v, treetype l, treetype r){ 
  treetype N;
  N=(nodeType *)malloc(sizeof(nodeType));
  strcpy(N->data,v);
  N->left = l; 
  N->right = r;
  return N;
}

treetype Add_Left(treetype *Tree, elmtype *NewData){
  nodeType *NewNode = create_node(NewData);
  if (NewNode == NULL)
    return (NewNode);
  if (*Tree == NULL)
    *Tree = NewNode;
  else{
    nodeType *Lnode = *Tree;
    while (Lnode->left != NULL)
      Lnode = Lnode->left;
    Lnode->left = NewNode;
  }
  return (NewNode);
}

treetype Add_Right(treetype *Tree, elmtype *NewData){
  nodeType *NewNode = create_node(NewData);
  if (NewNode == NULL)
    return (NewNode);
  if (*Tree == NULL)
    *Tree = NewNode;
  else{
    nodeType *Rnode = *Tree;
    while (Rnode->right != NULL)
      Rnode = Rnode->right;
    Rnode->right = NewNode;
  }
  return (NewNode);
}

void inorderprint(treetype tree){
  if(tree != NULL){
    inorderprint(tree->left);
    printf("%s", tree->data);
    inorderprint(tree->right);
  }
}
