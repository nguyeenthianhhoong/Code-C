#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include"binarytree_bangdau.h"

int main(){
  FILE *ptr1,*ptr2;
  char *data;
  char a;
  treetype round1[16],round2[8],round3[4],round4[2],final;
  ptr1=fopen("USopen.txt","r");
  ptr2=fopen("treegame.txt","w");
  if (ptr1==NULL||ptr2==NULL){
    printf("CANNOT OPEN FILE\n");
    exit(1);
  }  
  for(int i = 0; i < 16; i++){
    int j = 0;
    data = (char *)malloc(50*sizeof(char));
    while ((a = fgetc(ptr1)) != ' ' && a!=EOF){
      data[j] = a;
      j = j+1;
    }
    round1[i] = create_node(data);
    for (int k = 0; k < strlen(data); k++)
      free(data);
  } //ham doc du lieu tu file thi dau USopen
  int k,j = 0;
  srand((int)time(0));
  for (int i = 0; i < 16;i = i+2){
    k = rand()%2;
    if (k==0){
      round2[j] = createfrom2(round1[i]->data,round1[i],round1[i+1]);
    }
    else{
      round2[j] = createfrom2(round1[i+1]->data,round1[i],round1[i+1]);
    }
    j+=1;
    }
  j=0;
  for (int i=0;i<8;i=i+2){
    k=rand()%2;
    if (k==0){
      round3[j]=createfrom2(round2[i]->data,round2[i],round2[i+1]);
    }
    else{
      round3[j]=createfrom2(round2[i+1]->data,round2[i],round2[i+1]);
    }
    j+=1;
  }
  j=0;
  for (int i=0;i<4;i=i+2){
    k=rand()%2;
    if (k==0){
      round4[j]=createfrom2(round3[i]->data,round3[i],round2[i+1]);
    }
    else{
      round4[j]=createfrom2(round3[i+1]->data,round3[i],round3[i+1]);
    }
    j+=1;
    }
  
  k=rand()%2;
  if (k==0)
    final=createfrom2(round4[0]->data,round4[0],round4[1]);
  else
    final=createfrom2(round4[1]->data,round4[0],round4[1]);
  for (int i = 0;i < 16;i++){
    fprintf(ptr2,"%s ",round1[i]->data);
    printf("%s ",round1[i]->data);
  }
  printf("\n");
  for(int i = 0;i < 8; i++){
    fprintf(ptr2,"%s ",round2[i]->data);
    printf("%s ",round2[i]->data);
  }
  printf("\n");
  fprintf(ptr2,"\n");
  for (int i = 0; i < 4; i++){
    fprintf(ptr2,"%s ",round3[i]->data);
    printf("%s ",round3[i]->data);
  }
  printf("\n");
  fprintf(ptr2,"\n");
  for (int i=0;i<2;i++){
    fprintf(ptr2,"%s ",round4[i]->data);
    printf("%s", round4[i]->data);
  }
  fprintf(ptr2,"\n%s",final->data);
  printf("\n%s\n",final->data);
  free(data);
  fclose(ptr1);
  fclose(ptr2);
  return 0;
}

