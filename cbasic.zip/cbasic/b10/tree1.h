#include<stdio.h>
#include<stdlib.h>

typedef int elementtype;
typedef struct nodetype{
  elementtype element;
  struct nodetype *left,*right;
}node;
typedef struct nodetype *treetype;

void MakeNullTree(treetype *T){
  (*T)=NULL;
}

int EmptyTree(treetype T){
  return T==NULL;
}

treetype LeftChild(treetype n){
  if(n!=NULL)
    return n->left;
  else return NULL;
}

treetype RightChild(treetype n){
  if(n!=NULL)
    return n->left;
  else return NULL;
}

node *create_node(elementtype newdata)
{
  node *N=(node*)malloc (sizeof(node));
  if(N!=NULL)
    {
      N->left=NULL;
      N->right=NULL;
      N->element=newdata;
    }
  return N;
}

int IsLeaf(treetype n)
{
  if(n!=NULL)
    return(LeftChild(n)==NULL)&&(RightChild(n)==NULL);
  else return -1;
}

treetype createfrom2(elementtype v,treetype l,treetype r)
{
  treetype N;
  N=(node*)malloc(sizeof(node));
  N->element=v;
  N->left=l;
  N->right=r;
  return N;
}

treetype Add_left(treetype *tree,elementtype Newdata){
  node *Newnode=create_node(Newdata);
  if(Newnode==NULL)
    return (Newnode);
  if(*tree==NULL)
    *tree=Newnode;
  else{
    node *Lnode=*tree;
    while(Lnode->left!=NULL)
      Lnode=Lnode->left;
    Lnode->left=Newnode;
  }
  return (Newnode);
}

treetype Add_right(treetype *tree,elementtype Newdata){
  node *Newnode=create_node(Newdata);
  if(Newnode==NULL)
    return (Newnode);
  if(*tree==NULL)
    *tree=Newnode;
  else{
    node *Rnode=*tree;
    while(Rnode->right!=NULL)
      Rnode=Rnode->right;
    Rnode->right=Newnode;
  }
  return (Newnode);
}

void inorderprint(treetype tree){
  if(tree!=NULL){
    inorderprint(tree->left);
    printf("%4d\n",tree->element);
    inorderprint(tree->right);
  }
}

int nb_nodes(treetype T){
  if(EmptyTree(T))
    return 0;
  else return 1+nb_nodes(LeftChild(T))+nb_nodes(RightChild(T));
}

treetype search(elementtype x,treetype root){
  if(root==NULL)
    return NULL;
  else if(root->element==x)
    return root;
  else if(root->element <x)
    return search(x,root->right);
  else{
    return search(x,root->left);
  }
}

void insertnode(elementtype x,treetype *Root ){
  if (*Root == NULL){
    *Root=(node*)malloc(sizeof(node));
    (*Root)->element = x;
    (*Root)->left = NULL;
    (*Root)->right = NULL;
   }
   else if (x < (*Root)->element)
     insertnode(x,&(*Root)->left);
   else if (x>(*Root)->element)
     insertnode(x, &(*Root)->right);
}

elementtype DeleteMin (treetype *Root ){
elementtype k;
if ((*Root)->left == NULL){
k=(*Root)->element;
(*Root) = (*Root)->right;
return k;
}
else return DeleteMin(&(*Root)->left);
}

void Deletenode(elementtype x,treetype *root){
  if(*root!=NULL)
    if(x<(*root)->element)
      Deletenode(x,&(*root)->left);
    else if (x>(*root)->element)
      Deletenode(x,&(*root)->right);
    else if (((*root)->left==NULL)&&((*root)->right==NULL))
				   *root=NULL;
    else if ((*root)->left==NULL)
      *root=(*root)->right;
    else if ((*root)->right==NULL)
      *root=(*root)->left;
    else (*root)->element=DeleteMin(&(*root)->right);
					    
}
