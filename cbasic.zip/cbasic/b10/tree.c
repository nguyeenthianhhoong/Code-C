#include"tree1.h"

int main(){
  int a[10]={4,9,5,100,26,-18,13,77,1,34};
  int i;
  treetype root;
  MakeNullTree(&root);
  for(i=0;i<10;i++){
    insertnode(a[i],&root);
}
  inorderprint(root);
  Deletenode(100,&root);
  printf("after deletenode\n");
  inorderprint(root);
  return 0;
}
