#include<stdio.h>
#include<stdlib.h>
enum{success,fail,max=500};

int main(){
  FILE *fin,*fout;
  char filename1[]="bangdiem.txt";
  int reval=fail,choice;
  if((fin=fopen(filename1,"r"))==NULL){
    printf("cannot open");
    reval=fail;
    exit(1);
  } else if((fout=fopen("grade.dat","w+b"))==NULL){
    printf("cannot open");
    reval=fail;
  }else{


  do{
    printf("MENU\n");
    printf("1.Text2Dat\n");
        printf("2. Display Dat file\n");
        printf("3. Search and Update\n");
        printf("4. Quit\n");
        
        do{
            printf("Input a choice: ");
            scanf("%d", &choice);
        } while (choice < 1 || choice > 4);
        
        switch(choice){
            case 1:
	      texttobinary(fin,fout);
	      break;
	      
            case 2:

	      
            case 3:

	      
            case 4:
                printf("Bye bye\n");
                break;
        }
    } while (choice != 4);
  }
}

void texttobinary(FILE *fin,FILE *fout)
{
  char *p;
  int num;
  // char buff[max];

  p=(char *)malloc(max);
  if(p==NULL){
    printf("allocation failed, check memory");
    return NULL;
  }
  while(!feof(fin)){
    num=fread(p,sizeof(char),max,fin);
    p[num *sizeof(char)]='\0';
    fwrite(p,sizeof(char),num,fout);
  }
  fclose(fin);
  fclose(fout);
  
}
