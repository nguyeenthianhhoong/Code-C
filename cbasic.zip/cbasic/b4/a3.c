#include<stdio.h>
#include<stdlib.h>

enum{success,fail,max=100};

int main(){
  int num;
  FILE *ptr1,*ptr2;
  char filename1[]="1.txt",filename2[]="2.txt";
  int reval=success;
  if((ptr1=fopen(filename1,"r"))==NULL){
    printf("cannot open");
    reval=fail;
    exit(1);
  } else if((ptr2=fopen(filename2,"w"))==NULL){
    printf("cannot open");
    reval=fail;
    exit(1);
  }else{
    blockreadwrite(ptr1,ptr2);
    fclose(ptr1);
    fclose(ptr2);
  }
  return 0;
}
void blockreadwrite(FILE *fin,FILE *fout){
  int num;
  char buff[max+1];
  while(!feof(fin)){
    num=fread(buff,sizeof(char),max,fin);
     /*buff[num *sizeof(char)]='\0';*/
    printf("%s",buff);
    fwrite(buff,sizeof(char),num,fout);
  }
}
