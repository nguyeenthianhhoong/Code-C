#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define max 10
char *my_strcat(char *str1,char *str2){
  int len1,len2;
  char *p;
  len1=strlen(str1);
  len2=strlen(str2);
  p=(char *)malloc((len1+len2+1)*sizeof(char));
  if(p==NULL){
    printf("allocation failed, check memory");
    return NULL;
  }
  strcpy(p,str1);
  strcpy(p+len1,str2);
  return p;

  /*c2:for(i=0;i<len1;i++)
  result[i]=str1[i];
  for(i=len1;i<len1+len2;i++)
    result[i]=str[i]
    result[i+1]='\0'*/
  
}
int main(){
  char str1[max+1],str2[max+1];
  char *cat_str;
  printf("enter two strings:\n");
  scanf("%s",str1);
  scanf("%s",str2);
  cat_str=my_strcat(str1,str2);
  if(cat_str==NULL){
    printf("problem allocating memory");
  }
  printf("the concatenation of %s and %s is:\n%s\n",str1,str2,cat_str);
  free(cat_str);
  return 0;
}
