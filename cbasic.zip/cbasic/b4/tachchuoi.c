#include<stdio.h>
#include<stdlib.h>
#define max 100

char *substr(char *str,int offset,int number)
{
  char *pointer;
  int i;

  pointer=(char *)malloc(number+1);
  if(pointer==NULL){
    printf("allocation failed,,,check memory");
    return NULL;
  }

  for(i=0;i<number;i++){
    *(pointer+i)=*(str+offset-1);
    str++;
  }
  *(pointer+i)='\0';
  return pointer;
}

int main(){
  char s[max],*p;
  int a,b;
  printf("input a string\n");
  scanf("%s",&s);
  printf("input offset and number:");
  scanf("%d %d",&a,&b);
  p=substr(s,a,b);
  printf("substring of s1:\n%s\n",p);
  free(p);
  return 0;

}
