#include<stdio.h>
#include<stdlib.h>
#include<string.h>

enum{success,fail,max=5};
typedef struct phoneaddress_t{
  char name[20];
  char tel[11];
  char email[25];
}phoneaddress;


int main(){
  FILE *fp;
  phoneaddress pa[max];
  int i,irc;
  int reval=success;
  printf("read from 2sd data to 3rd data\n");
  if((fp=fopen("phonebook.dat","r+b"))==NULL){
    printf("can not open");
    reval=fail;
  }

  pa == (phoneaddress *)malloc(2 * sizeof(phoneaddress));
  if(pa==NULL)
    {
      printf("memory allocation fail");
      return fail;
      
    }

  if(fseek(fp,1*sizeof(phoneaddress),SEEK_SET)!=0)
    {
      printf("fseek failed");
      return fail;
    }
  irc=fread(pa,sizeof(phoneaddress),2,fp);
   for(i=0;i<2;i++){
    printf("%s---",pa[i].name);
    printf("%s---",pa[i].tel);
    printf("%s\n",pa[i].email);
  }
   strcpy(pa[1].name,"Lan Hoa");
   strcpy(pa[1].tel,"0923456");
   strcpy(pa[1].email,"lovelybuffalo@hust.edu.vn");
   fseek(fp,1*sizeof(phoneaddress),SEEK_SET);
    irc=fwrite(pa,sizeof(phoneaddress),2,fp);
    printf("fwrite return code= %d\n",irc);
    fclose(fp);
    free(pa);
    return reval;
}
