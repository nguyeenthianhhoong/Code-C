#include<stdio.h>

#define max 50//top of stack
typedef int eltype; //kieu phan tu mang(kieu int)
typedef eltype stacktype[max];//dinh ngia kieu stacktype la mang max phan tu co kieu eltype
int top;

void initialize(stacktype stack);//khoi tao stack
int empty(stacktype stack);//ktra stack rong
int full(stacktype stack);//ktra stack day
void push(eltype el,stacktype stack);//nap 1 phan tu
eltype pop(stacktype stack);//lay ra phan tu nap sau cung
eltype peek(stacktype stack);

initialize(stacktype stack){
  top=0;
}

empty(stacktype stack){
  return top==0;
}

full(stacktype stack){
  return top==max;
}

 push(eltype el,stacktype stack){
  if(full(stack))
    printf("stack overflow");
  else stack[top++]=el;
}

eltype pop(stacktype stack){
  if(empty(stack))
    printf("stack underflow");
  else return stack[--top];
}

eltype peek(stacktype stack){
  if(empty(stack)){
    printf("stack underflow");
    return -999999;
  }
  else return stack[top-1];
}
