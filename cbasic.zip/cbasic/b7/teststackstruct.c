#include"stackstruct.h"

int main(){
  int a[5]={1,3,4,5,6};
  int i;
  stacktype *s;
  //s=&p;
  initialize(&s);
  for(i=0;i<5;i++)
    push(a[i],&s);
  printf("all elements in stack\n");
  while(!empty(*s))

    printf("%4d\n",pop(&s));
 
 
  return 0;
}
