#include<stdio.h>
#include<string.h>
#include<stdlib.h>
enum{success,fail};

typedef struct phonedb {
  char model[25];
  char memory[10];
  char screen[15];
  char price[15];
}phone;
typedef phone elementtype;
typedef struct node node;
typedef struct node{
  elementtype element;
  node* prev;
  node* next;
};
typedef node* doublelist;
doublelist root,tail,cur;

node* makenewnode(elementtype addr){
  node* new=(node*)malloc(sizeof(node));
  new->element=addr;
  new->next=NULL;
  new->prev=NULL;
  return new;
}

void makeNull_List(doublelist *root,doublelist *tail,doublelist *cur){
  (*root)=NULL;
  (*tail)=NULL;
  (*cur)=NULL;
}

int isempty(doublelist *root){
  return(root==NULL);
}

elementtype readdata(){
  elementtype e;
  printf("model:");
  scanf("%s",e.model);
  printf("memory:");
  scanf("%s",e.memory);
  printf("screen:");
  scanf("%s",e.screen);
  printf("price:");
  scanf("%s",e.price);
  return e;
}

void insertathead(elementtype e,doublelist *root,doublelist *tail,doublelist *cur){
  node* new=makenewnode(e);
  if(*root==NULL)
    *tail=new;
  new->next=*root;
  (*root)->prev=new;
  *root=new;
  *cur=*root;
  printf("done!!");
}

void insertaftercur(elementtype e,doublelist *root,doublelist *tail, doublelist *cur){
  node* new=makenewnode(e);
  if(*root==NULL){
    *root=new;
    *tail=new;
    *cur=*root;
  }else{
    new->next=(*cur)->next;
    if((*cur)->next!=NULL)
      (*cur)->next->prev=new;
    //*cur->next=new;
    new->prev=*cur;
    (*cur)->next=new;
    *cur=new;
    
    if(new->next==NULL)
      *tail=new;
  }
}

void delete_list(doublelist p,doublelist *root ){
  // doublelist p;
  if(*root==NULL)
    printf("empty list");
  else{
    if( p==*root)
      (*root)=(*root)->next;
    else
      p->prev->next=p->next;
    free(p);
  }

}

void searchmodel(doublelist *head){
  char models[20];
  int check;
  printf("Search Model:");
  getchar();
  gets(models);
  for(doublelist p = *head; p != NULL; p = p->next){
    check = strcmp((p->element).model,models);
    if(check == 0){
      printf("%-25s%-10s%-15s%-15s\n\n",(p->element).model, (p->element).memory, (p->element).screen, (p->element).price);
    }
  }
 }

void readdat(FILE *fin){
  elementtype e;
  while(!feof(fin)){
    fread(e.model,25,1,fin);
    fread(e.memory,10,1,fin);
    fread(e.screen,15,1,fin);
    fread(e.price,15,1,fin);
    insertaftercur(e,&root,&tail,&cur);
  }
}

void displaylist(node *head){
  for(node *p=head;p!=NULL;p=p->next){
    printf("%-25s%-10s%-15s%-15s\n",(p->element).model, (p->element).memory, (p->element).screen, (p->element).price);
  }
}

/*void list_reverse(doublelist *root){
  doublelist *cur=root;
  doublelist *prev=NULL;
  doublelist *next;
   while(cur != NULL)
    {
      next =(cur)->next;
      (cur)->next = prev;
      prev=cur;
     cur=next; 
    }
  *root=prev;
 }
 }*/


void exportdat(FILE *file, doublelist *head){
  for(doublelist p = *head; p != NULL; p = p->next){
    fwrite(&(p->element),sizeof(elementtype),1,file);
  }
}

int main(){
  FILE *f,*f1;
  int choice,n,m;
  int reval=success;
  elementtype p;
  doublelist a;

  if((f=fopen("phoneDB.dat","rb"))==NULL){
    printf("cannot open phoneDB.dat\n");
    reval=fail;
  }
  if((f1=fopen("phoneDB1.dat","wb"))==NULL){
    printf("cannot open phoneDB.dat\n");
    reval=fail;
  }

do{
    printf("MENU:\n");
    printf("1.  IMPORT FROM DAT\n");
    printf("2.  DISPLAY\n");
    printf("3.  ADD NEW PHONE\n");
    printf("4.  INSERT AT POSITION\n");
    printf("5.  DELETE AT POSITION\n");
    //printf("5.  DELETE CURRENT\n");
    printf("6.  SEARCH\n");
    //printf("8.  DEVIDE AND EXTRACT\n");
    printf("7.  REVERSE LIST\n");
    printf("8.  SAVE TO FILE\n");
    printf("9.  DELETE LIST\n");
    printf("10. QUIT\n");
    do{
      printf("Input a choice:");
      scanf("%d",&choice);
    }
    while (choice < 1|| choice > 10);
    switch(choice){

    case 1:
      readdat(f);
      printf("Import success\n");
      fclose(f);
      break;
    
    case 2:
      displaylist(root);
      break;
    
    case 3:
    
       p=readdata();
       insertathead(p,&root,&tail,&cur);
       printf("done\n");
       displaylist(root);
      break;
    
    case 4:
     
      break;
    
    case 5:
      printf("vi tri xoa:");
      scanf("%d",&m);
     
      break;

    case 6:
      searchmodel(&root);
      break;

    case 7:
      //list_reverse(&root);
      displaylist(root);
      
      break;

    case 8:
      exportdat(f1,&root);
      printf("save success\n");
      fclose(f1);
      break;

    case 9:
    
      delete_list(root,&root);
      printf("...done!\n");
   
      break;

    case 10:
      printf("byeee\n");
      break;

     
    }
    } while (choice!=10);
    return 0;


}
  



