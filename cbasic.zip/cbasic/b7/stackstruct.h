#include<stdio.h>

#define max 50
typedef int eltype;
typedef struct stackRec{
  eltype storage[max];
  int top;
};
typedef struct stackRec stacktype;

void initialize(stacktype *stack);//khoi tao stack
int empty(stacktype stack);//ktra stack rong
int full(stacktype stack);//ktra stack day
void push(eltype el,stacktype *stack);//nap 1 phan tu
eltype pop(stacktype *stack);//lay ra phan tu nap sau cung
//eltype peek(stacktype *stack);

initialize(stacktype *stack)
{
  (*stack).top=0;
}

empty(stacktype stack)
{
  return stack.top==1;
}

full(stacktype stack)
{
  return stack.top==max;
}

push(eltype el,stacktype *stack)
{
  if(full(*stack))
    printf("stack overflow");
  else(*stack).storage[(*stack).top++]=el;
}

eltype pop(stacktype *stack)
{
  if(empty(*stack))
    printf("stack underflow");
  else return (*stack).storage[--(*stack).top];
}

