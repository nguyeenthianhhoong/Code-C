#include"stack.h"

int main(){
  int a[6]={0,2,4,1,3,5};
  int i;
  stacktype s;
  initialize(s);
  for(i=0;i<6;i++)
    push(a[i],s);
  printf("pop all elements in stack!\n");
  while(!empty(s)){
    printf("%4d\n",pop(s));
  }
  return 0;
}
