#include<stdio.h>
#include<string.h>
#include<stdlib.h>

typedef struct phonedb{
  char model[25];
  char storage[10];
  char  screen[15];
  char cost[15];
}phone;

typedef phone elementtype; 
typedef struct node node;
struct node{ 
  elementtype element; 
  node* next; 
}; 
node *root, *root1; 
node *cur, *cur1;

node* makeNewNode(elementtype addr){
  node* new = (node*)malloc(sizeof(node));
  new->element=addr;
  new->next =NULL;
  return new;
}

void insertAtHead(elementtype addr){
  node* new = makeNewNode(addr);
  new->next = root;
  root = new;
  cur = root;
}

node *insertTail(node *head,node *curr, elementtype data){
  node *temp = makeNewNode(data);
  if(temp == NULL)
    return head;
  if (head == NULL){
    head = temp;
  }
  else{
    curr = head;
    while(curr->next != NULL){
      curr = curr->next;
    }
    curr->next = temp;
  }
  return head;
}

node *ReadData(node* head,node* curr, FILE *file){
  int check = 0;
  elementtype addr;
  while(!feof(file)){
    check = fread(&addr,sizeof(elementtype),1,file);
    if(check != 0)
      head = insertTail(head,curr,addr);
  }
  return head;
}


void getLinkData(node* head){
  printf("\n");
  for (node *p = head; p != NULL; p = p->next){
    printf("%-25s%-10s%-15s%-15s\n",(p->element).model, (p->element).storage, (p->element).screen, (p->element).cost);
  }
}

void searchmodel(node *head){
  char models[20];
  printf("Search Model:");
  getchar();
  gets(models);
  for(node *p = head; p != NULL; p = p->next){
    int check = strcmp((p->element).model,models);
    if(check == 0){
      printf("%-25s%-10s%-15s%-15s\n",(p->element).model, (p->element).storage, (p->element).screen, (p->element).cost);
    }
  }
}

void changecost(node *head){
  for(node *p = head; p != NULL; p = p->next){
    int n = strlen((p->element).cost);
    for(int i = 0; i < n; i++){
      if((p->element).cost[i] == '.'){
	for(int j = i; j < n; j++){
	  (p->element).cost[j] = (p->element).cost[j+1];
	}
	n--;
	i--;
      }
    }
  }
}

void searchvalue(node *head){
  int values;
  printf("Enter value:");
  scanf("%d",&values);
  changecost(head);
  for(node *p = head; p != NULL; p = p->next){
    int check = atoi((p->element).cost);
    if(check < values)
      printf("%-25s%-10s%-15s%-15s\n",(p->element).model, (p->element).storage, (p->element).screen, (p->element).cost);
  }
}

void exportdat(FILE *file, node *head){
  for(node *p = head; p != NULL; p = p->next){
    fwrite(&(p->element),sizeof(elementtype),1,file);
  }
}

int main(){
  FILE *ptr,*ptr1,*ptr2;
  int n=0,choice;
  char a[81];
  node *root = NULL, *root1 = NULL;
  ptr = fopen("NokiaDB.txt","r");
  ptr1 = fopen("NokiaDB.dat","w+b");
  if(ptr1 == NULL || ptr == NULL){
    printf("Cannot open file\n");
    exit(1);
  }
  while(!feof(ptr))
    {
      char c=fgetc(ptr);
      if(c=='\n')
	n++;
    }
  fclose(ptr);
  do{
    printf("Menu:\n");
    printf("1.  IMPORT FROM TEXT\n");
    printf("2.  IMPORT FROM DAT\n");
    printf("3.  DISPLAY LIST\n");
    printf("4.  SEARCH BY MODEL\n");
    printf("5.  SEARCH BY VALUE\n");
    printf("6.  EXPORT TO DAT\n");
    printf("7.  QUIT\n");
    do{
      printf("Input a choice:");
      scanf("%d",&choice);
    }while (choice < 1|| choice > 7);
    switch(choice){
    case 1:{
      ptr = fopen("NokiaDB.txt","r");
      phone *db;
      db=(phone *)malloc(n*sizeof(phone));
      fgets(a,81,ptr);
      for(int i=0; i < n; i++){
	fscanf(ptr,"%s %s %s %s\n",db[i].model, db[i].storage, db[i].screen, db[i].cost);
	root = insertTail(root,cur,db[i]);
       }
      printf("List build success\n");
      fwrite(db,sizeof(phone),n,ptr1);
      fclose(ptr);
      fclose(ptr1);
      break;
    }
    case 2:{
      ptr1 = fopen("NokiaDB.dat","rb");
      root1 = ReadData(root1,cur1,ptr1);
      printf("Import from DAT success\n");
      fclose(ptr1);
      break;
    }
    case 3:{
      getLinkData(root);
      printf("List from text\n");
      getLinkData(root1);
      printf("List from dat\n");
      break;
    }
    case 4:{
      searchmodel(root);
      break;
    }
    case 5:{
      searchvalue(root);
      break;
    }
    case 6:{
      ptr1 = fopen("NokiaDB.dat","wb");
      exportdat(ptr1,root);
      printf("Export success\n");
      fclose(ptr1);
      break;
    }
    }
    } while (choice!=7);
    return 0;
}
