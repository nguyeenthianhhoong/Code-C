#include <stdio.h>
void swap(int* a, int* b)
{
	int tmp = *a;
	*a = *b;
	*b = tmp;
}
void nhapham(int a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		printf("the value of A[%d]= ", i + 1);
		scanf("%d", &a[i]);
	}
}
int main(void)
{
	int n;
	int a[20];
	printf("so luong:\n");
	scanf("%d", &n);
	nhapham(a, n);
	for (int i = 0; i <n; i++)
	{
		for (int j = i + 1; j < n; j++)
			if (a[i]<a[j])
			
			swap(&a[i], &a[j]);
	}
	int chuan = a[0];
	int count = 0;
	for (int i = 0; i < n; i++)
	{
		if (a[i]==chuan)
		{
			count++;
		}
		if (chuan!=a[i])
		{
			printf("the %d appear %d times\n", a[i - 1], count);
			chuan = a[i];
			count = 1;
		}
		if (i==n-1)
		{
			printf("the %d appear %d times\n", a[i], count);

		}
	}
	return 0;
}
