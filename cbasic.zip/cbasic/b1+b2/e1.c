#include<stdio.h>
#include<math.h>
#define size 20
int main(){
  int a[size],tb,i;
  for(i=0;i<=size;i++)
    {
      printf("A[%d]=",i);
      scanf("%d",&a[i]);
      tb+=a[i];
    }
  int mindiff=100000,diff,medianindex;
  float T;
  T=tb/size;
  for(i=0;i<size;i++){
    diff=fabs(a[i]-T);
    if(diff<mindiff){
      mindiff=diff;
      medianindex=i;
    }
  }
  printf("tbinh=%lf\n",T);
  printf("median:a[%d]\n",medianindex);
  return 0;
}
    
  
