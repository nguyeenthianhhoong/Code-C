#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct sinhvien
{
	char Hoten[30];
}sv;
void Nhap(sv sv[],int n)
{
	for(int i=0;i<n;i++)
	{
	  fflush(stdin);
	  printf("\nNhap ten: ");
	  gets(sv[i].Hoten);
	}
}
void Sapxep(sv sv[20], int n)
{
   sv tam;
   for(int i=1; i<=n; i++)
      for(int j=i+1; j<=n; j++)
        if(strcmp(sv[i].Ten,sv[j].Ten)>0 || strcmp(sv[i].Ho,sv[j].Ho)>0)
         {
           tam = sv[i];
           sv[i] = sv[j];
           sv[j]=tam;
}
}
void Xuat(sv sv[],int n)
{
	for(int i=0;i<n;i++)
	{
		printf("\n%s",sv[i].Hoten);
	}
}
void main()
{
	sinhvien sv[100];
	int n=3;
	Nhap(sv,n);
	Sapxep(sv,n);
	Xuat(sv,n);
	getch();

}
