#include<stdio.h>
#include<stdlib.h>
void split(double num,int *int_part,double *frac_part)
{
  *int_part=(int)num;
  *frac_part=num-*int_part;
}

int main(void){
  double num,fraction;
  int integer;
  printf("please enter a real number:");
  scanf("%lf",&num);
  
  split(num,&integer,&fraction);
  printf("the integer part is %d\n",integer);
  printf("the remaining fraction is %f\n",fraction);
  return 0;
}
  
  
