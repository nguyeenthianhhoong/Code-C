#include<stdio.h>
enum{success,fail}
main(void)
{
  FILE *fptr;
  char filename[]="hai.txt";
  int reval=success;
  if((fptr=fopen(filename,"r"))==NULL){
    printf("cannot open %s.\n",filename);
    reval=fail;
  }else{
    printf("the value of fptr:0x%p\n",fptr);
    printf("ready to close the file");
    fclose(fptr);
  }
  return reval;
}
