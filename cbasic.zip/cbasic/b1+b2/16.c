#include<stdio.h>
#include<stdlib.h>
int main(int argc,char* argv[])
{
  float width,height;
  if(argc!=3)
    {
      printf("wrong num of arguments!\n");
      printf("correct syntax:rect<width><height>\n");
      return 1;
    }
  width=atof(argv[1]);
  height=atof(argv[2]);
  printf("s=%f\n",width*height);
  printf("c=%f\n",2*(width+height));
  return 0;
}
