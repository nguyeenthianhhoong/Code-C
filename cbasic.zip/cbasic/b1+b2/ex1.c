#include<stdio.h>
#define size 10

int main(){
  int a[size],b[size],n,i;
  for(i=0;i<size;i++){
    printf("a[%d]=",i);
    scanf("%5d",&a[i]);
    b[i] = 1;
  }
  for(i=0;i<size;i++){
    int count=1;
    if(b[i] != 0){
    	for (int j=i+1;j<size;j++){
	   if(a[j]==a[i]){
	   	count++;
	   	b[j]=0;
	   }
        }

        printf("%d xuat hien %d lan\n",a[i],count);
    }
}
  
  return 0;
}
      
  
  
