#include<stdio.h>
enum{success,fail};

int main(int argc,char *argv[])
{
  FILE *fptr1,*fptr2;

  if(argc!=3)
    {
      printf("wrong\n");
      printf("correct syntax: mycp<a1.txt><a2.txt>");
      return 1;
    }
  
  int reval=success;
  if((fptr1=fopen(argv[1],"w"))==NULL){
    printf("cannot open %s.\n",argv[1]);
    reval=fail;
  } else if ((fptr2=fopen(argv[2],"r"))==NULL){
     printf("cannot open %s.\n",argv[2]);
    reval=fail;
  } else {
    CharReadWrite(fptr2,fptr1);
    
    fclose(fptr1);
    fclose(fptr2);
  }return reval;
}
void CharReadWrite(FILE *fin,FILE *fout)
{
  int c;
  while((c=fgetc(fin))!=EOF){
    fputc(c,fout);
    putchar(c);
  }
}
