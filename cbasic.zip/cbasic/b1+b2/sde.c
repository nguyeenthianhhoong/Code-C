#include<stdio.h>
#include<math.h>
#include<stdlib.h>

int main(int argc,char* argv[])
{
  float a,b,c,i,x1,x2;
  if(argc!=4)
    {
      printf("wrong number\n");
      printf("correct syntax:sde<a><b><c>\n");
    }
  a=atof(argv[1]);
  b=atof(argv[2]);
  c=atof(argv[3]);
  if(a==0)
    { if(b==0)
	{ if(c==0)
	    printf("pt vo so nghiem\n");
	  else
	    printf("pt vo nghiem\n");
	}
      else
	printf("pt co nghiem duy nhat x=%f\n",-c/b);
    }
  else
    {  i=b*b-4*a*c;
      if(i<0)
	printf("pt vo nghiem\n");
      else if(i==0)
	printf("pt co nghiem kep x1=x2=%f\n",-b/(2*a));
      else
	{
	  x1=(-b+sqrt(i))/(2*a);
	  x2=(-b-sqrt(i))/(2*a);
	  printf("pt co 2 nghiem phan biet:x1=%f\tx2=%f\n",x1,x2);
	}
    }
  return 0;
}
