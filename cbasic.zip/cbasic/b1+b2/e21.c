#include<stdio.h>
#define size 10

int main(){
  int a[size],n,i;
  for(i=0;i<size;i++){
    printf("a[%d]=",i);
    scanf("%5d",&a[i]);
  }
  int x=a[0],count=0;
  for(i=0;i<size;i++){
    if(a[i]==x){
      count++;
    }
    if(a[i]!=x){
      printf("%d xuat hien %d lan\n",a[i-1],count);
      x=a[i];
      count=1;
    }
  return 0;
}
      
     
