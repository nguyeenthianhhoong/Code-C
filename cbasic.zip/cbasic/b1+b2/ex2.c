#include<stdio.h>
#include<string.h>
#define size 100
void tachten(char s[],char ten[]){
  int i,j,n;
  n=strlen(s);
  for(i=n-1;i>0;i--)
    if(s[i]==' ')
      break;
  for(j=i+1;j<n;j++){
    ten[j-i-1]=s[j];
    ten[n-i-1]='\0';
  }
}
void sapxep(char ten[],char s[]){
  int i,j;
  char t[10];
  for (i = 1; i < 5; i++) {
      for (j = 1; j < 5; j++) {
         if (strcmp(s[j - 1], s[j]) > 0) {
            strcpy(t, s[j - 1]);
            strcpy(s[j - 1], s[j]);
            strcpy(s[j], t);
         }
      }
   }
}
int main(){
  char s[5][size],ten[10],t[10];
  int i,j,n;
  printf("entername:\n");
  for(i=0;i<5;i++)
    scanf("%s",s[i]);
  tachten(s,ten);
  sapxep(ten,s);
 
  printf("\ndanh sach:");
   for (i = 0; i < 5; i++)
      printf("\n%s", s[i]);

   return 0;
}
 
  
