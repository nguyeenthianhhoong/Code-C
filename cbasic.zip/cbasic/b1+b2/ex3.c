#include<stdio.h>
#include<ctype.h>
enum{success,fail};

int main(void)
{
  FILE *fptr1,*fptr2;
  char filename1[]="lab1w.txt",filename2[]="lab1.txt";
  int reval=success;
  if((fptr1=fopen(filename1,"w"))==NULL){
    printf("cannot open %s.\n",filename1);
    reval=fail;
  } else if ((fptr2=fopen(filename2,"r"))==NULL){
     printf("cannot open %s.\n",filename2);
    reval=fail;
  } else {
    CharReadWrite(fptr2,fptr1);
    fclose(fptr1);
    fclose(fptr2);
  }return reval;
}
void CharReadWrite(FILE *fin,FILE *fout)
{
  int c;
  while((c=fgetc(fin))!=EOF){
    if(islower(c))
      c=toupper(c);
    fputc(c,fout);
    putchar(c);
  }
}
