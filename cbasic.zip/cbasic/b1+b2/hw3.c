#include<stdio.h>
enum{success,fail};

int main(void)
{
  FILE *fptr1,*fptr2;
  char filename1[]="lab1w.txt",filename2[]="lab1.txt";
  int reval=success;
  if((fptr1=fopen(filename1,"w"))==NULL){
    printf("cannot open %s.\n",filename1);
    reval=fail;
  } else if ((fptr2=fopen(filename2,"r"))==NULL){
     printf("cannot open %s.\n",filename2);
    reval=fail;
  } else {
    double_space(fptr2,fptr1);
    
    fclose(fptr1);
    fclose(fptr2);
  }return reval;
}
void double_space(FILE *ifp,FILE *ofp)
{
  int c;
  while((c=fgetc(ifp))!=EOF){
    fputc(c,ofp);
    if(c=='\n')
      fputc('\n',ofp);/*found a newline-duplicate it*/
  }
}
void prn_info(char *pgm_name)
{
  printf("\n%s%s%s\n\n%s%s\n\n","usage: ",pgm_name,"infile outfile","the contents of infile will be double-spaced","and written to outfile");
}
