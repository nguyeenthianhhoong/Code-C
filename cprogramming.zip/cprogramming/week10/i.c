#include <stdio.h>
 
int main() 
{
    // khai bao mang a co n phan tu
    int n = 5, i, s = 0;
    int a[n];
 
    // thuc hien nhap tung phan tu mang
    for (i = 0; i < n; i++) 
    {
        printf("Nhap a[%d] = ", i);
        scanf("%d", &a[i]);
    }
 
    // thuc hien in cac phan tu cua mang ra man hinh
    printf("\nMang da nhap \n");
    for (i = 0; i < n; i++) 
    {
        printf ("%d \t", a[i]);
    }
 
    // tinh tong cac so trong mang
    for (i = 0; i < n; i++) 
    {
        s += a[i]; // s = s + a[i]
    }
    printf("\nTong cac so trong mang: %d\n", s);
 
    return 0;
}
