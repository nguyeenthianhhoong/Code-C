#include<stdio.h>
#define SIZE 10

int main(){
    int a[SIZE];
    int sum_odd = 0;
    for (int i=0;i<SIZE;i++){
        printf("Nhap phan tu thu %d:",i+1);
        scanf("%d",&a[i]);
    }
    printf("Mang vua nhap");
    for(int i=0;i<SIZE;i++){
        printf("%d\t",&a[i]);
    }
    int min = a[0];
    for(int i=0;i<SIZE;i++){
        if(a[i]%2!=0){
            sum_odd+=a[i];
        }
        if(a[i]<min){
            min = a[i];
        }
    }
    printf("\nTong cac phan tu so le trong mang: %d",sum_odd);
    printf("\nPhan tu nho nhat trong mang: %d",min);
    return 0;
}
