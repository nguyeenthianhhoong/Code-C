#include<stdio.h>
int calc_sum(const int arr[], int size) {
  int i = 0;
  int sum = 0;
  for(i = 0; i < size; ++i)
    sum += arr[i];
  return sum;
}
