#include<stdio.h>
#define size 10
void ham_1(int s[], int size);
void ham_2(int s[] ,int size);
int main() {
    int s[100];
    int size, i;
    printf("nhap mang: ");
    for(i=0; i<size; i++) {
        printf(" s[%d] = ", i); scanf("%d", &s[i]);
    }
    printf("xap xep theo thu tu giam dan:");
    ham_1(s,size);
    printf("xap xep cac so le theo thu giam dan: ");
    ham_2(s,size);
    return 0;
}
void ham_1(int s[], int size) {
    int k;
    for(int i=0; i<size-1; i++){
        for(int j=1; j<size; j++){
            if(s[i]<s[j]) {
                s[i]=k; s[i]= s[j]; s[j]=k;
            }
        }
    }
    for(i=0; i<size; i++)
        printf(" %d", s[i]);
}
void ham_2(int s[], int size) {
    int k;
    for(int i=0; i<size-1; i++){
        for(int j=1; j<size; j++){
            if(s[i]<s[j] && s[i]%2==1 && s[j]%2==1) {
                s[i]=k; s[i]=s[j]; s[j]=k;
            }
        }
    }
    for(int i=0; i<size; i++)
        if(s[i]%2 != 0 ) printf(" %d", s[i]);
}
