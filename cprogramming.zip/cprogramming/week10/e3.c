#include<stdio.h>
int equality(int a[],int b[],int size)
{
    for (int i=0;i<size;i++){
        if a[i]!=b[i] return 0;
    }
    return 1;
}

int[] inputArray(int size){
    int a[size];
    printf("Nhap mang: ");
    for (int i=0;i<size;i++){
        scanf("%d",&a[i]);
    }
}

int main()
{
    int m[100],n[100],s;
    printf("Nhap so luong phan tu cua hai mang");
    scanf("%d",&s);
    printf("Nhap mang 1: ");
    m = inputArray(s);
    printf("Nhap mang 2: ");
    n = inputArray(s);
    
    if (equality(m,n,s)==1)
        printf("Hai mang bang nhau");
    else
        printf("Hai mang khong bang nhau");
    return 0;
}
    
}
