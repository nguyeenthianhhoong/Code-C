#include<stdio.h>
#define x 10
int main(){
  int a[x],n;

  for(n=0;n<10;n++)
    { printf(" a[%d]:",n);
      scanf("%d",&a[n]);
    }
  printf("mang:");
  for (n=0;n<10;n++)
    printf("\t %d \n",a[n]);

  int min=a[0],sum=0;
  for (n=0;n<10;n++){
    if (a[n]%2 !=0){
      sum+=a[n];
    }
    if (a[n]<min){
      min=a[n];
    }
  }
  printf(" %d  %d",sum,min);
  //printf("%d \n", sum);
  //printf("%d \n", min);
  return 0;
}
    
