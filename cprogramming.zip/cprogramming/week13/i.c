#include<stdio.h>
void replace(char str[], char s1, char s2){
    for(int i=0;i<strlen(str);i++){
        if(str[i]==s1){
            str[i]=s2;
        }
    }
}

void check(char *s){
    int check1=1, check2=1;
    for (int i=0;i<3;i++){
        if (isalpha(s[i]) == 0)
            check1 = 0;
    }
    for (int i=3;i<7;i++){
        if (isdigit(s[i]) == 0)
            check2 = 0;
    }

    if (check1==1 && check2==1)
        printf("pass\n");
    else
        printf("Error\n");
}
