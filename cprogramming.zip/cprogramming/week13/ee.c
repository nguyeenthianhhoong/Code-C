#include<stdio.h>
#include<string.h>
#include<ctype.h>
void nhapchuoi(char s[]){
    printf("nhap chuoi:");
    getchar();
    gets(s);
    //scanf("%[^\n]s", s);
}

int demsokhoangtrang(char s[]){
    int i, dem=0;
    for(i=0; i<strlen(s); i++){
        if(s[i] == ' '){
            dem = dem +1;
        }
    }
    
    return dem;
}
