#include<stdio.h>
#include<string.h>

int khoangtrang(char s[]){
  int i,sum=0;
  for(i=0;i<strlen(s);i++)
    if(s[i]==' ')
      sum+=1;
  return sum;
}
int main(){
  char s[100];
  printf("enter string:");
  gets(s);
  khoangtrang(s);
  printf("so khoang trang:%d",sum);
  return 0;
}
