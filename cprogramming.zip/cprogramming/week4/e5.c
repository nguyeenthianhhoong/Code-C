#include<stdio.h>
int main(){
  double title,price,VAT;
  char CLSP[10],NAME[10],ISBN[10];
  printf("name:");
  scanf("%9s",NAME);
  printf("CLSP:");
  scanf("%5s",CLSP);
  printf("ISBN: ");
  scanf("%s",ISBN);
  printf("price: ");
  scanf("%lf",&price);
  printf("thong tin sp:\n");
  printf("name   isbn   price   clsp\n");
  printf("%s%5s%10g%5s\n",NAME,ISBN,price,CLSP);
  VAT=0.04*price;
  title=price+VAT;
  printf("tong la %lf\n",title);
  return 0;
}
  
  
