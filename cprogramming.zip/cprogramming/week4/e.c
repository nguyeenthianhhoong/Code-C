#include <stdio.h>
int main(){
char x, y[ 9 ];
printf( "Enter a string: " );
scanf( "%s%c", x, &y );
printf( "The input was:\n" );
printf( "the character \"%c\" ", y );
printf( "and the string \"%s\"\n", x );
return 0;
}
