#include<stdio.h>
#include<limits.h>
int main(){
  printf("max int:%ld\n",INT_MAX);
  printf("max long:%ld\nmin long:%ld\n",LONG_MAX,LONG_MIN);
  return 0;
}
