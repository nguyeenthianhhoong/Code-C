#include<stdio.h>
#include<string.h>
#include<ctype.h>
void nhapchuoi(char s[]){
    printf("nhap chuoi:");
    getchar();
    gets(s);
    //scanf("%[^\n]s", s);
}

int demsokhoangtrang(char s[]){
    int i, dem=0;
    for(i=0; i<strlen(s); i++){
        if(s[i] == ' '){
            dem = dem +1;
        }
    }
    
    return dem;
}

void replace(char str[], char s1, char s2){
    for(int i=0;i<strlen(str);i++){
        if(str[i]==s1){
            str[i]=s2;
        }
    }
}

void check(char *s){
    int check1=1, check2=1;
    for (int i=0;i<3;i++){
        if (isalpha(s[i]) == 0)
            check1 = 0;
    }
    for (int i=3;i<7;i++){
        if (isdigit(s[i]) == 0)
            check2 = 0;
    }

    if (check1==1 && check2==1)
        printf("pass\n");
    else
        printf("Error\n");
}

int strend(char s[], char t[]){
    if(strlen(s)< strlen(t))
        return 0;
    else{
        for(int i = 0; i< strlen(t); i++){
            if(s[strlen(s)-1-i] != t[strlen(t)-1-i])
                return 0;
        }
        return 1;
    }
}

int main(){
    char line[100];
    int choice, count;
    char text[100], keyword[100];
    
    do{
        printf("MENU\n");
        printf("1. Input a string\n");
        printf("2. Count number of blanks\n");
        printf("3. Replace in a string\n");
        printf("4. Check if appearing at the end\n");
        printf("5. Quit\n");
        
        do{
            printf("Input a choice: ");
            scanf("%d", &choice);
        } while (choice < 1 || choice > 5);
        
        switch(choice){
            case 1:
                nhapchuoi(line);
                printf("Input: %s\n", line);
                break;
            case 2:
                count = demsokhoangtrang(line);
                printf("Number of blanks: %d\n", count);
                break;
            case 3:
                replace(line, 'p', 'm');
                printf("Replace: %s\n", line);
                break;
            case 4:
                nhapchuoi(text);
                nhapchuoi(keyword);
                printf("Keyword appears at the end: %s\n", strend(text, keyword)==1? "Yes":"No");
                break;
            case 5:
                printf("Bye bye\n");
                break;
        }
    } while (choice != 5);
}
