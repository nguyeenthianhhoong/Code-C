#include<stdio.h>
int main(){
  printf("Liu Haoran\n");
  return 0;
}
