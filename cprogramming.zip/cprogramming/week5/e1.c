#include<stdio.h>
int main(){
  double km,m;
  printf("enter km:");
  scanf("%lf",&km);
  m=km/1000;
  printf("meters:%g\n",m);
  return 0;
}
