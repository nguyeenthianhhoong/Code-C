#include<stdio.h>
int main(){
  float a;
  char x;
  // A:car, B: bus, C: truck
  printf("xe ra bai:");
  scanf("%c",&x);
  printf("enter a:");
  scanf("%f",&a);
  if(x=='A')
    {if(a<=2)
	printf("sum =%f",a*0.7);
      else
	printf("sum =%f",a*2.5);
    }
   else if(x=='B')
    {if(a<=2)
	printf("sum=%f",a*1.5);
      else
	printf("sum=%f",a*2);
    }
    else if(x=='C')
    {if(a<=2)
	printf("sum=%f",a*2.5);
      else
	printf("sum=%f",a*3.25);
    }
    else {
	printf("No type of car!");
    }
    return 0;
}
