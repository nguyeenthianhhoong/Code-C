#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int main(){
    int n, a;
    srand(time(NULL));
    n=rand()%10;
    
    while(1){
        printf("enter a number: ");
        scanf("%d",&a);
        if(a==n){
            printf("dung roi!\n");
            break;
        }
        if (a<n)
            printf("Nho hon so can doan\n");
        if (a>n)
            printf("Lon hon so can doan\n");
    }
    
    return 0;
}
