#include<stdio.h>
#include<time.h>
#include<stdlib.h>
int main(){
  int a,n;
  srand(time(NULL));
    n=rand()%10;
  printf("enter num:");
  scanf("%d",&a);
  if (a<n)
    printf("too low");
  if(a==n)
    printf("correct");
  if(a>n)
    printf("too high");
  return 0;
}
    
