#include<stdio.h>
int main(){
  double a;
  printf("enter num:");
  scanf("%lf",&a);
  if (0<=a<90)
    printf("north %lf east",a);
    
  else if(90<=a<180)
       printf("south %lf east",180-a);
       
  else if (180<=a<270)
      printf("south %lf west",a-180);
       
  else if (270<=a<=360)
       printf("north %lf west",360-a);
       
  return 0;
}
