#include<stdio.h>
int main(){
    int age;
    printf("nhap tuoi: ");
    scanf("%d",&age);
    if (age <18)
        printf("child");
    if (age >=18 && age <65)
        printf("adult");
    if (age >65)
        printf("nguoi cao tuoi");
    return 0;
}
