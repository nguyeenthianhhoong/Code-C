#include<stdio.h>
int matran(int n,int a[100][100])
{
  
  for(int i=0;i<n;i++)
    {
      for(int j=0;j<n;j++)
	{
	  printf("nhap a[%d][%d]=",i,j);
	  scanf("%d",&a[i][j]);
	  printf("%4d",a[i][j]);
	}
      printf("\n");
    }
}
int donvi(int n,int a[100][100])
{
  for(int i=0;i<n;i++)
    {
      if (a[i][i]!=1)
	  return 0;
      for(int j=0;j<n;j++)
	{
	  if( a[i][j]!=0|| a[j][i]!=0)
	    return 0;
		    
	}
    }
      return 1;
}


  

      
int main(){
  int choice;
 
  do{
    printf("MENU\n");
    printf("1.Ma tran\n");
    printf("2.Tam giac\n");
    printf("3.Chuyen so\n");
    printf("4.Phan so\n");
    printf("5.Exit\n");
    do{
      printf("Input a choice:");
      scanf("%d",&choice);
    }while(choice<1||choice>5);
    switch(choice){
    case 1:
      int n, a[100][100];
     
       do{
      printf("enter n:");
      scanf("%d",&n);
      printf("n k hop le");
    }while(n<0);
       matran(n,a);
       if (donvi(n,a)==0)
	 printf("khong");
       if(donvi(n,a)==1)
	 printf("co"); 
      break;
    case 2:
      int n;
      char a;
      printf("choice N or X:");
      scanf("%c",&a);
      if(a=='X'){
	for (int i=1;i<n;i++)
	  { for (int j=1;j<=i;j++)
	      { printf("*");
	      }
	    printf("\n");
	  }
      }
       if(a=='N'){
	  for(int m=1;m<n;m++)
	    {for (int k=1;n>1;n--)
		{printf("*");
		}
	      printf("\n");
	    }
	}
      
      break;
    case 3:
      break;
    case 4:
      break;
    case 5:
      break;
    }
  }while(choice !=5);
}
