#include<conio.h>
#include<stdio.h>
int main()
{
	int nhapmang(int n, int A[100][100])
{
	int i, j;
	for(i=0; i<n; i++)
	{
	    for(j=0; j<n; j++)
	    {
            printf("nhap A[%d][%d] = ", i, j);
            scanf("%d", &A[i][j]);
	    }
	}
}
int xuatmang(int n, int A[100][100])
{
    int i, j;
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
        {
            printf("%3d", A[i][j]);
        }
        printf("\n");
    }
}
/*kiem tra ma tran vua nhap co phai la ma tran don vi khong*/
int donvi(int n, int A[100][100])
{
    int i, j;
    for(i=0; i<n; i++)
    {
        if(A[i][i] !=1)
        {
            return 0;
        }
    }
    for(i=0; i<n; i++)
    {
        for(j=i+1; j<n; j++)
        {
            if((A[i][j] !=0) || (A[j][i] !=0))
            {
                        return 0;
            }
        }
    }
    return 1;
}
int main()
{
    int n, A[100][100] ;
    printf("nhap mang kich thuoc n la \n n = ");
    scanf("%d", &n);
    nhapmang(n, A);
    printf("Ma tran vua nhap la:\n");
    xuatmang(n, A);
   
    if(donvi(n, A)==0)
    {
        printf("mang vua nhap khong phai la ma tran don vi\n");
        printf("Nen theo de bai ta in ra : Khong");
    }
    if(donvi(n, A) ==1)
    {
        printf("Mang vua nhap la ma tran don vi");
        printf("Nen theo de bai ta in ra : Co");
    }
    getch();
    return 0;
}
