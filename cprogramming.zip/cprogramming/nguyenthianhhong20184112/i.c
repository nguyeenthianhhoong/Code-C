#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct hon_so hon_so;
struct hon_so
{
  int phan_nguyen;
  int tu_so;
  int mau_so;
};
void rutGon(int *tu_so, int *mau_so)
{
  for(int i = 2; i <= *tu_so; i++)
    {
      if(*tu_so % i == 0 && *mau_so % i == 0)
        {
          *tu_so = *tu_so / i;
          *mau_so = *mau_so / i;
          i --;
        }
    }
}
void phanSo()
{
  hon_so a, b;
  printf("Nhap vao hon so thu 1 : ");
  scanf("%d%*c%d%*c%d", &(a.phan_nguyen), &(a.tu_so), &(a.mau_so));
  printf("Nhap vao hon so thu 2 : ");
  scanf("%d%*c%d%*c%d", &(b.phan_nguyen), &(b.tu_so), &(b.mau_so));
  if(a.tu_so == 0 || a.mau_so == 0
     ||b.tu_so == 0 || b.mau_so == 0)
    {
      printf("INVALID\n");
    }
  else
    {
      int tuSo_phanSo1 = (a.phan_nguyen * a.mau_so + a.tu_so);
      int tuSo_phanSo2 = (b.phan_nguyen * b.mau_so + b.tu_so);
      int tu_so = tuSo_phanSo1 * b.mau_so;
      int mau_so = tuSo_phanSo2 * a.mau_so;
      int phan_nguyen = tu_so / mau_so;
      tu_so = tu_so - (phan_nguyen) * mau_so;
      rutGon(&tu_so, &mau_so);
      if(phan_nguyen != 0)
        printf("%d %d/%d\n", phan_nguyen, tu_so, mau_so);
      else
        printf("%d/%d\n", tu_so, mau_so);
    }
}
void maTran()
{
  int cap = 0;
  printf("Nhap cap ma tran vuong : ");
  scanf("%d", &cap);
  int A[cap][cap];
  printf("Nhap ma tran : \n");
  for(int i = 0; i < cap; i++)
    {
      for(int j = 0; j < cap; j++)
        {
          printf(" Vi tri hang %d cot %d : ", i + 1, j + 1);
          scanf("%d", &A[i][j]);
        }
    }
  for(int i = 0; i < cap; i++)
    {
      for(int j = 0; j < cap; j++)
        {
          if(i == j && A[i][j] != 1)
            {
              printf("Khong\n");
              break;
            }
          else if(i != j && A[i][j] != 0)
            {
              printf("Khong\n");
              break;
            }
          else if( i == j && j == cap - 1
                   && A[i][j] == 1)
            {
              printf("Co\n");
            }
        }
    }
}
void tamGiac()
{
  char choice;
  int hang = 0;
  printf("Nhap kich thuoc va chieu : ");
  scanf("%d%*c%*c%c", &hang, &choice);
  if(choice == 'X')
    {
      for(int i = 0; i < hang; i++)
        {
          for(int j = 0; j < 2 * hang - i; j++)
            {
              if(j < hang - i)
                printf(" ");
              else
                printf("*");
            }
          printf("\n");
        }
    }
  else if(choice == 'N')
    {
      for(int i = 0; i < hang; i++)
        {
          for(int j = 0; j < 2 * (hang) - i - 1; j++)
            {
              if(j < i)
                printf(" ");
              else
                printf("*");
            }
          printf("\n");
        }
    }
}
int pow1(int so, int mu)
{
  int pow = 1;
  for(int i = 0; i < mu; i++)
    {
      pow = pow * so;
    }
  return pow;
}
  long long sdt;
void chuyendoi(){
	printf("\nNhap so dien thoai: ");
	scanf("%d",&sdt);
	if(sdt>=100000000&&sdt<=999999999) printf("\n%d",sdt);
	if(sdt>=1620000000&&sdt<=1699999999){
		sdt=sdt-1000000000-300000000;
		printf("\n%d",sdt);
	}
	else if((sdt>=1000000000&&sdt<1620000000)||(sdt>1699999999&&sdt<=9999999999)) printf("\nKhac nha mang");
}
int main()
{
  Menu:
  printf("\n Menu :\n");
  printf("1. Ma Tran.\n");
  printf("2. Tam giac.\n");
  printf("3. Chuyen doi so.\n");
  printf("4. Phan so\n");
  printf("5. Thoat.\n");
  int option = 0;
  do
  {
    printf("\n  Nhap so tuong ung de tien hanh lua chon : ");
    scanf("%d", &option);
  }while(option < 1 || option > 5);

 switch(option)
   {
   case 1:
     {
       maTran();
       break;
     }
   case 2:
     {
       tamGiac();
       break;
     }
   case 3:
     {
       chuyendoi();
       break;
     }
   case 4:
     {
       phanSo();
       break;
     }
   case 5:
     {
       printf("\n\nThis program made by Luong Duc Duong\n\n");
       return 0;
     }
   }
  goto Menu;
}
