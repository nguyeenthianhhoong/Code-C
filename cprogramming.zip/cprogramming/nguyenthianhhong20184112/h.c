#include<stdio.h>
#include<stdlib.h>

int main()
{
	int a[50][50];
	int i,j,m,n;
	int x,y;
	printf("nhap so hang n="); scanf("%d",&n);
	
	printf("nhap vao ma tran tu trai qua phai, tu tren xuong duoi:\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
    
	for(i=0;i<n;i++)
    {
    	for(j=0;j<n;j++)
    	{
    		if (i == j) 
            {
                if (a[i][j] == 1) 
                {
                   x = 1;
                }
                else
                {
                    x = 0;
                    break;
                }
            }
            else 
            {
                if (a[i][j] == 0) 
                {
                    y = 1;
                }
                else
                {
                    y = 0;
                    break;
                }
            }
        }
    }
    if (x*y==1) 
    printf("La ma tran don vi\n");
    else if(x*y==0) 
    printf("Khong la ma tran don vi\n");
	
	return 0;
	}
