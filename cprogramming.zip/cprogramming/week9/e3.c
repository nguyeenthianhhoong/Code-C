#include<stdio.h>
int isleapyear(int a)
{ if(a%4==0)
    return 1;
  return 0;
}
int main(){
  int a;
  printf("year:");
  scanf("%d",&a);
  if (isleapyear(a)==0)
    printf("%d la nam nhuan",a);
  else
    printf("%d k la nam nhuan",a);
  return 0;
}
