#include <stdio.h>
 
int max2(int a, int b) 
{
    return a > b ? a : b;
}
 
int max3(int a, int b, int c) 
{
    return max2( max2(a, b), c);
}
 
int main()
{
    int a = 7, b = 13, c = 4;
    printf("So lon nhat la %d \n", max3(a, b, c));
    return 0;
}
