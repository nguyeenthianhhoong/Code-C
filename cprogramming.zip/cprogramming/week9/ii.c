#include<stdio.h>
int is_Prime(int a){
    if(a<=1){
        return 0;
    }
    for (int i = 2; i < a;i++)
        if(a%i==0)
            return 0;
    return 1;
}

int main(){
    int a;
    printf("Nhap 1 so:");
    scanf("%d",&a);
    if(is_Prime(a)==1)
           printf("%d la so nguyen to",a);
    else
           printf("%d khong la so nguyen to",a);
    
    printf("Cac so nguyen to tu 2 den %d la: ",a);
    for(int i=2;i<=a;i++){
        if(is_Prime(i)==1)
            printf("%2d",i);
    }
           
    return 0;
}
