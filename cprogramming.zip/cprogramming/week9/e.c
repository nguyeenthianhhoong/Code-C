#include<stdio.h>

float ke(float m, float v)
{ return (m*v*v)/2;
    }
int main(){
  float m,v;
  printf("enter m,v:");
  scanf("%f%f",&m,&v);
  printf("dongnang la:%3f",ke(m,v));
  return 0;
}
