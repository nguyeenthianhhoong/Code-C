#include<stdio.h>
int is_prime(int n)
{
  
  for (int i=1;i<n;i++){
    if (n%i==0)
      return 0;
  } return 1;
}
int main(){
  int x;
   printf("x=");
  scanf("%d",&x);
  if (is_prime(x)==0)
    printf("%d k la snt\n",x);
  else
    printf("%d la snt\n",x);
  printf("cac snt tu 2 den %d:",x);
  for(int a=2;a<=x;a++){
    if(is_prime(a)==1)
      printf("%2d\n",a);
  }
  return 0;
}

      
  
