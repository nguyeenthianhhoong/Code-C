#include <stdio.h>
 
int kiemTraChiaHet(int n)
{
    if(n % 2 == 0 && n % 5 == 0)
    {
        return 1;
    }
    return 0;
}
 
int main()
{
    int x;
 
    printf("Nhap x = ");
    scanf("%d", &x);
 
    if( kiemTraChiaHet(x) == 0)
    {
        printf("day khong phai so dep @@\n");
    } else {
        printf("day la so dep !!!\n");
    }
 
    return 0;
}
