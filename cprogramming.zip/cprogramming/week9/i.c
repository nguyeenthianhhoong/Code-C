 
#include <stdio.h>
 
void loiKhuyen()
{
    printf("Neu hoc nghiem tuc va cham chi thi ban se thay:\n");
    printf("Khong co viec gi kho\n");
    printf("Chi so long khong ben\n");
    printf("Dao nui va lap bien\n");
    printf("Quyet chi at lam nen\n");
    printf("\n");
}
 
int main()
{
    printf("Hoc bai nay kho qua!\n");
    loiKhuyen();
 
    printf("Hoc C kho qua!\n");
    loiKhuyen();
 
    return 0;
}
