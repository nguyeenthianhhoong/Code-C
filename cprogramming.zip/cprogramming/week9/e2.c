#include<stdio.h>
float saraly(float a){
  if (a<10 || a>65)
    return 0;
  else if(a>=10 && a<=40)
    return a*15;
  else if(a>40)
    return 40*15+(a-40)*1.5*15;
}
int main(){
  float a;
  printf("enter a=");
  scanf("%f",&a);
  printf("saraly:%f",saraly(a));
  return 0;
}
