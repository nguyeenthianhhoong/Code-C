#include <stdio.h>
 
int main()
{
    int ngay = 12;
    int thang = 8;
    int nam = 1992;
 
    printf("KQ: %02d/%02d/%04d\n", ngay, thang, nam);
 
    return 0;
}
