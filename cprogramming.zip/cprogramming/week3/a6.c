#include<stdio.h>
int main(){
  printf("the size of basic data:\nint:%lu\nlong:%lu\ndouble:%lu\nchar:%lu\n",sizeof(int),sizeof(long),sizeof(double),sizeof(char));
  return 0;
}
