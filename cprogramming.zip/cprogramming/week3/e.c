#include<stdio.h>
int main(){
  char word[20];
  printf("what is your name:\n");
  scanf("%19s",word);
  printf("welcome %s",word);
  return 0;
}
