#include<stdio.h>

void main(){
  int year;
  float height;
  year=19;
  height=1.63;
  printf("I'm is %d years old and %f m height\n",year,height);
}
