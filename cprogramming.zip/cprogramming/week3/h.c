#include<stdio.h>
int main(){
  int a,b,c;
  printf("enter first num=");
  scanf("%d",&a);
  printf("enter second num=");
  scanf("%d",&b);
  c=a+b;
  printf("sum %d+%d=%d",a,b,c);
  return 0;
}
  
