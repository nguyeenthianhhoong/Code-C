#include<stdio.h>
int main(){
  int *ptr;
  int x=12345,y;
  ptr=&x;
  printf("the value of ptr is %p\n",ptr);
  printf("the address of x is %p\n\n",&x);
  printf("total characters printed is:%n",&y);
  printf("%d\n",y);
  y = printf("this line has 28 characters\n");
  printf("%d characters were printed \n",y);
  printf("printing a %% in format control string\n");
  return 0;
}
