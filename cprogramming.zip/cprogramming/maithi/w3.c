#include <stdio.h>
#include <math.h>
#include <stdlib.h>
int main()
{
	double rate = 0.05; //VD 5%/nam

	double n = log(2) / log(1 + rate/12);
	int m = ceil(n);

	printf("Gui lai sua %.2f/nam sau %d thang se lai gap 2\n"
		, rate, m);

	rate = 0.12; // lai suat vay thong dung
	m = ceil(log(2) / log(1 + rate / 12));
	printf("Gui lai sua %.2f/nam sau %d thang se lai gap 2\n"
		, rate, m);

	rate = 0.3*12; // lai suat vay nong
	m = ceil(log(2) / log(1 + rate / 12));
	printf("Gui lai sua %.2f/nam sau %d thang se lai gap 2\n"
		, rate, m);

	system("pause");

	return 0;
}
