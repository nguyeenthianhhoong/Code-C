#include<stdio.h>
#include<string.h>
#include<ctype.h>
//change entered string to a standard string 

int oddChar(char a)       //check odd char: !,?,>,<....
{
  if(a>=65&&a<=90)
    return 0;
  else if(a>=97&&a<=122)
    return 0;
  else if(a==32)
    return 0;
  return 1;
}

void delChar(char *a,int n)       //delete a char from the string
{
	int i;
	int len = strlen(a);
	for(i=n;i<len;i++)
	{
		a[i]=a[i+1];
	}
	
	a[len-1]='\0';

}

void toUpper(char *s){
  if(islower(*s))
    *s -=32;
}
void toLower(char *s){
  if(isupper(*s))
    *s += 32;
}



void  standardString(char *str){
  int i;
  for( i=0;i<strlen(str);i++){
    if(oddChar(str[i])){// xoa ki tu thua 
      delChar(str,i);
      i--;
    }
  }
  for(int i=0;i<strlen(str);i++){
    if(str[i]==' '&&(str[i+1]==' '||i == strlen(str)-1)){// xoa dau cach
      delChar(str,i);
      i--;
    }
    if(str[i]==' '&&i==0){
      delChar(str,i);
      i--;
    }
  }
  for(i=0;i<strlen(str);i++){
    if (str[i] != ' ')
    toLower(&str[i]);
  }
  toUpper(&str[0]);
  for(int i =1;i<strlen(str);i++){
    if(str[i-1]==' ')
      toUpper(&str[i]);
  }
  
}


int main()
{
	char str[100];
	printf("Enter string: ");
	gets(str);
	//	printf("%s\n",str);

	standardString(str);
	
	puts(str);
	printf("\n");
}
