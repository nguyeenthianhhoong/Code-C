#include <stdio.h>
#include<string.h>
void chuyenDoiCoSo(char s[], int n) {

	int coSo = 0, soDu = 0;
	printf( "Nhap vao he co so can chuyen:\n ") ;
	scanf("%d",&coSo);

	int i=0;
	while (n > 0) {
		soDu = n % coSo;
		if (soDu < 10) {
			s[i] = '0' + soDu;        
		}
		else {
			s[i] = 'A' + (soDu - 10);    
		}
		i++;
		n = n / coSo;
	}
        s[i] = '\0';
	for (int i = strlen(s) - 1; i >= 0; i--) {
	  printf("%c",s[i]);
	}
}

int main() {
	
	int n = 0;
	char s[100];
	printf( "Nhap vao mot so tu nhien: \n");
	scanf("%d",&n);
	
	chuyenDoiCoSo(s, n);

	return 0;
}
