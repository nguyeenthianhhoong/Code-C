#include<stdio.h>
int hoandoi(int *a,int *b,int *c){
  int doi;
  doi=*a;
  *a=*b;
  *b=*c;
  *c=doi;
  return 0;
}
int main(){
  int a,b,c;
  printf("enter:");
  scanf("%d%d%d",&a,&b,&c);
  hoandoi(&a,&b,&c);
  printf("after a=%d\tb=%d\tc=%d\n",a,b,c);
  return 0;
    }
