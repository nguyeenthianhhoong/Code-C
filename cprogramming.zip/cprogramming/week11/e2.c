#include<stdio.h>
int main(){
  float a,b,c,*x,*y,*z;
  x=&a;
  y=&b;
  z=&c;
  printf("enter a,b,c:");
  scanf("%f%f%f",&a,&b,&c);
  printf("add 100:\n x:%f\ty:%f\tz:%f",*x+100,*y+100,*z+100);
  return 0;
}
