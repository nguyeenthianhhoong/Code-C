#include <stdio.h>
 
void hoanVi(int *a, int *b) 
{
     int temp = *a;
     *a = *b;
     *b = temp;
}
 
int main() 
{
    int a = 42, b = 7826;
    printf("Truoc khi goi ham hoan vi: a = %d, b = %d \n", a, b);
 
    hoanVi(&a, &b);
 
    printf("Sau khi goi ham hoan vi: a = %d, b = %d \n", a, b);
 
    return 0;
}
