#include<stdio.h>
int main(){
  int a[7]={1,2,4,3,5,3,6};
  for (int i=0;i<5;i++)
    
    printf("address of a[%d]:%p\n",i,&a[i]);
  return 0;
}
