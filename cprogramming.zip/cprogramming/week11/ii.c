#include <stdio.h>
#include <string.h> // for strlen function
 
int main() 
{
    char s[50];
    printf("Enter a string: ");
    gets(s);
 
    int i, count = 0; // count - bien dem so luong dau cach
    for (i = 0; i < strlen(s); i++ )
    {
        if(s[i] == ' ') 
        {
            count++;
        }
    }
 
    printf("Number word in string is: %d\n", count + 1 );
 
    return 0;
}
