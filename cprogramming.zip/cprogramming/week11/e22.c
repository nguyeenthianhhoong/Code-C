#include <stdio.h>
int main(){
    int x,y,z;
    int *ptr;
    printf("nhap so: \n");
           scanf("%d %d %d\n",&x,&y,&z);
           printf("\nGia tri tra ve:\n");
           ptr=&x;
           printf("x=%d\n",*ptr+100);
           ptr=&y;
           printf("y=%d\n",*ptr+100);
           ptr=&z;
           printf("z=%d\n",*ptr+100);
           return 0;
}

