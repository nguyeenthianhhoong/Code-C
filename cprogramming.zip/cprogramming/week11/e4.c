#include <stdio.h>
void in(int x, int y, int z, int *p, int *q, int *r)
{
    printf(" x = %d \t y = %d \t z = %d\n", x,y,z);
    printf(" p = %p \t q = %p \t r = %p\n", p,q,r);
    printf(" *p = %d \t *q = %d \t *r = %d\n\n", *p,*q,*r);
}
void swap(int *a, int *b, int *c)
{
    int swap = *a;
    *a = *b;
    *b = *c;
    *c = swap;
}

int main()
{
    int x,y,z, *p,*q,*r;
    printf("x y z = ");
    scanf("%d%d%d",&x,&y,&z);
    
    p = &x; q= &y; r = &z;
    in(x,y,z,p,q,r);
    
    swap(&x,&y,&z);
    in(x,y,z,p,q,r);
    
    swap(&p,&q,&r);
    in(x,y,z,p,q,r);
    return 0;
}
