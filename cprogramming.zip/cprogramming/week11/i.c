#include <stdio.h>
 
int main() 
{
    // khai bao chuoi co toi da 50 ky tu
    char name[50]; 
    printf("Hi, What is your name? \nMy name is: ");
    gets(name);
    printf("Hi %s, welcome to C language\n", name);
 
    // khoi tao chuoi ngay khi khai bao
    char myLove[] = "Nguyen Thi Lap Lanh";
    puts(myLove);
 
    return 0;
}
