#include<stdio.h>
int main(){
  int a,b,c;
  printf("enter:");
  scanf("%d%d%d",&a,&b,&c);
  printf("address of\n a:%p \t b:%p \t c:%p",&a,&b,&c);
  return 0;
}
	
