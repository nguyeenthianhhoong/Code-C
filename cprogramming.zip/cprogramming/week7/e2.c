#include<stdio.h>

int main()
{
    int n,i,j,f;
    printf("nhap n = ");
    scanf("%d",&n);
    printf("cac so hoan hao la: ");
    for (i=2; i<=n; i++)
    {
        f=0;
        for (j=1; j<i; j++)
        {
            if (i%j == 0)
            {
                f=f+j;
            }
        }
        if(i==f)
        {
            printf("%d ",i);
        }
    }
    printf("\n");
    return 0;
}
