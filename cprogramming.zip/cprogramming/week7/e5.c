#include<stdio.h>
int giai_thua(int n){
  int f = 1;
 c1: for (f = 1; n > 1; n--){
    f = f * n;
  }
 c2: for (int cnt = 1; cnt <= n; cnt++){
    f = f * cnt;
  }
  return f;
}

int nCr(int n, int r){
  return giai_thua(n) / (giai_thua(n-r) * giai_thua(r));
}

int main(){
  int n;
  printf("enter n=");
  scanf("%d",&n);
  for(int i=0;i<=n;i++){
    for (int j = 0; j <= n - i; j++){
      printf(" ");
    }
    for (int j = 0; j <= i; j++){
      printf(" %d", nCr(i, j));
    }
    printf("\n");
  }
  return 0;
}
