#include <stdio.h>
 
int main()
{
    int i;
    int s = 0;
    for (i = 1; i <= 20; i = i + 2)
    {
        if(s <= 15)
        {
            s = s + i;
        }
    }
 
    printf("S = %d\n", s);
 
    return 0;
}
