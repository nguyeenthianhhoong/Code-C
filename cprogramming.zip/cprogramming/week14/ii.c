#include<stdio.h>
#include<stdlib.h>
typedef struct date_str{
    int ngay;
    int thang;
    int nam;
} Date;

void nhapngaythangnam(Date *p){
    do{
       printf("nhap ngay:");
       scanf("%d",&p->ngay);
    }while (p->ngay<1||p->ngay>31);
    
    do{
        printf("nhap thang:");
        scanf("%d",&p->thang);
    }while (p->thang<1||p->thang>12);
    
    do{
        printf("nhap nam:");
        scanf("%d",&p->nam);
    }while (p->nam<1);
}

void inngaythangnam(Date a, Date b){
    printf("ngay:%d\tthang:%d\tnam:%d\t\n", a.ngay,a.thang,a.nam);
    printf("ngay:%d\tthang:%d\tnam:%d\t",b.ngay,b.thang,b.nam);
}

void datecmp (Date a, Date b){
    int check=0;
    
    if((a.nam) < (b.nam))
        check = -1;
    else if((a.nam) > (b.nam))
        check = 1;
    else{
        if((a.thang) < (b.thang))
            check = -1;
        else if((a.thang) > (b.thang))
            check = 1;
        else{
            if((a.ngay) < (b.ngay))
                check = -1;
            else if((a.ngay) > (b.ngay))
                check = 1;
            else
                check=0;
        }
    }
    
    if(check==-1)
        printf("\ntruoc\n");
    else if(check==1)
        printf("\nsau\n");
    else
        printf("\nbang\n");
}

int main(){
    Date a;
    Date b;
    nhapngaythangnam(&a);
    nhapngaythangnam(&b);
    printf("\n");
    inngaythangnam(a, b);
    datecmp(a,b);
    return 0;
}
