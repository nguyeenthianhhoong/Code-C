#include <stdio.h>
#define SIZE 12
typedef struct wt
{
    float totalRainfall;
    float highRainfall;
    float lowRainfall;
    float averageTemperature;
} weather;

void main(){
    int i;
    char months[SIZE][10] = {"January","February", "March", "Aprill", "June", "July", "August", "September", "October", "November", "December"};
    float rain =0, temp=0;
    weather month[SIZE];
    float max_temp;
    float min_temp;
    
    for (i=0; i<SIZE; i++)
    {
        printf("%s: \n", months[i]);
        printf("\tTotal rainfall: ");
        scanf("%f", &month[i].totalRainfall);
        printf("\tHigh rainfall: ");
        scanf("%f", &month[i].highRainfall);
        printf("\tLow rainfall: ");
        scanf("%f", &month[i].lowRainfall);
        printf("\tAverage Temperature: ", &month[i].averageTemperature);
    }
    printf("\n");
    max_temp = month[0].averageTemperature;
    min_temp = month[0].averageTemperature;
    printf("Month\tTotal rainfall\tHigh rainfall\tLow rainfall\tAverage temperature\n");
    
    for (i=0;i<SIZE;i++)
    {
        if (max_temp<month[i].averageTemperature) max_temp=month[i].averageTemperature;
        if (min_temp>month[i].averageTemperature) min_temp=month[i].averageTemperature;
        rain += month[i].totalRainfall;
        temp += month[i].averageTemperature;
        printf("%s\t%g\t\t%g\t\t%g\t\t%g\n",months[i], month[i].totalRainfall, month[i].highRainfall, month[i].lowRainfall, month[i].averageTemperature);
    }
    
    printf("The average rainfall: %g\n", rain/SIZE);
    printf("The total rainfall of the year: %g\n", rain);
    printf("The average temperature: %g\n", temp/SIZE);
    printf("The highest temperature: %g\n", max_temp);
    printf("the lowest temperature: %g\n", min_temp);
}

