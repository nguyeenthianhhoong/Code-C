#include<stdio.h>
#include<stdlib.h>
typedef struct st{
    char id[6];
    char name[31];
    float grade;
    char classement;
} student;

int main(){
    student a[100],temp;
    int n,i,j;
    do{
        printf("nhap so sinh vien:");
        scanf("%d",&n);
        if(n>100||n<0)
            printf("so sinh vien khong hop le\n");
    }while(n>100 || n<0);
    
    for(i=0;i<n;i++){
        printf("nhap vao thong tin sinh vien thu %d\n",i+1);
        printf("\tId:");
        
        scanf("%c",&a[i].id);
        printf("\tTen:");
       
        scanf("%c",&a[i].name);
        printf("\tdiem:");
       
        scanf("%fl",&a[i].grade);
        if(a[i].grade>=9 && a[i].grade<=10)
	  a[i].classement='A';
        if(a[i].grade>=8 &&a[i].grade<9)
	  a[i].classement='B';
        if(a[i].grade>=6.5 &&a[i].grade<8)
	  a[i].classement='C';
        if(a[i].grade<6.5)
             a[i].classement='D';
    }
    
    for(i=0;i<n-1;i++){
        for(j=i+1;j<n;j++){
            if(a[i].grade<a[j].grade){
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
            }
        }
    }
    
    printf("\n\n");
    printf("%s\t %s\t %s\n","ten","diem","phan loai");
    for(i=0;i<n;i++){
        printf("%s\t%.1lf\t%c\n",a[i].name,a[i].grade,a[i].classement);
    }
}

