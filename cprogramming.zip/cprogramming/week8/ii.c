#include <stdio.h>
 
int main()
{
    int n = 10;
 
    while (n--)
    {
        printf("%d ", n);
    }
 
    printf("\n");
 
    return 0;
}
