#include<stdio.h>

int main(){
    int soluong,i = 1;
    float diem, tongDiem=0, tb;
    printf("Nhap so luong sinh vien: ");
    scanf("%d", &soluong);
    while(i<=soluong){
        printf("Nhap diem sinh vien thu %d: ", i);
        scanf("%f", &diem);
        if(diem<0){
            printf("Diem khong hop le");
            break;
        }
        tongDiem+=diem;
        i++;
    }
    tb = tongDiem/soluong;
    printf("Diem TB = %f", tb);
    
    return 0;
}
