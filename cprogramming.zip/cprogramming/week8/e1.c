
#include<stdio.h>
int main()
{
    char c;
    int i=0;
    while ((c=getchar())!='.')
    {
        if (c=='\t')
        { printf(" ");
        }
        else
        if (c=='\\ ')
        {
            if (i != 1)
            {
                printf(" \ ");
               
                i=1;
            }
        }
        else
        {
            i=0;
            putchar(c);
        }
    }
    
    printf("\n");
    return 0;
}
