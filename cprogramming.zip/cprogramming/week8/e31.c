#include<stdio.h>

int main(){
    unsigned int a;
    int x=0;
    printf("Nhap so:");
    scanf("%d", &a);
    do{
        printf("%d", x);
        printf("\n");
        x++;
    }while(x<=a);
    return 0;
}
