#include<stdio.h>
int main()
{
    int n=1;
    int dat=0;
    int tach=0;
    
    while(n>=1 && n<=10)
    {
        int x;
        printf("Nhap diem vao day:");
        scanf("%d",&x);
        
        if(x>=6)
        {
            dat++;
        }
        else
        {
            tach++;
        }
        n++;
    }
    printf("So sinh vien qua mon la %d\n",dat);
    printf("So sinh vien tach mon la %d\n",tach);
    return 0;
}
