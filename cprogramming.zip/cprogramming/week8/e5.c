#include<stdio.h>
int main(){
  int n,i=1,a=1;
  printf("enter n");
  scanf("%d",&n);
  while(i<=n){
    a=a*i;
      i++;
  }
  printf("giai thua of %d : %d",n,a);
  return 0;
}
      
