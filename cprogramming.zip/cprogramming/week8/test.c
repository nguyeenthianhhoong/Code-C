#include <stdio.h>

int main() {
	int m, n = 0;
	int i = 1;
	int j = 1;
	
		while (m < 10) {
			m = m + i;
			i = i + 1;
		}
		do {
			n = n + j;
			j = j + 1;	
		} while (n < 10);

	if (m == n) {
		printf("Equal!");
	} else {
		printf("Not equal!");
	}
	return 0;
}
