#include <stdio.h>
#include <string.h> // for strcmp function
 
int main()
{
    char p[20] = "Iloveyou";      // pass saved
    char pass[20];              // pass must enter
 
    do
    {
        printf("Enter your password: ");
        gets(pass);
    } while ( strcmp(p, pass) != 0);
 
    printf("Ok. You are login success!\n");
 
    return 0;
}

