#include <stdio.h>
#define eof '.'
int main()
  
{
    char c;
    int i = 0;
    
    while((c = getchar()) != eof)
    {
        if( c == ' ')
        {
            if( i != 1)
            {
                putchar(c);
                i = 1;
            }
            else continue;
        }
        else
        {
            putchar(c);
            i = 0;
        }
    }
    return 0;
}
