#include<stdio.h>
int main(){
  int a;
  unsigned int b;
  printf("enter a:");
  scanf("%d",&a);
  for (b=1;b<=a;b++)
    printf("%d",b);
  return 0;
}
