#include<stdio.h>
#define PI 3.142
main()
{
  double r,c,ac;
  r=5.678;
  printf("radius=%f\n",r);
  c=2.0*PI*r;
  printf("circle's circumference=%f\n",c);
  ac=PI*r*r;
  printf("circle's area=%f\n",ac);
}
