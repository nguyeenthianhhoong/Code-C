#include<stdio.h>
int main(){
printf("My neighbor's name is duong\n");
return 0;
}
