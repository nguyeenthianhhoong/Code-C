#include<stdio.h>
int main(){
        printf("#include<stdio.h>\n");
        printf("int main(){\n");
        printf("printf(\"My neighbor's name is duong\\n\");\n");
        printf("return 0;\n}\n");
        return 0;
}
