#include<stdio.h>
int main(){
  printf("***********************\n");
  printf("my name is .......\n");
  printf("nice to meet you\n");
  printf("***********************\n");
  return 0;
}
