#include <stdio.h>
#include <stdlib.h>
 
int main() 
{
    double a[10][10], *pa[10];
    int n, m, i, j;
 
    printf("Nhap so hang va so cot: ");
    scanf("%d %d", &n, &m);
 
    for (i = 0 ; i < n; i++) 
    {
        pa[i] = a[i]; // con tro thu i tro den hang thu i
        for (j = 0 ; j < m; j++) 
        {
            printf("Nhap a[%d][%d] = ", i, j);
            scanf("%lf", &pa[i][j]);
        }
    }
 
    for (i = 0 ; i < n; i++) 
    {
        printf("\n"); // xuong dong
        for (j = 0 ; j < m; j++) 
        {
            printf("%-5.2lf", pa[i][j]);
        }
    }
 
    return 0;
}
