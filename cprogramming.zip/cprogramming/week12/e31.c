#include<stdio.h>
int getminmax(int *arr, int size,int *Min, int *Max)
{
    *Min=*arr;
    *Max=*arr;
    for(int i=0;i<size;i++,arr++)
    {
        if(*arr>=*Max) *Max=*arr;
        if(*arr<=*Min) *Min=*arr;
    }
    return 0;
}
int main()
{
    int a[5]={1,2,3,4,5};
    int min, max;
    getminmax(a, 5, &min, &max);
    return 0;
}
