#include<stdio.h>
int getminmax(int *arr,int *min,int *max,int size)
{
  *min=*arr;
  *max=*arr;
  for(int i=0;i<size;i++)
    {if(*arr<=*min)
	min=arr[i];
      if(*arr>=*max)
	max=arr[i];
    }
  return 0;
}
int main(){
  int a[10],size,*min,*max,s;
  printf("size=");
  scanf("%d",&size);
  for( int i=0;i<size;i++)
    {printf("a[%d]=",i);
      scanf("%d",&s);}
  getminmax(a,&min,&max,size);
  printf("min:%d\n max:%d\n",min,max);
  return 0;
}
