#include<stdio.h>
int *findmax(int arr[],int n);

int main(){
  int n,i,*p,*q;
  printf("enter:");
  scanf("%d",&n);
  int arr[n];
  for(i=0;i<n;i++){
    printf("enter arr[%d]:",i);
    scanf("%d",&arr[i]);
  }
  p=findmax(arr,n);
 
  printf("max:%d",*p);
 
  return 0;
}
int *findmax(int data[],int n){
  int *max=data;
  int i;
  for(i=1;i<n;i++){
    if(*max<*(max+i))
      *max=*(max+i);
  }
  return max;
}
