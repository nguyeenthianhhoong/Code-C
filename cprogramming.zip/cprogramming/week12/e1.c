#include<stdio.h>
#define MAXX 100
double *maximum(double *a, int size)
{
    double *max,*p;
    max=a;
    if(a==NULL) return NULL;
    for(p=a+1; p<a+size; p++)
        if(*p>*max) max=p;
    return max;
}

int main(){
    int size;
    double a[MAXX];
    printf("so phan tu cua mang: ");
    scanf("%d",&size);
    for(int i=0; i<size; i++){
        printf("a[%d]= ", i+1);
        scanf("%lf", &a[i]);
    }
    
    double *p=maximum(a,size);
    printf("dia chi cua phan tu lon nhat la: %p",p);
    return 0;
}
