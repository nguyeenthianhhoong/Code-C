#include<stdio.h>
void reverseUsingIndex(int a[], int s){
    int c;
    for(int i=0;i<s/2;i++)
    {
        c=a[i];
        a[i]=a[s-i-1];
        a[s-i-1]=c;
    }
}
void reverseUsingPointer(int *p, int s){
    int c;
    for(int i=0;i<s/2;i++)
    {
        int c=*(p+i);
        *(p+i)=*(p+s-i-1);
        *(p+s-i-1)=c;
    }
}
int main()
{
    int a[100];
    int s;
    printf("Nhap so luong mang: ");
    scanf("%d", &s);
    printf("Nhap mang");
    for(int i=0;i<s;i++)
    scanf("%d", &a[i]);

    // reverseUsingIndex(a, s);
    reverseUsingPointer(a, s);
    
    printf("Mang sau khi sap xep ");
    for(int i=0;i<s;i++)
      printf("%d", a[i]);
    return 0;
}
