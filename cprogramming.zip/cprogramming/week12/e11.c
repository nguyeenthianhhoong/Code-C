#include<stdio.h>
#define ma 20
double *max(double *a,int size){
  double *max,*x;
  max =a;
  if(a==NULL)
    return NULL;
  for(x=a+1;x<size+a;x++)
    if(*x>*max)
      *max=*x;
  return max;
}
int main(){
  int size;
  double s[ma];
  double *maxi= max(s,size);
  printf("enter size:");
  scanf("%d",&size);
  for (int i=0;i<size;i++){
    printf("s[%d]=",i);
    scanf("%lf",&s[i]);
  }
  printf("address of max:%p\n",maxi);
  return 0;
}
  
    
    
