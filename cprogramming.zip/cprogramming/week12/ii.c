#include <stdio.h>
 
int main() 
{
    int n = 5, i;
    int a[n], *pa;
    pa = a; // con tro pa tro toi dau mang a
 
    for (i = 0; i < n; i++) 
    {
        printf("Nhap a[%d] = ", i);
        scanf("%d", pa + i);
    }
 
    for (i = 0; i < n; i++) 
    {
        printf ("%d \t", *(pa + i));
    }
 
    return 0;
}
