#include<stdio.h>
int counteven(int *x,int sophantu){
  int count=0;
  for(int i=0; i<sophantu;i++)
    if(*(x+i) %2==0)
      count+=1;
  return count;
}
int main(){
  int a[5],count=counteven(a,5),i;
  for(i=0;i<5;i++){
  printf("enter a[%d]=",i);
  scanf("%d",&a[i]);}

    
  printf("%d",count);
  return 0;
}
  
