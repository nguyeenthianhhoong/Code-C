#include <stdio.h>
 
void nhapMang(int a[], int n) 
{
    int i;
    for (i = 0; i < n; i++) 
    {
        printf("Nhap a[%d] = ", i);
        scanf("%d", &a[i]);
    }
}
 
void nhapContro(int a[], int n)
{
    int i;
    for (i = 0; i < n; i++) 
    {
        printf("Nhap a[%d] = ", i);
        scanf("%d", a + i);
    }
}
 
void xuatMang(int a[], int n) 
{
    int i;
    for (i = 0; i < n; i++) 
    {
        printf ("%d \t", a[i]);
    }
}
 
int main() 
{
    // khai bao mang a co n phan tu
    int n = 5;
    int a[n];
    nhapContro(a, n);
    xuatMang(a, n);
 
    return 0;
}
