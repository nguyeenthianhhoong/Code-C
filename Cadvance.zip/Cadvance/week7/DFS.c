#include "dllist.h"
#include "jrb.h"
#include <stdio.h>
#include <stdlib.h>
typedef JRB Graph;
Graph creatGraph();
void addEdge(Graph graph, int v1, int v2);
int adjacent(Graph graph, int v1, int v2);
getAdjacentVertices(Graph graph, int v, int *output);
void DFS(Graph graph, int start, int stop, void (*func)(int));
void printfVertex(int v) { printf("%4d", v); }
void BFS(Graph graph, int start, int stop, void (*func)(int));
void dropGraph(Graph graph);
int main() {
  Graph g = creatGraph();
  printf("Hello!\n");
  addEdge(g, 0, 1);
  addEdge(g, 1, 2);
  addEdge(g, 1, 3);
  addEdge(g, 2, 3);
  addEdge(g, 2, 4);
  addEdge(g, 4, 5);
  printf("\nDFS: start from node 2 to   5 : ");
  DFS(g, 1, 4, printfVertex);
  printf("\nDFS: start from node 1 to all : ");
  DFS(g, 1, -1, printfVertex);
  printf("\nBDFS: start from node 1 to   5 : ");
  BFS(g, 1, 5, printfVertex);
  printf("\nBFS: start from node 1 to all : ");
  BFS(g, 1, -1, printfVertex);
  printf("\n");
  dropGraph(g);
  return 0;
}

// Ham
Graph creatGraph() { return make_jrb(); }
void addEdge(Graph graph, int v1, int v2) {
  JRB node, tree;
  if (!adjacent(graph, v1, v2)) {
    node = jrb_find_int(graph, v1);
    if (node == NULL) {
      tree = make_jrb();
      jrb_insert_int(graph, v1, new_jval_v(tree));
    } else {
      tree = (JRB)jval_v(node->val);
    }
    jrb_insert_int(tree, v2, new_jval_i(1));
  }
  if (!adjacent(graph, v2, v1)) {
    node = jrb_find_int(graph, v2);
    if (node == NULL) {
      tree = make_jrb();
      jrb_insert_int(graph, v2, new_jval_v(tree));
    } else {
      tree = (JRB)jval_v(node->val);
    }
    jrb_insert_int(tree, v1, new_jval_i(1));
  }
}
int adjacent(Graph graph, int v1, int v2) {
  JRB node, tree;
  node = jrb_find_int(graph, v1);
  if (node == NULL) {
    return 0;
  }
  tree = (JRB)jval_v(node->val);
  if (jrb_find_int(tree, v2) == NULL) {
    return 0;
  } else {
    return 1;
  }
}

int getAdjacentVertices(Graph graph, int v, int *output) {
  JRB node, tree;
  node = jrb_find_int(graph, v);
  int total;
  if (node == NULL) {
    return;
  } else {
    tree = (JRB)jval_v(node->val);
    total = 0;
    jrb_traverse(node, tree) {
      output[total] = jval_i(node->key);
      total++;
    }
  }
  return total;
}

void DFS(Graph graph, int start, int stop, void (*func)(int)) {
  int u, n, visited[100] = {};
  int output[1000], v;
  Dllist node, queue;
  queue = new_dllist();
  dll_append(queue, new_jval_i(start));
  while (!dll_empty(queue)) {
    node = dll_last(queue);
    u = jval_i(node->val);
    dll_delete_node(node);
    if (!visited[u]) {
      func(u);
      visited[u] = 1;
      if (u == stop) {
        return;
      }
      n = getAdjacentVertices(graph, u, output);
      for (int i = 0; i < n; i++) {
        v = output[i];
        if (!visited[v]) {
          dll_append(queue, new_jval_i(v));
        }
      }
    }
  }
}
void BFS(Graph graph, int start, int stop, void (*func)(int)) {
  int visited[1000] = {};
  int n, output[1000], u, v;
  Dllist queue, node;
  queue = new_dllist();
  dll_append(queue, new_jval_i(start));
  while (!dll_empty(queue)) {
    node = dll_first(queue);
    u = jval_i(node->val);
    dll_delete_node(node);
    while (!visited[u]) {
      visited[u] = 1;
      func(u);
      if (u == stop) {
        return;
      }
      n = getAdjacentVertices(graph, u, output);
      for (int i = 0; i < n; i++) {
        v = output[i];
        if (!visited[v]) {
          dll_append(queue, new_jval_i(v));
        }
      }
    }
  }
}
void dropGraph(Graph graph) {
  JRB node, tree;
  jrb_traverse(node, graph) {
    tree = (JRB)jval_v(node->val);
    jrb_free_tree(tree);
  }
  jrb_free_tree(graph);
}