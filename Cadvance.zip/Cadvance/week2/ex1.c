#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

int Search(void *buf, int size,int l,int r,void *item,int (*compare)(void const*,void const*))
{
  if (r < l) return -1;
  int i = (l+r)/2;
  int res = compare(item, (char*)buf + (size*i));
  if(res==0) return i;
  else if(res < 0) return Search(buf,sizeof(int), l, i-1, item, compare);
  else return Search(buf,sizeof(int), i+1, r, item, compare);
}

int int_compare(void const *x,void const *y)
{
  int m,n;
  m = *((int*)x);
  n = *((int*)y);
  if(m==n) return 0;
  return (m>n)?1:-1;
  }

int main()
{
  int n=20,i;
  int *a = (int*)malloc(n*sizeof(int));
  for(i=0; i<n; i++)
    {
      a[i]=rand()%100;
    }
  qsort(a, n, sizeof(int), int_compare);
  for(i=0; i<n; i++)
    {
      printf("%d  ",a[i]);
    }
  printf("\n");
  int item;
  printf("number: ");
  scanf("%d",&item);
  printf("address: %d\n", Search(a, sizeof(int), 0, n-1, &item, int_compare)+1);
  return 0;
}
