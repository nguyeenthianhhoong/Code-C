#include <stdio.h>
#include <stdlib.h>
#define size 100



int int_compare(const void * a, const void * b){
   return ( *(int*)a - *(int*)b );
}

int main(){
  int *a=(int*)malloc(size*sizeof(int));
  int i;
  for(i=0;i<size;i++){
    a[i]=rand()%100;
  }
   printf("Truoc khi sap xep \n");
   for(i=0;i<size;i++ ) {
      printf("%d ", a[i]);
   }

   qsort(a, size, sizeof(int), int_compare);
   printf("\nSau khi sap xep \n");
   for(i=0;i<size;i++ ) {
      printf("%d ", a[i]);
   }
   printf("\n");
   
  
   return(0);
}
