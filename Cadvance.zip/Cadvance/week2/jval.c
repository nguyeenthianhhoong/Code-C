#include<stdio.h>
#include<stdlib.h>
#include <time.h>
#include <string.h>

typedef union {
  int i;
  long l;
  float f;
  double d;
  void *v;
  char *s;
  char c;
} Jval; //jval dung de luu tru cac loai du lieu khac nhau

//ham khoi tao
Jval new_jval_i(int i){
  Jval j;
  j.i=i;
  return j;
}

Jval new_jval_f(float f){
  Jval j;
  j.f=f;
  return j;
}

Jval new_jval_d(double d){
  Jval j;
  j.d=d;
  return j;
}

Jval new_jval_v(void *v){
  Jval j;
  j.v=v;
  return j;
}


//ham truy cap
int jval_i(Jval j){
  return j.i;
}
float jval_f(Jval j){
  return j.f;
}
void *jval_v(Jval j){
  return j.v;
}


///////////////
void jvalSwap(Jval *a, int j, int k, int size){

	char *buf = (char *)a;
	char temp;
	for(int i = 0; i < size; i++){
		temp = buf[size * j + i];
		buf[size * j + i] = buf[size * k + i];
		buf[size * k + i] = temp;
	}

}

void sort_i(Jval *a,int num,int size,int (*compare)(const Jval*,const Jval*)){
        if(num <= 1) return;
	int R = num - 1;
	int i = 0, j = R + 1;
	int p = 1, q = R;
	while(1){
		while(compare(&a[++i], &a[0]) < 0)
			if(i == R) break;
		while(compare(&a[--j], &a[0]) > 0);
		if(i >= j) break;

		jvalSwap(a, i, j, size);
		if(compare(&a[0], &a[i]) == 0){
			jvalSwap(a, p, i, size);
			p++;
		}
		if(compare(&a[0], &a[j]) == 0){
			jvalSwap(a, q, j, size);
			q--;
		}

	}

	for(int k = 0; k < p; k++, j--) jvalSwap(a, k, j, size);
	for(int k = q + 1; k <= R; k++, i++) jvalSwap(a, k, i, size);

	sort_i  (a, j+1, size, compare);
	sort_i  (&a[i], num - i, size, compare);
}

Jval* create_array_i (int n){
  Jval *array=(Jval *)malloc(sizeof(Jval)*n);
  for(int i=0;i<n;i++)
    array[i]=new_jval_i(rand()%100);
  return array;

}

int compare_i(Jval const *x,Jval const *y){
  int m,n;
  m = *((int*)x);
  n = *((int*)y);
  if(m==n) return 0;
  return (m>n)?1:-1;
  }

  int main(){
    int n=20;
    Jval *a=create_array_i(n);
    sort_i(a,n,sizeof(Jval),compare_i);
    for(int i=0;i<n;i++){
      printf("%d\t",jval_i(a[i]));
    }
    return 0;
  }
