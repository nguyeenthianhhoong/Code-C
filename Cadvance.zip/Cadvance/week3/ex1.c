#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define max_phone_number 10

typedef struct{
  char name[80];
  int num;
}PhoneEntry;

typedef struct{
  PhoneEntry entries[max_phone_number];
  int total;
}Phonebook;
//Phonebook *Phonebook;

Phonebook createPhonebook(){
  Phonebook p;
  p.total=0;
  p.entries=(PhoneEntry*)malloc(max_phone_number*sizeof(PhoneEntry));
  return p;
  }

/*int binarysearch(PhoneEntry *entries,int l,int r,char*name, int *found){
  if(r<l){
    return -1;
    *found=0;
  }
  int mid=(l+r)/2;
  if(strcmp(entries->name,name)==0){
    return mid;
    *found=1;
  }
  else if(strmp(entries->name,name)>0)
    return binarysearch(entries,mid+1,r,name,found);
  else
    return binarysearch(entries,l,mid-1,name,found);
    }*/

int binarySearch(PhoneEntry *entries, int l, int r, char *name, int *found)
{
  int i, res;
  if(r < l)
    {
      *found = 0;
      return l;
    }
  i = (l+r)/2;
  res = strcmp(name, entries[i].name);
  if(res == 0)
    {
      *found =1;
      return i;
    }
  else if(res < 0)
    {
      return binarySearch(entries, l, i-1,name, found) ;
    }
  else
    {
      return binarySearch(entries, i+1, l,name, found) ;
    }
}

void addPhonen(char *name,int number,Phonebook* book){
  int found,p;
  if((p=binarysearch(book->entries,0,book->total-1,name,&found))!=-1){
me
  }
}
void dropPhonebook(Phonebook *book){
  free(book);
}

int main(){
  Phonebook *book;
  addPhonenumber(&book);
  
  return 0;
}

