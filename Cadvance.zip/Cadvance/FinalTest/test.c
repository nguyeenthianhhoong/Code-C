#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "graph.h"
#include "dijkstra.h"
#define max 100

void readFile1(Graph g, char *filename);
void readFile2(Graph g, char *filename);
void lienkettoi(Graph g);
void lienkettoiit(Graph g);
void chilienketden(Graph g);
void chilienketdi(Graph g);
void duongDiMin(Graph g, int s, int t);

int main(){
  Graph g=creatGraph();
  JRB node;
  int choice,n,id1,id2,w,cnt;
  int output[max];
  do{
    printf("\t\tMENU:\n");
    printf("\t1. Noi dung file\n");
    printf("\t2. PageRank khoi tao\n");
    printf("\t3. PageRank sau m lan\n");
    printf("\t4. Lien ket\n");
    printf("\t5. Khoang cach\n");
    printf("\t6. Thoat\n");
    do{
      printf("Input a choice:");
      scanf("%d",&choice);
    }
    while (choice < 1|| choice >6 );
    switch(choice){

    case 1:
      readFile1(g,"webpages.txt");
      n=getVertexCount(g);
      printf("%d\n",n);
      jrb_traverse(node,g.vertices){
	printf("%d %s\n",jval_i(node->key),jval_s(node->val));
      }
      printf("---------------------------\n");
      readFile2(g,"pageConnections.txt");
      printf("Web nhieu lien ket toi nhat: ");
      lienkettoi(g);
      printf("\n");
      printf("Web it lien ket toi nhat: ");
      lienkettoiit(g);
      break;
      
    case 2:
     
      
      break;
      
    case 3:
     
      
    case 4:
      printf("web chi co lien ket den: ");
      chilienketden(g);
      printf("\n");
      printf("web chi co lien ket di: ");
      chilienketdi(g);
      
      break;
      
    case 5:
     printf("ID1:");
      scanf("%d",&id1);
      printf("ID2:");
      scanf("%d",&id2);
      //duongDiMin(g,id1,id2);
      
       /*w = shortestPath(g, id1, id2, output, &cnt);
    
    if (w == INFINITIVE_VALUE)
    {
         printf("No path from %s to %s\n", getVertex(g, id1), getVertex(g, id2));
    }else
    {
         printf("Path from %s to %s (with total distance %f)\n", getVertex(g, id1), getVertex(g, id2), w);
         for (int i=0; i<cnt; i++)
             printf(" => %s", getVertex(g, output[i]));
    }
      */

      break;
      
    case 6:
dropGraph(g);
      break;
     }
    } while (choice!=6);
    return 0;

}

void readFile1(Graph g, char *filename){
  IS is=new_inputstruct(filename);
  int n,id;
  char url;
  get_line(is);
  n=atoi(is->fields[0]);
  while (get_line(is)>0){
    addVertex(g,atoi(is->fields[1]),is->fields[0]);

  }
 jettison_inputstruct(is);
}



void readFile2(Graph g, char *filename){
  IS is=new_inputstruct(filename);
  int id1,id2,m;
  get_line(is);
  m=atoi(is->fields[0]);
  while(get_line(is) != -1){
    id1=atoi(is->fields[0]);
    for(int i=1;i < is->NF;i++){
	id2=atoi(is->fields[i]);	
	addEdgeValue(g,id1,id2,1);    
     }
  }
    
 jettison_inputstruct(is); 

}

void lienkettoi(Graph g){
  JRB node;
    int mark = 0;
    int cnt;
    jrb_traverse(node, g.vertices){
        int output[max];
        cnt = inDegree(g, jval_i(node->key), output);
        if(cnt > mark){
            mark = cnt;
        }
    }

    jrb_traverse(node, g.vertices){
        int output[max];
        cnt = inDegree(g, jval_i(node->key), output);
        if(cnt == mark){
printf("%d %s\n",jval_i(node->key),jval_s(node->val));
            //printf("%s %d\n", jval_s(node->val),jval_i(node->key));
        }
    }
    printf("\n");
  
  
}

void lienkettoiit(Graph g){
  JRB node;
    int mark =100;
    int cnt;
    jrb_traverse(node, g.vertices){
        int output[max];
        cnt = inDegree(g, jval_i(node->key), output);
        if(cnt < mark){
            mark = cnt;
        }
    }

    jrb_traverse(node, g.vertices){
        int output[max];
        cnt = inDegree(g, jval_i(node->key), output);
        if(cnt == mark){
printf("%d %s\n",jval_i(node->key),jval_s(node->val));
            //printf("%s %d\n", jval_s(node->val),jval_i(node->key));
        }
    }
    printf("\n");
  
}

void chilienketden(Graph g){
  JRB node;
    int mark =100;
    int in,out;
    jrb_traverse(node, g.vertices){
      int output1[max],output2[max];
        in = inDegree(g, jval_i(node->key), output1);
	out = outDegree(g, jval_i(node->key), output2);
	if(out==0)
	  printf("%s\n",jval_s(node->val));
            
    }
    printf("\n");

}


void chilienketdi(Graph g){
  JRB node;
    int mark =100;
    int in,out;
    jrb_traverse(node, g.vertices){
      int output1[max],output2[max];
        in = inDegree(g, jval_i(node->key), output1);
	out = outDegree(g, jval_i(node->key), output2);
	if(in==0)
	  printf("%s\n",jval_s(node->val));
            
    }
    printf("\n");

}


/*

void duongDiMin(Graph g, int s, int t){
    if(jrb_find_int(g.vertices, s) == NULL || jrb_find_int(g.vertices, t) == NULL){
        printf("Khong ton tai\n");
        return;
    }
    //printf("hi\n");
    int output[max];
    double w;
    int cnt;
    //w = shortestPath_s_to_t(g, s, t, output, &cnt);
    w = shortestPath(g, id1, id2, output, &cnt);
    printf("Khoang cach ngan nhat tu %d den %d:\n",s,t);
    if(w == INFINITIVE_VALUE){
        printf("-1\n");
    }else{
        printf(" %g\n", w);
        printf("\t");
        for(int i = 0; i < cnt-1; i++){
            printf("%d --> ", output[i]);
        }
        printf("%d\n", output[cnt-1]);
	}
    if (w == INFINITIVE_VALUE)
    {
         printf("No path from %s to %s\n", getVertex(g, id1), getVertex(g, id2));
    }else
    {
         printf("Path from %s to %s (with total distance %f)\n", getVertex(g, id1), getVertex(g, id2), w);
         for (int i=0; i<cnt; i++)
             printf(" => %s", getVertex(g, output[i]));
    }
  


    }*/
  

