#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "graph.h"
#include "dijkstra.h"

void readFile1(Graph g, char *filename);
void readFile2(Graph g, char *filenme);
void swap1(double *a, double *b);
void swap2(int *a, int *b);
int sanPhamLq(Graph g, int id, int *output);
double duongdi(Graph g, int id1, int id2, int *output, int *getNum);

int main(){
  Graph g=creatGraph();
  JRB node;
  int choice,id1,id2,count,output[1000],i;
  double test;
  do{
    printf("\t\tMENU:\n");
    printf("\t1. Danh sach san pham\n");
    printf("\t2. Danh sach giao dich\n");
    printf("\t3. Muc do lien quan giua 2 san pham\n");
    printf("\t4. Danh sach cac san pham lien quan\n");
    printf("\t5. Moi lien he giua 2 san pham\n");
    printf("\t6. Thoat\n");
    do{
      printf("Input a choice:");
      scanf("%d",&choice);
    }
    while (choice < 1|| choice >6 );
    switch(choice){

    case 1:
      readFile1(g,"products.txt");
      jrb_traverse(node,g.vertices){
	printf("Ma san pham:%d\n",jval_i(node->key));
	printf("Ten san pham:%s\n\n",jval_s(node->val));
      }
      break;
      
    case 2:
      readFile2(g,"orderhistory.txt");
      
      break;
      
    case 3:
      printf("ID1:");
      scanf("%d",&id1);
      printf("ID2:");
      scanf("%d",&id2);
      printf("Do lien quan giua 2 san pham:");
      if(!hasEdge(g,id1,id2))
	 printf("-1\n");
      else
	printf("%g\n",getEdgeValue(g,id1,id2));
      break;
      
    case 4:
      printf("ID: ");
      scanf("%d",&id1);
      count=sanPhamLq(g,id1,output);
      printf("Cac san pham lien quan:");
      for(i=0;i<count;i++)
	printf("%s\t",getVertex(g,output[i]));
      printf("\n");
      break;
      
    case 5:
     printf("Nhap 2 sp: ");
                scanf("%d%d", &id1, &id2);
                test = duongdi(g, id1, id2, output, &count);
                if(test == INFINITIVE_VALUE){
                    printf("Hai san pham khong co lien he voi nhau\n");
                    break;
                }
                // printf("%s", getVertex(g, id2));
                // int i = w[id2];
                // while(i != id1){
                //     printf("<---- %s", getVertex(g, i));
                //     i = w[i];
                // }
                // printf("<-----%s\n", getVertex(g, i));
                for(int i = 0; i < count - 1; i++){
                    printf("%s---->", getVertex(g, output[i]));
                }
                printf("%s\n", getVertex(g,output[count-1]));
                

      break;
      
    case 6:

      break;
     }
    } while (choice!=6);
    return 0;

}
void readFile1(Graph g,char *filename){
  IS is = new_inputstruct(filename);
  while(get_line(is) != -1){   
    addVertex(g,atoi(is->fields[0]),is->fields[1]);
  }
  jettison_inputstruct(is);
}

void readFile2(Graph g,char *filename){
  IS is= new_inputstruct(filename);
  int id1,id2;
  JRB node1,tree1,node2,tree2;
  while(get_line(is) != -1){
    for(int i=0;i < is->NF;i++){
      for(int j=i+1; j<is->NF; j++){
	id1=atoi(is->fields[i]);
	id2=atoi(is->fields[j]);
	if(hasEdge(g,id1,id2)){
                    node1 = jrb_find_int(g.edges, id1);
                    tree1 = (JRB) jval_v(node1->val);
                    node1 = jrb_find_int(tree1, id2);
                    node1->val.d += 1;

                    node2 = jrb_find_int(g.edges, id2);
                    tree2 = (JRB) jval_v(node2->val);
                    node2 = jrb_find_int(tree2, id1);
                    node2->val.d += 1;
		    
	   }else{
	  addEdgeValue(g,id1,id2,1);
	  addEdgeValue(g,id2,id1,1);
	 	}
	
      }
      printf("%s\t",getVertex(g,atoi(is->fields[i])));
    }
	printf("\n");

  }
  jettison_inputstruct(is);
}
void swap1(double *a, double *b){
    double tmp = *a;
    *a = *b;
    *b = tmp;
}

void swap2(int *a, int *b){
    int tmp = *a;
    *a = *b;
    *b = tmp;
}

int sanPhamLq(Graph g, int id, int *output){
  double w[1000];
    int count = 0;
    count = outDegree(g, id, output);
    for(int i = 0; i < count; i++){
        w[i] = getEdgeValue(g, id, output[i]);
    }
    for(int i = 0; i < count; i++){
        for(int j = count-1; j >= i; j--){
            if(w[i] < w[j]){
                swap1(&w[i], &w[j]);
                swap2(&output[i], &output[j]);
            }
        }
    }
    return count;

}

double duongdi(Graph g, int id1, int id2, int *output, int *getNum){
    double w;
    w = shortestPath_s_to_t(g, id1, id2, output, getNum);
    return w;
}



