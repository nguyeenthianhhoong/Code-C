#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "graph.h"
#include "dijkstra.h"
#define max 100

//int menu(void);
void readFile(Graph g, Graph g2, char *filename, int *n);
void printMatrix(Graph g, double arr[100][100], int n);
void printDanhsachke(Graph g);
int checkDibo(Graph g, int id1, int output[max], int cnt);
void chucnang3a(Graph g);
void chucnang3b(Graph);
void duongDiMin(Graph g, int s, int t);
void chucnang5(Graph g, int s, int t);

int main(){
  Graph g = creatGraph();
  Graph g2 = creatGraph();
  int n,s,t;
  double arr[max][max] = {};
  int choice;
  
  do{
    printf("\t\tMENU:\n");
    printf("\t1. Doc do thi\n");
    printf("\t2. In ma tran ke cua moi thanh tri\n");
    printf("\t3. Dua ra\n");
    printf("\t4. Duong di ngan nhat\n");
    printf("\t5. Duong di bo ngan nhat\n");
    printf("\t6. Thoat\n");
    do{
      printf("Input a choice:");
      scanf("%d",&choice);
    }
    while (choice < 1|| choice >6 );
    switch(choice){

    case 1:
      readFile(g, g2, "dothi.txt", &n);
      printMatrix(g, arr, n);
      break;
      
    case 2:
      printDanhsachke(g);
      break;
      
    case 3:
      printf("Danh sach thanh tri chi co the den no bang di bo la: ");
      chucnang3a(g);
      printf("Danh sach thanh tri co nhieu duong di den no nhat la: ");
      chucnang3b(g);                   
      break;
      
    case 4:
      printf("Nhap thanh tri xuat phat: ");
      scanf("%d", &s);
      printf("Nhap thanh tri dich: ");
      scanf("%d", &t);
      duongDiMin(g, s, t);

      break;
      
    case 5:
      printf("Nhap thanh tri xuat phat: ");
      scanf("%d", &s);
      printf("Nhap thanh tri dich: ");
      scanf("%d", &t);
      chucnang5(g2, s, t);

      break;
      
    case 6:

      break;
     }
    } while (choice!=6);
    return 0;


}

void readFile(Graph g, Graph g2, char *filename, int *n){
    IS is = new_inputstruct(filename);
    int m;
    double w;
    int id1, id2;
    get_line(is);
    *n = atoi(is->fields[0]);
    m = atoi(is->fields[1]);
    while(get_line(is) > 0){
        id1 = atoi(is->fields[0]);
        id2 = atoi(is->fields[1]);
        addVertex(g, id1, is->fields[0]);
        addVertex(g, id2, is->fields[1]);
        w = atof(is->fields[2]);
        addEdgeValue(g, id1, id2, w);
        addEdgeValue(g, id2, id1, w);
        if(w >= 50){
            addVertex(g2, id1, is->fields[0]);
            addVertex(g2, id2, is->fields[1]);
            addEdgeValue(g2, id1, id2, w);
            addEdgeValue(g2, id2, id1, w);
        }
    }
}

void printMatrix(Graph g, double arr[max][max], int n){
    for(int i = 1; i <= n-1; i++){
        for(int j = i+1; j <= n; j++){
            if(hasEdge(g, i, j)){
                // arr[i][j] = getEdgeValue(g, i, j);
                // arr[j][i] = getEdgeValue(g, i, j);
                arr[i][j] = 1;
                arr[j][i] = 1;
            }
        }
    }
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= n; j++){
            printf("%-5g", arr[i][j]);
        }
        printf("\n");
    }
}

void printDanhsachke(Graph g){
    JRB node;
    int cnt;
    jrb_traverse(node, g.vertices){
        int ouput[max];
        printf("Castle %s: ", getVertex(g, jval_i(node->key)));
        cnt = outDegree(g, jval_i(node->key), ouput);
        for(int i = 0; i < cnt; i++){
            printf("%d ", ouput[i]);
        }
        printf("\n");
    }
}

int checkDibo(Graph g, int id1, int output[max], int cnt){
    for(int i = 0; i < cnt; i++){
        if(getEdgeValue(g, output[i], id1) < 50){
            return 0;
        }
    }
    return 1;
}

void chucnang3a(Graph g){
    JRB node;
    int cnt;
    jrb_traverse(node, g.vertices){
        int ouput[max];
        cnt = inDegree(g, jval_i(node->key), ouput);
        if(checkDibo(g, jval_i(node->key), ouput, cnt) == 1){
            printf("%d ", jval_i(node->key));
        }
    }
    printf("\n");
}

void chucnang3b(Graph g){
    JRB node;
    int mark = 0;
    int cnt;
    jrb_traverse(node, g.vertices){
        int output[max];
        cnt = inDegree(g, jval_i(node->key), output);
        if(cnt > mark){
            mark = cnt;
        }
    }

    // printf("%d", jval_i(tmp->key));
    jrb_traverse(node, g.vertices){
        int output[max];
        cnt = inDegree(g, jval_i(node->key), output);
        if(cnt == mark){
            printf("%d ", jval_i(node->key));
        }
    }
    printf("\n");
}

void duongDiMin(Graph g, int s, int t){
    if(jrb_find_int(g.vertices, s) == NULL || jrb_find_int(g.vertices, t) == NULL){
        printf("ROUTE NOT FOUND\n");
        return;
    }
    int output[max];
    double w;
    int cnt;
    w = shortestPath_s_to_t(g, s, t, output, &cnt);
    if(w == INFINITIVE_VALUE){
        printf("ROUTE NOT FOUND\n");
    }else{
        printf("Duong di ngan nhat tu %d den %d: \n", s, t);
        printf("\tDo dai duong di: %g\n", w);
        printf("\t");
        for(int i = 0; i < cnt-1; i++){
            printf("%d --> ", output[i]);
        }
        printf("%d\n", output[cnt-1]);
    }
}

void chucnang5(Graph g, int s, int t){
    if(jrb_find_int(g.vertices, s) == NULL || jrb_find_int(g.vertices, t) == NULL){
        printf("ROUTE NOT FOUND\n");
        return;
    }
    int output[max];
    double w;
    int cnt;
    w = shortestPath_s_to_t(g, s, t, output, &cnt);
    if(w == INFINITIVE_VALUE){
        printf("ROUTE NOT FOUND\n");
    }else{
        printf("Duong di bo ngan nhat tu %d den %d: \n", s, t);
        printf("\tDo dai duong di: %g\n", w);
        printf("\t");
        for(int i = 0; i < cnt-1; i++){
            printf("%d --> ", output[i]);
        }
        printf("%d\n", output[cnt-1]);
    }
}
