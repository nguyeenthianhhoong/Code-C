#include <stdio.h>
#include <stdlib.h>

int main()
{
    char * s = "LE TAN DAT";
    int count[26] = {0};
    int i;
    for(i = 0; i < 26; ++i)
        count[s[i] - 'A']++;
    for(i = 0; i < 26; ++i)
        if(count[i])
            printf("%c %d\n", i+'A', count[i]);
    return 0;
}