#include <stdio.h>
#include "graphlib.h"
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

typedef struct {
    char name[100];
}Station;
void readfile(){
    char a[81];
    int k,count=1;
    Station st[100];
    FILE *ptr;
    ptr = fopen("input.txt",'r');
    if(ptr == NULL){
        printf("can't open this file");
        return ;
    }
    fgets(a,81,ptr);
    while (strstr(a,"LINES")==NULL)                    //Tach ten Station
    {
        fgets(a,81,ptr);
        if (strstr(a,"LINES")!=NULL)
            break;

        int vitri,i;
        for (vitri = strlen(a); vitri >= 0; vitri--)
            if (a[vitri] == '=') break;

        for (i = vitri + 1; i < strlen(a); i++)
        {
            st[count].name[i - (vitri + 1)] = a[i];
        }
        st[count].name[i - (vitri + 1)] = '\0';// ket thuc xau ten
        count++;
    }
    printf("STATION: \n");
    for (int k = 0; k < count; k++)
    {
        printf("%s", st[k].name);
    }

    while (fgets(a,81,ptr)!=NULL)
    {
        int *num, k=0;
        num=(int *)malloc(50 * sizeof(int));
        for (int i=strlen(a); i>=0; i--)
        {
            if (a[i]=='=') break;
            if (isdigit(a[i]))
            {
                num[k]=(int)a[i]-48;
                k++;
            }
        }

        for (int i = 0; i < k-1; i++)
        {
            for (int j= i+1; j < k; j++)
            {
                printf("%s %s",num[i],num[j]);
            }
        }

        free(num);
    }
    
}

int main() {
    readfile();
    return 0;
}
