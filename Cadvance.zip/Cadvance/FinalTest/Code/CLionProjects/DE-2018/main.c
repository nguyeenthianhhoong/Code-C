#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "fields.h"
#include "mygraph.h"


int readfile(Graph *g,char* filename)
{
    IS is = new_inputstruct(filename);
    get_line(is);
    int m = atoi(is->fields[0]);
    for(int i = 0; i < m; i++){
        get_line(is);
        addVertex(g,atoi(is->fields[1]),is->fields[0]);
    }
    jettison_inputstruct(is);
    return m;
}
void readFile(Graph *graph,char *filename, int m){
    IS is = new_inputstruct(filename);
    get_line(is);
    int n = atoi(is->fields[0]);
    for(int i = 0; i < m, i++){
        get_line(is);
        addVertex(graph,atoi(is->fields[1]),is->fields[0]);

    }

}
void check3(Graph *graph,char *string){
    if(strcmp(string,"-s") == 0)
    printGraph(graph,0);
}
int main(int argc,char *agrv[]) {
    if(argc == 2 || argc == 3 || argc == 4 || argc == 6|| argc == 8);
    else printf("nhap sai tham so dau vao");
    if(argc == 2){
        if(strcmp(agrv[1],"-t") == 0)
            printf("C-Advanced, HK20182\n");
        return 0;
    }
    Graph graph;
    createGraph(&graph);
    readfile(&graph,agrv[2]);
    int m;
    if(argc == 3){
        m = check3(&graph,agrv[1]);
        return 0;
    }
    Graph graph1;
    createGraph(graph1);
    if(argc == 4 || argc == 6 || argc == 8)
    {
        readFile(&graph1,agrv[2],m);
    }
    dropGraph(&graph);
    dropGraph(&graph1)
    return 0;
}
