#ifndef UNTITLED5_DATA_H
#define UNTITLED5_DATA_H

#include "jrb.h"

typedef struct Graph{
    JRB vertex;
    JRB edges;
}Graph;

#endif
