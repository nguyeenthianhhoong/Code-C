#include <stdio.h>
#include "mygraph.h"

int main(int argc,char *argv[]){
    Graph graph;
    createGraph(&graph);

    addVertex(&graph,1,"ha noi");
    addVertex(&graph,2,"quang binh");
    addVertex(&graph,3,"long an");
    addVertex(&graph,4,"Da nang");
    addVertex(&graph,5,"nghe an");

    addEdge(&graph,1,3,NULL,0);
    addEdge(&graph,1,2,NULL,0);
    addEdge(&graph,1,5,NULL,0);
    addEdge(&graph,2,3,NULL,0);
    addEdge(&graph,2,4,NULL,0);
    addEdge(&graph,4,1,NULL,0);

    printGraph(&graph,0);

    dropGraph(&graph);
    return 0;
}