#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdio_ext.h>
#include "fields.h"
#include "jrb.h"
#include "jval.h"


/* Data */
typedef struct{
    char phone[12];
    char name[30];
}Data;
//
/* COMPARE */
int compareP(Jval x,Jval y){
    Data *p = (Data*)(x.v);
    Data *q = (Data*)(y.v);
    return strcmp(p->phone,q->phone);
}
int compareN(Jval x,Jval y){
    Data *p = (Data*)(x.v);
    Data *q = (Data*)(y.v);
    return strcmp(p->name,q->name);
}
//
/* INPUT */
JRB readFile(){
    int kt;
    IS is = new_inputstruct("input.txt");
    if(is == NULL){
        printf("\tKhong the mo file.\n");
        return NULL;
    }
    JRB root = make_jrb();
    while(1){
        kt = get_line(is);
        if(kt == EOF) break;
        Data *data = (Data*)calloc(1,sizeof(Data));
        strcpy(data->phone,is->fields[kt-1]);
        strcpy(data->name,is->fields[0]);
        int i;
        for(i = 1;i < kt-1;i++)
            strcat(strcat(data->name," "),is->fields[i]);
        jrb_insert_gen(root,new_jval_v(data),new_jval_v(data),compareN);
    }
    jettison_inputstruct(is);
    return root;
}
JRB nhapMoi(JRB root){
    char c;
    printf("\tBan co chac chan muon nhap lai(y/n) :");
    __fpurge(stdin);
    //fflush(stdin);
    scanf("%c",&c);
    if(c != 'y') return NULL;
    jrb_free_tree(root);
    JRB R = make_jrb();
    int i = 1;
    while(1){
        Data *data = (Data*)calloc(1,sizeof(Data));
        printf("\tNhap thong tin nguoi thu %d:\n",i++);
        printf("\tName : ");
        __fpurge(stdin);
        //fflush(stdin);
        scanf("%[^\n]s",data->name);
        printf("\tPhone : ");
        __fpurge(stdin);
        //fflush(stdin);
        scanf("%[^\n]s",data->phone);
        jrb_insert_gen(R,new_jval_v(data),new_jval_v(data),compareN);
        printf("\tBan co nhap them (y/n) ?");
        __fpurge(stdin);
        //fflush(stdin);
        scanf("%c",&c);
        if(c != 'y') break;
    }
    return R;
}
void nhapTiep(JRB root){
    int i = 1;
    while(1){
        Data *data = (Data*)calloc(1,sizeof(Data));
        JRB p;
        printf("\tNhap thong tin nguoi thu %d:\n",i++);
        printf("\tName : ");
        __fpurge(stdin);
        //fflush(stdin);
        scanf("%[^\n]s",data->name);
        p = jrb_find_gen(root,new_jval_v(data),compareN);
        if(p != NULL) {
            printf("\tTen da ton tai. Ban muon thay doi thong tin");
            char a;
            fflush(stdin);
            scanf("%c", &a);
            if (a = 'y') {
                printf("\tNhap so dien thoai can thay doi : ");
                Data *q = (Data *) (p->val.v);
                __fpurge(stdin);
                //fflush(stdin);
                scanf("%[^\n]s", q->phone);
            } else {
                printf("\tPhone : ");
                __fpurge(stdin);
                //fflush(stdin);
                scanf("%[^\n]s", data->phone);
                jrb_insert_gen(root, new_jval_v(data), new_jval_v(data), compareN);
            }
        }
        printf("\tBan co nhap them (y/n) ?");
        char c;
        __fpurge(stdin);
        //fflush(stdin);
        scanf("%c",&c);
        if(c != 'y') break;
    }
}
//
/* HANDLING */
void capNhat(JRB root){
    int chose;
    Data data;
    JRB p;
    while(1){
        printf("\tNhap name can tim : ");
        __fpurge(stdin);
        //fflush(stdin);
        scanf("%[^\n]s",data.name);
        p = jrb_find_gen(root,new_jval_v(&data),compareN);
        if(p == NULL)
            printf("\tkhong tim thay nguoi can tim!!\n");
        else {
            printf("\tNhap so dien thoai can thay doi : ");
            Data *q = (Data*)(p->val.v);
            __fpurge(stdin);
            //fflush(stdin);
            scanf("%[^\n]s",q->phone);
        }
        printf("\tBan co muon cap nhat tiep(y/n) ??");
        char c;
        __fpurge(stdin);
        //fflush(stdin);
        scanf("%c",&c);
        if(c != 'y') break;
    }
}
void xoaNode(JRB root){
    Data data;
    printf("\tNhap ten can xoa : ");
    __fpurge(stdin);
    //fflush(stdin);
    scanf("%[^\n]s",data.name);
    jrb_delete_node(jrb_find_gen(root,new_jval_v(&data),compareN));
}
JRB sortPhone(JRB root){
    JRB R = make_jrb();
    JRB p;
    jrb_traverse(p,root){
        Data *data = (Data *)(p->val.v);
        jrb_insert_gen(R,new_jval_v(data),new_jval_v(data),compareP);
    }
    return R;
}
void inNode(JRB node){
    Data *data = (Data *)(node->val.v);
    printf("\t%-30s\t%-13s\n",data->name,data->phone);
}
void search(JRB rootN,JRB rootP,int i){
    Data *data = (Data*)calloc(1,sizeof(Data));
    JRB p;
    if(i == 1){

        printf("\tNhap ten can tim :");
        __fpurge(stdin);
        //fflush(stdin);
        scanf("%[^\n]s",data->name);
        p = jrb_find_gen(rootN,new_jval_v(data),compareN);
    }
    else {
        printf("\tNhap phone can tim :");
        __fpurge(stdin);
        //fflush(stdin);
        scanf("%[^\n]s",data->phone);
        p = jrb_find_gen(rootP,new_jval_v(data),compareP);
    }
    if(p == NULL)
        printf("\tkhong tim thay nguoi can tim!!\n");
    else inNode(p);
    free(data);
    return ;
}
//
/* OUTPUT */
void writeFile(JRB root){
    FILE *f = NULL;
    f = fopen("output.txt","w");
    if(f == NULL){
        printf("\tKhong the mo file!!!\n");
        return ;
    }
    JRB p;
    jrb_traverse(p,root){
        Data *data = (Data *)(p->val.v);
        fprintf(f,"%s\t%s\n",data->name,data->phone);
    }
    fclose(f);
}
void inTree(JRB root){
    int i = 1;
    JRB p;
    printf("\tDanh sach cac lien he  : \n");
    printf("\tSTT       NAME                   Phone\n");
    jrb_traverse(p,root){
        Data *data = (Data*)(p->val.v);
        printf("\t%-5d%-25s\t%-12s\n",i++,data->name,data->phone);
    }
}
//
/* MENU */
JRB menu2(JRB root){
    int chose;
    while(1){
        printf("\t------- Menu ------\n");
        printf("\t1.Nhap moi hoan toan.\n");
        printf("\t2.Nhap them du lieu.\n");
        printf("\tNhap su lua chon cua ban:");
        __fpurge(stdin);
        //fflush(stdin);
        scanf("%d",&chose);
        switch(chose){
            case 1:
                nhapMoi(root);
                break;
            case 2:
                nhapTiep(root);
                return NULL;
                break;
            default :
                printf("\tLua chon khong phu hop.\n");
        }
    }
}
void menu8(JRB rootN,JRB rootP){

    int chose;
    while(1){
        printf("\t----- MENU ------\n");
        printf("\t1.Time kiem theo ten.\n");
        printf("\t2.Tim kiem theo phone\n");
        printf("\tNhap su lua chon cua ban : ");
        __fpurge(stdin);
        //fflush(stdin);
        scanf("%d",&chose);
        switch(chose){
            case 1:
                search(rootN,rootP,1);
                return;
            case 2:
                search(rootN,rootP,2);
                return ;
            default :
                printf("\tLua chon khong phu hop.\n");
        }
    }
}
void menu(){
    JRB root = NULL;
    JRB newRoot = NULL;
    JRB rootPhone = NULL;
    JRB currRoot = NULL;
    JRB p = NULL;
    int chose;
    while(1){
        printf("\t------- MENU -------\n");
        printf("\t1.Doc du lieu tu file.\n");
        printf("\t2.Nhap lai du lieu.\n");
        printf("\t3.Hien thi du lieu.\n");
        printf("\t4.Cap nhat thong tin.\n");
        printf("\t5.Xoa so dien thoai.\n");
        printf("\t6.Hien thi danh sach theo ten.\n");
        printf("\t7.Hien thi du lieu theo so dien thoai.\n");
        printf("\t8.Tim kiem thong tin.\n");
        printf("\t9.Ghi du lieu vao file.\n");
        printf("\t10.Exit.\n");
        printf("\tNhap su lua chon cua ban:");
        __fpurge(stdin);
        //fflush(stdin);
        scanf("%d",&chose);
        switch(chose){
            case 1:
                root = readFile();
                currRoot = root;
                break;
            case 2:
                p = menu2(root);
                if(p != NULL) currRoot = p;
                break;
            case 3:
                inTree(currRoot);
                break;
            case 4:
                capNhat(currRoot);
                break;
            case 5:
                xoaNode(currRoot);
                break;
            case 6:
                inTree(currRoot);
                break;
            case 7:
                rootPhone = sortPhone(currRoot);
                inTree(rootPhone);
                break;
            case 8:
                while(1) {
                    if (rootPhone == NULL) rootPhone = sortPhone(currRoot);
                    menu8(currRoot, rootPhone);
                    printf("\tBan co muon tiep tuc tim kiem: ");
                    char c;
                    __fpurge(stdin);
                    //fflush(stdin);
                    scanf("%c",&c);
                    if(c != 'y') break;
                }
                break;
            case 9:
                writeFile(currRoot);
                break;
            case 10:
                if(root != NULL) jrb_free_tree(root);
                if(rootPhone != NULL)jrb_free_tree(rootPhone);
                if(newRoot != NULL)jrb_free_tree(newRoot);
                if(p != NULL)jrb_free_tree(p);
                return ;
            default :
                printf("\tLua chon khong phu hop.\n");
        }
    }
}
//
/* MAIN */
int main() {
    menu();
    return 0;
}
//

