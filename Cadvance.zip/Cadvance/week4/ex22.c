#include<stdio.h>
#include"jrb.h"

int main(){
  JRB tree,bn;
  int n,i,choice;
  int a[n];
  tree=make_jrb();

  do{
    printf("\t\tMENU:\n");
    printf("\t1. INSERT\n");
    printf("\t2. DISPLAY\n");
    printf("\t3. DESTROY\n");
    printf("\t4. QUIT\n");
    do{
      printf("Input a choice:");
      scanf("%d",&choice);
    }
    while (choice < 1|| choice >4 );
    switch(choice){

    case 1:
      printf("So gia tri:");
      scanf("%d",&n);
      for(i=0;i<n;i++){
	printf("Enter:");
	scanf("%d",&a[i]);
	(void) jrb_insert_int(tree,a[i],new_jval_i(a[i]));
      }
      break;
    case 2:
      jrb_traverse(bn,tree){
	printf("%d\t",jval_i(bn->key));
      }
      printf("\n");
      break;
    case 3:
      jrb_free_tree(tree);
      break;
    case 4:

      break;
     }
    } while (choice!=4);
    return 0;
}
