#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include"jrb.h"
#include"dllist.h"

typedef struct{
  JRB edges;
  JRB vertices;
}Graph;

Graph createGraph();
void addVertex(Graph g, int id, char* name);
char *getVertex(Graph g, int id);
void addEdge(Graph g, int v1, int v2);
int hasEdge(Graph g, int v1, int v2);
int indegree(Graph g, int v, int* output);
int outdegree(Graph g, int v, int* output);
int DAG(Graph g);
void dropGraph(Graph g);

void topologicalSort(Graph g,int* output,int* n);

int main(){
  Graph g=createGraph();
  int i,n,output[100];
  addVertex(g,0,"CS102");
  addVertex(g,1,"CS140");
  addVertex(g,2,"CS160");
  addVertex(g,3,"CS302");
  addVertex(g,4,"CS311");
  addVertex(g,5,"MATH300");
  addEdge(g,0,1);
  addEdge(g,0,2);
  addEdge(g,1,3);
  addEdge(g,5,4);
  addEdge(g,3,4);
  if(!DAG(g)){
    printf("Cannot make topological sort\n");
    return 1;
  }
  topologicalSort(g,output,&n);
  printf("the topological order:\n");
  for(i=0;i<n;i++)
    printf("%s\n",getVertex(g,output[i]));
}


Graph createGraph(){
  Graph g;
  g.edges=make_jrb();
  g.vertices=make_jrb();
  return g;
}

void addVertex(Graph g, int id, char* name){
  JRB node=jrb_find_int(g.vertices,id);
  if(node==NULL)
    jrb_insert_int(g.vertices,id,new_jval_s(strdup(name)));
}

char *getVertex(Graph g,int id){
  JRB node=jrb_find_int(g.vertices,id);
  if(node==NULL)
    return NULL;
  else return jval_s(node->val);
}

void addEdge(Graph g, int v1,int v2){
  JRB node,tree;
  if(!hasEdge(g,v1,v2)){
    node=jrb_find_int(g.edges,v1);
    if(node==NULL){
      tree=make_jrb();
      jrb_insert_int(g.edges,v1,new_jval_v(tree));
    }else{
      tree=(JRB)jval_v(node->val);
    }
    jrb_insert_int(tree,v2,new_jval_i(1));
  }
}

int hasEdge(Graph g,int v1,int v2){
  JRB node,tree;
  node=jrb_find_int(g.edges,v1);
  if(node==NULL)
    return 0;
  tree=(JRB)jval_v(node->val);
  if(jrb_find_int(tree,v2)==NULL)
    return 0;
  else return 1;
}

int indegree(Graph g,int v,int* output){
  JRB tree,node;
  int total=0;
  jrb_traverse(node,g.edges)
  {
    tree=(JRB)jval_v(node->val);
    if(jrb_find_int(tree,v)){
      output[total]=jval_i(node->key);
      total++;
    }
  }
  return total;
}

int outdegree(Graph g,int v,int*output){
  JRB tree,node;
  int total;
  node=jrb_find_int(g.edges,v);
  if(node==NULL)
    return 0;
  tree = (JRB)jval_v(node->val);
  total = 0;
  jrb_traverse(node,tree){
    output[total]=jval_i(node->key);
    total++;

  }
  return total;
}

int DAG(Graph g){
  int visited[1000]={};
  int n,output[100],i,u,v,start;
  Dllist node,stack;
  JRB vertex;
  jrb_traverse(vertex,g.vertices){
    memset(visited,0,sizeof(visited));
    start=jval_i(vertex->key);
    stack=new_dllist();
    dll_append(stack,new_jval_i(start));
    while(!dll_empty(stack)){
      node=dll_last(stack);
      u=jval_i(node->val);
      dll_delete_node(node);
      if(!visited[u]){
	visited[u]=1;
	n=outdegree(g,u,output);
	for(i=0;i<n;i++){
	  v=output[i];
	  if(v==start)
	    return 0;
	  if(!visited[v])
	    dll_append(stack,new_jval_i(v));
	}
      }
    }
  }
  return 1;
}

void topologicalSort(Graph g,int* output,int* n){
  int indeg[1000],tmp[100],m,i,u,v,total;
  JRB vertex;
  Dllist node, queue;
  queue=new_dllist();
  jrb_traverse(vertex,g.vertices){
    u=jval_i(vertex->key);
    indeg[u]=indegree(g,u,tmp);
    if(indeg[u]==0)
      dll_append(queue,new_jval_i(u));
  }
  total=0;
  while(!dll_empty(queue)){
    node=dll_first(queue);
    u=jval_i(node->val);
    dll_delete_node(node);
    output[total++]=u;
    m=outdegree(g,u,tmp);
    for(i=0;i<m;i++){
      v=tmp[i];
      indeg[v]--;
      if(indeg[v]==0)
	dll_append(queue,new_jval_i(v));
    }
  }
  *n=total;
}

void dropGraph(Graph g){
  JRB node,tree;
  jrb_traverse(node,g.edges){
    tree=(JRB)jval_v(node->val);
    jrb_free_tree(tree);
    }
  jrb_free_tree(g.edges);
  jrb_free_tree(g.vertices);
  
}
