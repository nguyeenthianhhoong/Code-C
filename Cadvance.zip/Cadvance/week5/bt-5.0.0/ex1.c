#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"btree.h"


int main(){
  BTA *btphone;
  btinit();// khởi tạo thư viện Btree: int btinit(void);
  int choice,i,size;
  char name[20];
  long phone;
  btphone=btopn("book",0,0);// mở Btree file: BTA *btopn(char *namefile,int mode,int shared);  mode=0 cho phép update; shared=0 k cho phép access,khác 0 trả về NULL or con trỏ root  

  do{
    printf("\tMENU:\n");
    printf("1. INSERT\n");
    printf("2. SEARCH\n");
    printf("3. DISPLAY\n");
    printf("4. DELETE\n");
    printf("5. QUIT\n");
    do{
      printf("Input a choice:");
      scanf("%d",&choice);
    }
    while (choice < 1|| choice >5);
    switch(choice){

    case 1:
      
      printf("Name:");
      scanf("%s",&name);
      printf("Phone:");
      scanf("%d",&phone);
      btins(btphone,name,(char*)&phone,sizeof(long));
      
      break;
    case 2:
      printf("Search name:");
      scanf("%s",&name);
      if(btsel(btphone,name,(char*)&phone,sizeof(long),&size) ){
	printf("not found\n");
      }else
	printf("phone:%d\n",phone);
      break;
      
    case 3:
      btsel(btphone, "", (char*)&phone, sizeof(long), &size);
      while ( btseln(btphone, name, (char*)&phone, sizeof(long), &size)==0 ) {
	  printf("%s\t%10d\n", name, phone);
       }	
      break;
    case 4:
      printf("name delete:");
      scanf("%s",&name);
      btdel(btphone,name);
      printf("deleted!!!\n");
      break;
    case 5:

      break;
     }
    } while (choice!=5);
    return 0;

}

/*

1.Khởi tạo thư viện B tree:
    int btinit(void)

2.Tạo file B tree:   BTA *btcrt(char* fid, int nkeys, int shared) 
           fid: tên file 
           nkeys: số lượng khóa nhiều nhất
           shared: nếu bằng 0 thì cho phép share, nếu khác 0 thì không cho phép hàm sẽ trả về root, nếu thất bại sẽ trả về NULL
 
3.Mở B tree file:  BTA *btopn(char *fid,int mode,int shared);
    fid: tên file
    mode: bằng 0 cho phép update, khác 0 thì ko cho phép
    shared: 0 sẽ không cho phép access, khác 0 sẽ cho phép trả về NULL hoặc con trỏ root

4.Thoát B tree file: int btcls(BTA *btact);
    thoát khỏi file B tree trỏ bởi con trỏ btact, nếu thành công sẽ trả về gía trị 0, khác 0 thì đã có lỗi xảy ra

 5.Chèn key và data vào B tree: int btins(BTA *btact, char *key, char *data, int dsize);
  trả về 0 nếu thanh công; dsize: độ dài của data

6.update data cho key: int btupd(BTA *btact, char *key, char *data, int dsize);

7.xác định dữ liệu của khóa có sẵn: int btsel(BTA *btact, char *key, char *data, int dsize, int *rsize);trả lại data record của key tồn tại.
 
8.Xóa key và data:int btdel(BTA *btact, char *key);trả về 0 nếu thành công

9.Xác định kích cỡ của data: int btrecs(BTA *btact, char *key, int *rsize);

*/


